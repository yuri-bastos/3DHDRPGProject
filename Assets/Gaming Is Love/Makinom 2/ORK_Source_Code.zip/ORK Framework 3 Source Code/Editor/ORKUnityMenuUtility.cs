﻿
using UnityEngine;
using UnityEditor;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Editor
{
	public static class ORKUnityMenuUtility
	{
		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public static void AddSphereTrigger3D(GameObject gameObject)
		{
			SphereCollider collider = gameObject.AddComponent<SphereCollider>();
			collider.radius = 5f;
			collider.isTrigger = true;
			gameObject.layer = 2;
		}

		public static void AddCircleTrigger2D(GameObject gameObject)
		{
			CircleCollider2D collider = gameObject.AddComponent<CircleCollider2D>();
			collider.radius = 5f;
			collider.isTrigger = true;
			gameObject.layer = 2;
		}

		public static void AddBoxTrigger3D(GameObject gameObject)
		{
			BoxCollider collider = gameObject.AddComponent<BoxCollider>();
			collider.size = new Vector3(10, 10, 10);
			collider.isTrigger = true;
			gameObject.layer = 2;
		}

		public static void AddBoxTrigger2D(GameObject gameObject)
		{
			BoxCollider2D collider = gameObject.AddComponent<BoxCollider2D>();
			collider.size = new Vector3(10, 10);
			collider.isTrigger = true;
			gameObject.layer = 2;
		}

		public static void Add3DPhysics(GameObject gameObject)
		{
			if(gameObject.GetComponent<Collider>() == null)
			{
				BoxCollider collider = gameObject.AddComponent<BoxCollider>();
				collider.isTrigger = true;
				gameObject.layer = 2;
			}
			if(gameObject.GetComponent<Rigidbody>() == null)
			{
				Rigidbody rigidbody = gameObject.AddComponent<Rigidbody>();
				rigidbody.useGravity = false;
				rigidbody.isKinematic = true;
				rigidbody.constraints = RigidbodyConstraints.FreezeAll;
			}
		}

		public static void Add2DPhysics(GameObject gameObject)
		{
			if(gameObject.GetComponent<Collider2D>() == null)
			{
				BoxCollider2D collider = gameObject.AddComponent<BoxCollider2D>();
				collider.isTrigger = true;
				gameObject.layer = 2;
			}
			if(gameObject.GetComponent<Rigidbody2D>() == null)
			{
				Rigidbody2D rigidbody = gameObject.AddComponent<Rigidbody2D>();
				rigidbody.gravityScale = 0;
				rigidbody.isKinematic = true;
				rigidbody.constraints = RigidbodyConstraints2D.FreezeAll;
			}
		}


		/*
		============================================================================
		Battle functions
		============================================================================
		*/
		// battle
		[MenuItem("GameObject/ORK Framework/Battle/Battle (3D)", false, 20)]
		public static BattleComponent CreateBattle3D(MenuCommand menuCommand)
		{
			BattleComponent battle = SceneObjectHelper.Create<BattleComponent>("Battle");
			ORKUnityMenuUtility.AddSphereTrigger3D(battle.gameObject);
			return battle;
		}

		[MenuItem("GameObject/ORK Framework/Battle/Battle (2D)", false, 20)]
		public static BattleComponent CreateBattle2D(MenuCommand menuCommand)
		{
			BattleComponent battle = SceneObjectHelper.Create<BattleComponent>("Battle");
			ORKUnityMenuUtility.AddCircleTrigger2D(battle.gameObject);
			return battle;
		}

		[MenuItem("GameObject/ORK Framework/Battle/Battle (None)", false, 20)]
		public static BattleComponent CreateBattleNone(MenuCommand menuCommand)
		{
			BattleComponent battle = SceneObjectHelper.CreateSimple<BattleComponent>("Battle");
			battle.UseSceneID = false;
			battle.startSettings.DisableAll();
			battle.settings.combatant = new ChanceBattleCombatant[0];
			return battle;
		}

		// random battle area
		[MenuItem("GameObject/ORK Framework/Battle/Random Battle Area (3D)", false, 20)]
		public static RandomBattleArea CreateRandomBattleArea3D(MenuCommand menuCommand)
		{
			RandomBattleArea battle = SceneObjectHelper.CreateSimple<RandomBattleArea>("Random Battle Area");
			ORKUnityMenuUtility.AddBoxTrigger3D(battle.gameObject);
			return battle;
		}

		[MenuItem("GameObject/ORK Framework/Battle/Random Battle Area (2D)", false, 20)]
		public static RandomBattleArea CreateRandomBattleArea2D(MenuCommand menuCommand)
		{
			RandomBattleArea battle = SceneObjectHelper.CreateSimple<RandomBattleArea>("Random Battle Area");
			ORKUnityMenuUtility.AddBoxTrigger2D(battle.gameObject);
			return battle;
		}

		// real time battle area
		[MenuItem("GameObject/ORK Framework/Battle/Real Time Battle Area (Scene)", false, 20)]
		public static RealTimeBattleArea CreateRealTimeBattleArea(MenuCommand menuCommand)
		{
			return SceneObjectHelper.CreateSimple<RealTimeBattleArea>("Real Time Battle Area (Scene)");
		}

		[MenuItem("GameObject/ORK Framework/Battle/Real Time Battle Area (3D)", false, 20)]
		public static RealTimeBattleArea CreateRealTimeBattleArea3D(MenuCommand menuCommand)
		{
			RealTimeBattleArea battle = SceneObjectHelper.CreateSimple<RealTimeBattleArea>("Real Time Battle Area");
			ORKUnityMenuUtility.AddBoxTrigger3D(battle.gameObject);
			return battle;
		}

		[MenuItem("GameObject/ORK Framework/Battle/Real Time Battle Area (2D)", false, 20)]
		public static RealTimeBattleArea CreateRealTimeBattleArea2D(MenuCommand menuCommand)
		{
			RealTimeBattleArea battle = SceneObjectHelper.CreateSimple<RealTimeBattleArea>("Real Time Battle Area");
			ORKUnityMenuUtility.AddBoxTrigger2D(battle.gameObject);
			return battle;
		}

		[MenuItem("GameObject/ORK Framework/Battle/Battle Grid", false, 20)]
		public static BattleGridComponent CreateBattleGrid(MenuCommand menuCommand)
		{
			return SceneObjectHelper.CreateSimple<BattleGridComponent>("Battle Grid");
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		[MenuItem("GameObject/ORK Framework/Combatant/Combatant Spawner", false, 21)]
		public static CombatantSpawner CreateCombatantSpawner(MenuCommand menuCommand)
		{
			return SceneObjectHelper.Create<CombatantSpawner>("Combatant Spawner");
		}

		[MenuItem("GameObject/ORK Framework/Combatant/Combatant Spawner (3D)", false, 21)]
		public static CombatantSpawner CreateCombatantSpawner3D(MenuCommand menuCommand)
		{
			CombatantSpawner spawner = SceneObjectHelper.Create<CombatantSpawner>("Combatant Spawner (Area)");
			ORKUnityMenuUtility.AddBoxTrigger3D(spawner.gameObject);
			return spawner;
		}

		[MenuItem("GameObject/ORK Framework/Combatant/Combatant Spawner (2D)", false, 21)]
		public static CombatantSpawner CreateCombatantSpawner2D(MenuCommand menuCommand)
		{
			CombatantSpawner spawner = SceneObjectHelper.Create<CombatantSpawner>("Combatant Spawner (Area)");
			ORKUnityMenuUtility.AddBoxTrigger2D(spawner.gameObject);
			return spawner;
		}

		[MenuItem("GameObject/ORK Framework/Combatant/Combatant Trigger (3D)", false, 21)]
		public static CombatantTriggerComponent CreateCombatantTrigger3D(MenuCommand menuCommand)
		{
			CombatantTriggerComponent combatantTrigger = SceneObjectHelper.CreateSimple<CombatantTriggerComponent>("Combatant Trigger");
			ORKUnityMenuUtility.AddSphereTrigger3D(combatantTrigger.gameObject);
			return combatantTrigger;
		}

		[MenuItem("GameObject/ORK Framework/Combatant/Combatant Trigger (2D)", false, 21)]
		public static CombatantTriggerComponent CreateCombatantTrigger2D(MenuCommand menuCommand)
		{
			CombatantTriggerComponent combatantTrigger = SceneObjectHelper.CreateSimple<CombatantTriggerComponent>("Combatant Trigger");
			ORKUnityMenuUtility.AddCircleTrigger2D(combatantTrigger.gameObject);
			return combatantTrigger;
		}


		/*
		============================================================================
		Zone functions
		============================================================================
		*/
		// area
		[MenuItem("GameObject/ORK Framework/Zone/Area", false, 21)]
		public static AreaComponent CreateArea(MenuCommand menuCommand)
		{
			AreaComponent area = SceneObjectHelper.CreateSimple<AreaComponent>("Area");
			area.gameObject.layer = 2;
			area.startSettings.DisableAll();
			area.startSettings.autoStartSetting.isStart = true;
			return area;
		}

		[MenuItem("GameObject/ORK Framework/Zone/Area (3D)", false, 21)]
		public static AreaComponent CreateArea3D(MenuCommand menuCommand)
		{
			AreaComponent area = SceneObjectHelper.CreateSimple<AreaComponent>("Area");
			ORKUnityMenuUtility.AddSphereTrigger3D(area.gameObject);
			return area;
		}

		[MenuItem("GameObject/ORK Framework/Zone/Area (2D)", false, 21)]
		public static AreaComponent CreateArea2D(MenuCommand menuCommand)
		{
			AreaComponent area = SceneObjectHelper.CreateSimple<AreaComponent>("Area");
			ORKUnityMenuUtility.AddCircleTrigger2D(area.gameObject);
			return area;
		}

		// level zone
		[MenuItem("GameObject/ORK Framework/Zone/Level Zone (Scene)", false, 21)]
		public static LevelZone CreateLevelZone(MenuCommand menuCommand)
		{
			return SceneObjectHelper.CreateSimple<LevelZone>("Level Zone (Scene)");
		}

		[MenuItem("GameObject/ORK Framework/Zone/Level Zone (3D)", false, 21)]
		public static LevelZone CreateLevelZone3D(MenuCommand menuCommand)
		{
			LevelZone levelZone = SceneObjectHelper.CreateSimple<LevelZone>("Level Zone");
			ORKUnityMenuUtility.AddBoxTrigger3D(levelZone.gameObject);
			return levelZone;
		}

		[MenuItem("GameObject/ORK Framework/Zone/Level Zone (2D)", false, 21)]
		public static LevelZone CreateLevelZone2D(MenuCommand menuCommand)
		{
			LevelZone levelZone = SceneObjectHelper.CreateSimple<LevelZone>("Level Zone");
			ORKUnityMenuUtility.AddBoxTrigger2D(levelZone.gameObject);
			return levelZone;
		}

		// block spawn
		[MenuItem("GameObject/ORK Framework/Combatant/Block Combatant Spawn (3D)", false, 21)]
		[MenuItem("GameObject/ORK Framework/Zone/Block Combatant Spawn (3D)", false, 21)]
		public static BlockCombatantSpawn CreateBlockCombatantSpawn3D(MenuCommand menuCommand)
		{
			BlockCombatantSpawn block = SceneObjectHelper.CreateSimple<BlockCombatantSpawn>("Block Combatant Spawn");
			ORKUnityMenuUtility.AddBoxTrigger3D(block.gameObject);
			return block;
		}

		[MenuItem("GameObject/ORK Framework/Combatant/Block Combatant Spawn (2D)", false, 21)]
		[MenuItem("GameObject/ORK Framework/Zone/Block Combatant Spawn (2D)", false, 21)]
		public static BlockCombatantSpawn CreateBlockCombatantSpawn2D(MenuCommand menuCommand)
		{
			BlockCombatantSpawn block = SceneObjectHelper.CreateSimple<BlockCombatantSpawn>("Block Combatant Spawn");
			ORKUnityMenuUtility.AddBoxTrigger2D(block.gameObject);
			return block;
		}


		/*
		============================================================================
		Move AI functions
		============================================================================
		*/
		[MenuItem("GameObject/ORK Framework/Move AI/Point of Interest (Move AI)", false, 32)]
		public static PointOfInterest CreatePointOfInterest(MenuCommand menuCommand)
		{
			return SceneObjectHelper.CreateSimple<PointOfInterest>("Point of Interest");
		}

		[MenuItem("GameObject/ORK Framework/Move AI/Move AI Area (3D)", false, 32)]
		public static MoveAIArea CreateMoveAIArea3D(MenuCommand menuCommand)
		{
			MoveAIArea area = SceneObjectHelper.CreateSimple<MoveAIArea>("Move AI Area");
			ORKUnityMenuUtility.AddBoxTrigger3D(area.gameObject);
			return area;
		}

		[MenuItem("GameObject/ORK Framework/Move AI/Move AI Area (2D)", false, 32)]
		public static MoveAIArea CreateMoveAIArea2D(MenuCommand menuCommand)
		{
			MoveAIArea area = SceneObjectHelper.CreateSimple<MoveAIArea>("Move AI Area");
			ORKUnityMenuUtility.AddBoxTrigger2D(area.gameObject);
			return area;
		}

		[MenuItem("GameObject/ORK Framework/Move AI/Move AI Range (3D)", false, 32)]
		public static MoveAIRangeComponent CreateMoveAIRange3D(MenuCommand menuCommand)
		{
			MoveAIRangeComponent range = SceneObjectHelper.CreateSimple<MoveAIRangeComponent>("Move AI Range");
			ORKUnityMenuUtility.AddBoxTrigger3D(range.gameObject);
			return range;
		}

		[MenuItem("GameObject/ORK Framework/Move AI/Move AI Range (2D)", false, 32)]
		public static MoveAIRangeComponent CreateMoveAIRange2D(MenuCommand menuCommand)
		{
			MoveAIRangeComponent range = SceneObjectHelper.CreateSimple<MoveAIRangeComponent>("Move AI Range");
			ORKUnityMenuUtility.AddBoxTrigger2D(range.gameObject);
			return range;
		}

		[MenuItem("GameObject/ORK Framework/Move AI/Move AI Hiding Area (3D)", false, 32)]
		public static MoveAIHidingAreaComponent CreateMoveAIHidingArea3D(MenuCommand menuCommand)
		{
			MoveAIHidingAreaComponent area = SceneObjectHelper.CreateSimple<MoveAIHidingAreaComponent>("Move AI Hiding Area");
			ORKUnityMenuUtility.AddBoxTrigger3D(area.gameObject);
			return area;
		}

		[MenuItem("GameObject/ORK Framework/Move AI/Move AI Hiding Area (2D)", false, 32)]
		public static MoveAIHidingAreaComponent CreateMoveAIHidingArea2D(MenuCommand menuCommand)
		{
			MoveAIHidingAreaComponent area = SceneObjectHelper.CreateSimple<MoveAIHidingAreaComponent>("Move AI Hiding Area");
			ORKUnityMenuUtility.AddBoxTrigger2D(area.gameObject);
			return area;
		}

		[MenuItem("GameObject/ORK Framework/Move AI/No Random Patrol (3D)", false, 32)]
		public static NoRandomPatrol CreateNoRandomPatrol3D(MenuCommand menuCommand)
		{
			NoRandomPatrol area = SceneObjectHelper.CreateSimple<NoRandomPatrol>("No Random Patrol");
			ORKUnityMenuUtility.AddBoxTrigger3D(area.gameObject);
			return area;
		}

		[MenuItem("GameObject/ORK Framework/Move AI/No Random Patrol (2D)", false, 32)]
		public static NoRandomPatrol CreateNoRandomPatrol2D(MenuCommand menuCommand)
		{
			NoRandomPatrol area = SceneObjectHelper.CreateSimple<NoRandomPatrol>("No Random Patrol");
			ORKUnityMenuUtility.AddBoxTrigger2D(area.gameObject);
			return area;
		}


		/*
		============================================================================
		Game object functions
		============================================================================
		*/
		[MenuItem("GameObject/ORK Framework/ORK Game Starter", false, 43)]
		public static ORKGameStarter CreateGameStarter(MenuCommand menuCommand)
		{
			ORKGameStarter gameStarter = SceneObjectHelper.CreateSimple<ORKGameStarter>("ORK Game Starter");
			gameStarter.project = MakinomAssetHelper.LoadProjectAsset();
			return gameStarter;
		}

		[MenuItem("GameObject/ORK Framework/Item Collector", false, 43)]
		public static ItemCollector CreateItemCollector(MenuCommand menuCommand)
		{
			if(!Maki.Instantiated)
			{
				Maki.Initialize(MakinomAssetHelper.LoadProjectAsset());
			}
			return SceneObjectHelper.Create<ItemCollector>("Item Collector");
		}

		[MenuItem("GameObject/ORK Framework/Shop Interaction", false, 43)]
		public static ShopInteraction CreateShopInteraction(MenuCommand menuCommand)
		{
			return SceneObjectHelper.CreateSimple<ShopInteraction>("Shop Interaction");
		}
	}
}
