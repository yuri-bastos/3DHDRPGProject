﻿
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(TopDownBorderCamera))]
public class TopDownBorderCameraInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as TopDownBorderCamera);
	}

	protected virtual void ComponentSetup(TopDownBorderCamera target)
	{
		Undo.RecordObject(target, "Change to 'Top Down Border Camera' on " + target.name);
		this.BaseInit(false);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}