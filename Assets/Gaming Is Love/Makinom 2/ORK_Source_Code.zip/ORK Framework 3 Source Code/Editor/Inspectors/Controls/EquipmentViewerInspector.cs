
using GamingIsLove.Makinom.Editor;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Editor;
using GamingIsLove.ORKFramework.Components;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;

[CustomEditor(typeof(EquipmentViewer))]
public class EquipmentViewerInspector : BaseInspector
{
	private GameObject prefabInstance;

	private EquipPreview preview = new EquipPreview();

	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as EquipmentViewer);
	}

	protected virtual void ComponentSetup(EquipmentViewer target)
	{
		Undo.RecordObject(target, "Change to 'Equipment Viewer' on " + target.name);
		this.BaseInit(true);

		EditorAutomation.Automate(target.settings, this.baseEditor);


		// equipment preview
		if(!Application.isPlaying)
		{
			if(this.baseEditor.BeginFoldout("Equipment Preview",
				"Display a selected equipment to preview how it will look on the equipment viewer.\n" +
				"You need to disable preview when you're done, otherwise the previewed equipment prefab won't be removed.", "", false))
			{
				bool tmpPreview = this.preview.preview;
				EquipmentAsset tmpEquip = this.preview.equip.StoredAsset;
				bool tmpIsPrefabView = this.preview.isPrefabView;

				EditorAutomation.Automate(this.preview, this.baseEditor);

				if(tmpPreview != this.preview.preview ||
					this.preview.equip.Is(tmpEquip) ||
					tmpIsPrefabView != this.preview.isPrefabView)
				{
					if(this.prefabInstance != null)
					{
						GameObject.DestroyImmediate(this.prefabInstance);
					}

					if(this.preview.preview &&
						this.preview.equip.StoredAsset != null)
					{
						Equipment equip = this.preview.equip.StoredAsset.Settings;

						this.prefabInstance = equip.GetPrefabSettings(this.preview.level - 1).
							CreateViewerPrefab(target.transform, null, this.preview.isPrefabView);
						if(this.prefabInstance != null)
						{
							this.prefabInstance.hideFlags = HideFlags.DontSave;
							if(target.settings.setScale)
							{
								this.prefabInstance.transform.localScale = target.settings.scale;
							}

							for(int i = 0; i < target.settings.childLink.Length; i++)
							{
								Transform equipChild = this.prefabInstance.transform.Find(target.settings.childLink[i].equipmentChildObject);
								Transform combatantChild = target.transform.root.Find(target.settings.childLink[i].combatantChildObject);
								if(equipChild != null && combatantChild != null)
								{
									equipChild.SetPositionAndRotation(combatantChild.position, combatantChild.rotation);
								}
							}
						}
					}
				}

				EditorGUILayout.Separator();
			}
			this.baseEditor.EndFoldout();
		}

		this.EndSetup();
	}

	private class EquipPreview : BaseData
	{
		[EditorHelp("Preview Prefab", "Preview a selected equipment's prefab.")]
		[EditorLabel("Display a selected equipment to preview how it will look on the equipment viewer.\n" +
			"You need to disable preview when you're done, otherwise the previewed equipment prefab won't be removed.")]
		public bool preview = false;

		[EditorHelp("Equipment", "Select the equipment that will be displayed.")]
		public AssetSelection<EquipmentAsset> equip = new AssetSelection<EquipmentAsset>();

		[EditorHelp("Level", "Define the level of the equipment that will be used.")]
		[EditorLimit(1, false)]
		public int level = 1;

		[EditorHelp("Prefab View Portrait", "Display the equipment as a prefab view portrait.")]
		public bool isPrefabView = false;

		public EquipPreview()
		{

		}
	}
}