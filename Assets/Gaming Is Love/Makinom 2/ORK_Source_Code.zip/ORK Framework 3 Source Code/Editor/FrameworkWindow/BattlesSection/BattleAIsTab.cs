
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.ORKFramework.AI.Nodes;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class BattleAIsTab : ORKGenericAssetListTab<BattleAIAsset, BattleAI>
	{
		private BattleAIAsset battleAI;

		private int lastIndex = -1;

		private bool resetList = false;


		// node editor
		private NodeEditor nodeEditor;

		private Rect nodeRect = new Rect(0, 0, 0, 0);

		private static List<EditorClipboard> clipboard = new List<EditorClipboard>();

		public BattleAIsTab(MakinomEditorWindow parent) : base(parent)
		{
			this.nodeEditor = new NodeEditor(this, BattleAIsTab.clipboard,
				this.AddNode, this.RemoveNode, this.AddNodeGroup, this.RemoveNodeGroup, this.AddLayer);

			this.nodeEditor.SetNodeInfos(
				EditorAttributes.GetNodeInfos(typeof(BaseAINode)),
				typeof(BattleAIGateNode));
		}

		public override void Reloaded()
		{
			base.Reloaded();
			this.battleAI = null;
			this.lastIndex = -1;
		}

		public override bool FocusSearchField()
		{
			if(Event.current.mousePosition.x < EditorDataHandler.Instance.EditorAsset.SubSectionDrag +
				EditorDataHandler.Instance.EditorAsset.TabListDrag)
			{
				if(this.listSearchField != null)
				{
					this.listSearchField.SetFocus();
					return true;
				}
			}
			else
			{
				this.nodeEditor.FocusSearchField();
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Battle AIs"; }
		}

		public override string HelpText
		{
			get
			{
				return "Battle AIs are used by the AI controlled combatants to select battle actions.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/battle-ai/"; }
		}

		protected override bool EnableSearchBarFoldoutButtons
		{
			get
			{
				if(this.nodeEditor.IsNodeSelected &&
					this.nodeEditor.Selected.Count > 1)
				{
					return true;
				}
				return false;
			}
		}


		/*
		============================================================================
		Settings display
		============================================================================
		*/
		protected override void RemoveData()
		{
			base.RemoveData();
			this.resetList = true;
		}

		public override void ShowTab()
		{
			this.ClearShow();

			EditorGUILayout.BeginHorizontal();

			this.ShowList();

			this.Editor.TabListDrag();

			EditorGUILayout.BeginVertical();

			EditorGUI.BeginDisabledGroup(!this.editable);
			this.ShowSettings();
			this.CloseAllFoldouts();
			EditorGUI.EndDisabledGroup();

			EditorGUILayout.EndVertical();
			EditorGUILayout.EndHorizontal();

			if(GUI.changed)
			{
				this.Editor.Repaint();
			}
		}

		public override void ShowSettings()
		{
			if(this.assetList.AssetExists(this.index))
			{
				if(this.index != this.lastIndex ||
					this.resetList)
				{
					this.resetList = false;
					this.battleAI = this.assetList.Assets[this.index];
					this.nodeEditor.SelectNode(this.battleAI.Settings.setting, false, -1);
					this.nodeEditor.Layer = this.battleAI.Settings.setting.nodeLayer;
					this.nodeEditor.FirstFocus = true;
					this.lastIndex = this.index;

					// remove empty nodes
					for(int i = 0; i < this.battleAI.Settings.setting.node.Length; i++)
					{
						if(this.battleAI.Settings.setting.node[i] == null)
						{
							CommentNode tmp = new CommentNode();
							tmp.comment = "null node loaded";
							this.battleAI.Settings.setting.node[i] = tmp;
							Debug.LogWarning("Replacing null node at index " + i + " with comment node.\n" +
								"This can be the result of a custom node script that has been removed from the project.\n" +
								"Saving the battle AI will also save the comment the node.");
						}
					}
				}
			}
			else
			{
				this.battleAI = null;
			}

			if(this.battleAI != null)
			{
				this.nodeRect.Set(
					EditorDataHandler.Instance.EditorAsset.SubSectionDrag + EditorDataHandler.Instance.EditorAsset.TabListDrag + 22,
					EditorTool.SectionHeight,
					this.Editor.position.width - EditorDataHandler.Instance.EditorAsset.SubSectionDrag - EditorDataHandler.Instance.EditorAsset.TabListDrag - 22,
					this.Editor.position.height - EditorTool.SectionHeight - EditorTool.SaveButtonHeight - EditorDataHandler.Instance.EditorAsset.FormulaDrag);

				GUILayoutUtility.GetRect(this.nodeRect.width, this.nodeRect.height);

				// node display
				if(this.nodeEditor.showSettings)
				{
					this.Editor.FormulaDrag();

					EditorGUILayout.BeginHorizontal(GUILayout.Height(EditorDataHandler.Instance.EditorAsset.FormulaDrag));

					this.BeforeSettings();

					EditorGUILayout.BeginVertical();
					this.ShowSearchSettings();

					// node settings
					this.settingsScroll = EditorGUILayout.BeginScrollView(this.settingsScroll);

					if(this.nodeEditor.NewStartNode != null &&
						EditorTool.Button("View All Nodes", "Exits the current limited node view and displays all nodes.", ""))
					{
						this.nodeEditor.NewStartNode = null;
					}

					// node settings
					if(this.nodeEditor.Selected != null)
					{
						for(int i = 0; i < this.nodeEditor.Selected.Count; i++)
						{
							if(this.nodeEditor.Selected[i] != null)
							{
								if(this.nodeEditor.Selected[i] == this.battleAI.Settings.setting)
								{
									this.guidField.Edit(this.battleAI.Settings, this);
									EditorAutomation.Automate(this.battleAI.Settings, this);
								}
								else
								{
									NodeInfo nodeInfo = this.nodeEditor.GetNodeInfo(this.nodeEditor.Selected[i].GetType());
									if(this.BeginFoldout(nodeInfo.content, nodeInfo.info, true))
									{
										nodeInfo.ShowSubMenuInfo();

										if(!(this.nodeEditor.Selected[i] is BattleAIGateNode))
										{
											EditorGUILayout.BeginHorizontal();
											EditorAutomation.Automate("active", this.nodeEditor.Selected[i], this, true);
											if(EditorTool.MicroButton("Focus", "Focus the node editor on this node.\n" +
												"Can also be done using the keyboard shortcut 'CTRL + F'.", ""))
											{
												this.nodeEditor.FocusNode(this.nodeEditor.Selected[i]);
											}
											GUILayout.FlexibleSpace();
											EditorGUILayout.EndHorizontal();
										}
										else
										{
											if(EditorTool.MicroButton("Focus", "Focus the node editor on this node.\n" +
												"Can also be done using the keyboard shortcut 'CTRL + F'.", ""))
											{
												this.nodeEditor.FocusNode(this.nodeEditor.Selected[i]);
											}
										}

										// override name
										EditorGUILayout.BeginHorizontal();
										EditorAutomation.Automate("overrideNodeName", this.nodeEditor.Selected[i], this, true);
										EditorAutomation.Automate("nodeName", this.nodeEditor.Selected[i], this, true);
										GUILayout.FlexibleSpace();
										EditorGUILayout.EndHorizontal();

										if(this.nodeEditor.Selected[i].IsEnabled)
										{
											EditorGUILayout.Separator();
											EditorAutomation.Automate(this.nodeEditor.Selected[i], this);
										}
										EditorGUILayout.Separator();
									}
									this.EndFoldout();
								}
							}
						}
					}
					EditorGUILayout.EndScrollView();
					EditorGUILayout.EndVertical();

					this.AfterSettings();

					EditorGUILayout.EndHorizontal();
				}
			}
		}

		public override void InstanceCallback(string info, System.Object instance)
		{
			if(info == "buttons:randomnode")
			{
				if(instance is RandomNode)
				{
					if(EditorTool.Button("Add Node", "Adds a random node to the list.", ""))
					{
						ArrayHelper.Add(ref ((RandomNode)instance).random, -1);
					}
					if(((RandomNode)instance).random.Length > 1 &&
						EditorTool.Button("Remove Node", "Removes the last random node from the list.", ""))
					{
						ArrayHelper.RemoveAt(ref ((RandomNode)instance).random, ((RandomNode)instance).random.Length - 1);
					}
				}
			}
			else
			{
				base.InstanceCallback(info, instance);
			}
		}

		public override void ShowAfterEditor()
		{
			if(this.battleAI != null)
			{
				// node grid
				this.nodeEditor.ShowNodes(this.nodeRect,
					this.battleAI.Settings.setting,
					this.battleAI.Settings.setting.node,
					this.battleAI.Settings.setting.group,
					null,
					ref this.battleAI.Settings.setting.layer);

				if(GUI.changed)
				{
					this.parent.Repaint();
				}
			}
		}


		/*
		============================================================================
		Node functions
		============================================================================
		*/
		public BaseNode[] AddNode(BaseNode node)
		{
			if(this.battleAI != null && node is BaseAINode)
			{
				ArrayHelper.Add(ref this.battleAI.Settings.setting.node, node as BaseAINode);
				return this.battleAI.Settings.setting.node;
			}
			return null;
		}

		public BaseNode[] RemoveNode(BaseNode node)
		{
			if(this.battleAI != null && node is BaseAINode)
			{
				ArrayHelper.Remove(ref this.battleAI.Settings.setting.node, node as BaseAINode);
				return this.battleAI.Settings.setting.node;
			}
			return null;
		}

		public NodeGroup[] AddNodeGroup(NodeGroup group)
		{
			if(this.battleAI != null)
			{
				ArrayHelper.Add(ref this.battleAI.Settings.setting.group, group);
				return this.battleAI.Settings.setting.group;
			}
			return null;
		}

		public NodeGroup[] RemoveNodeGroup(NodeGroup group)
		{
			if(this.battleAI != null)
			{
				ArrayHelper.Remove(ref this.battleAI.Settings.setting.group, group);
				return this.battleAI.Settings.setting.group;
			}
			return null;
		}

		public string[] AddLayer()
		{
			if(this.battleAI != null)
			{
				ArrayHelper.Add(ref this.battleAI.Settings.setting.layer, "New Layer");
				return this.battleAI.Settings.setting.layer;
			}
			return null;
		}
	}
}
