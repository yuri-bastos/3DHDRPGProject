
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class CraftingTypesTab : ORKGenericAssetListTab<CraftingTypeAsset, CraftingType>
	{
		public CraftingTypesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.CraftingTypes.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.CraftingTypes.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Crafting Settings & Types"; }
		}

		public override string HelpText
		{
			get
			{
				return "Set up basic crafting settings, e.g. default layout and notification, " +
					"and define crafting types that are used to separate crafting recipes.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/inventory/crafting-recipes/"; }
		}

		public override bool HasGeneralSettings
		{
			get { return true; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up general settings regarding crafting.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.CraftingSettings; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.CraftingSettings;
				}
				return base.DisplayedSettings;
			}
		}
	}
}
