
using UnityEditor;
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class FactionsTab : ORKGenericAssetListTab<FactionAsset, FactionSetting>
	{
		public FactionsTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Factions.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Factions.SetAssets(this.assetList.Assets);
		}

		public override void DefaultSetup()
		{
			if(this.assetList.Assets.Count == 0)
			{
				FactionAsset player = FactionsTab.CreateAsset("Player");
				FactionAsset enemies = FactionsTab.CreateAsset("Enemies");
				FactionAsset allies = FactionsTab.CreateAsset("Allies");
				this.assetList.Add(player);
				this.assetList.Add(enemies);
				this.assetList.Add(allies);

				ORK.Factions.sympathy = new FactionSympathy[]
				{
					new FactionSympathy(player, enemies, -1000),
					new FactionSympathy(player, allies, 1000),
					new FactionSympathy(enemies, allies, -100)
				};
			}
		}

		private static FactionAsset CreateAsset(string name)
		{
			FactionAsset asset = ScriptableObject.CreateInstance<FactionAsset>();
			asset.Settings = new FactionSetting(name);
			return asset;
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Factions"; }
		}

		public override string HelpText
		{
			get
			{
				return "Factions are used distinct enemies from allies.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/factions/"; }
		}

		public override string GeneralSettingsHelpText
		{
			get
			{
				return "Set up sympathies between factions.\n" +
					"The default start sympathy between factions is 0, add a faction sympathy to use a different sympathy.";
			}
		}

		protected override BaseSettings Settings
		{
			get { return ORK.AnimationTypes; }
		}

		protected override IBaseData DisplayedSettings
		{
			get
			{
				if(this.index == -1)
				{
					return ORK.Factions;
				}
				return base.DisplayedSettings;
			}
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			base.ShowSettings();

			if(this.index == -1)
			{
				for(int i = 0; i < ORK.Factions.sympathy.Length; i++)
				{
					if(ORK.Factions.sympathy[i].sympathy < ORK.Factions.min)
					{
						ORK.Factions.sympathy[i].sympathy = ORK.Factions.min;
					}
					else if(ORK.Factions.sympathy[i].sympathy > ORK.Factions.max)
					{
						ORK.Factions.sympathy[i].sympathy = ORK.Factions.max;
					}
				}
			}
		}
	}
}
