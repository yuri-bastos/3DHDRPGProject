
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class LootTab : ORKGenericAssetListTab<LootAsset, Loot>
	{
		public LootTab(MakinomEditorWindow parent) : base(parent)
		{

		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Loot"; }
		}

		public override string HelpText
		{
			get
			{
				return "Loot is used to create loot tables for combatants and can also be used by shops and item collectors.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/loot/"; }
		}
	}
}
