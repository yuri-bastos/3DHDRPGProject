
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class AbilitiesTab : ORKGenericAssetListTab<AbilityAsset, Ability>
	{
		private int arrayIndex = 0;

		private string[] sections = new string[] { "1" };

		private bool showLevelInBar = false;

		public AbilitiesTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.Abilities.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.Abilities.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Abilities"; }
		}

		public override string HelpText
		{
			get
			{
				return "Abilities are actions that can be used to do damage/healing or other status changes, as well as passive bonuses.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/abilities/"; }
		}


		/*
		============================================================================
		Filter functions
		============================================================================
		*/
		protected override FilteredList Filter
		{
			get
			{
				if(this.filter == null)
				{
					this.filter = new FilteredList(this,
						new FilteredListAssetSelection<AbilityTypeAsset, AbilityType>(
							new string[] { "Ability Type", "Filter the ability list by ability type.", "" }));
				}
				return this.filter;
			}
		}

		protected override bool CheckFilterCondition(int index)
		{
			if(this.Filter.assetFilterSelection[0].UseFilter)
			{
				AbilityType type = this.Filter.assetFilterSelection[0].Selection as AbilityType;
				return this.assetList.Assets[index].Settings.IsType(type, false);
			}
			return true;
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			bool tmp = false;
			Ability ability = this.CurrentSettings;
			if(ability != null)
			{
				tmp = ability.IsUseable(UseableIn.None);
			}

			base.ShowSettings();

			if(ability != null)
			{
				if(tmp != ability.IsUseable(UseableIn.None))
				{
					ability.level = new AbilityLevel[] { new AbilityLevel() };
				}

				// check level index for buttons
				this.CheckArrayIndex(ability.level.Length);

				// check level index for settings display
				this.CheckArrayIndex(ability.level.Length);

				// show level settings
				if(ability.IsUseable(UseableIn.None))
				{
					if(LevelUpType.Uses == ability.lvlType)
					{
						ability.lvlType = LevelUpType.None;
					}
					if(ability.level[this.arrayIndex].passive == null)
					{
						ability.level[this.arrayIndex].passive = new PassiveAbility();
					}
				}
				else if(ability.level[this.arrayIndex].active == null)
				{
					ability.level[this.arrayIndex].active = new ActiveAbility();
				}
				EditorAutomation.Automate(ability.level[this.arrayIndex], this);

				ability.level[0].lvlPoints = 0;
				for(int i = 1; i < ability.level.Length; i++)
				{
					if(ability.level[i].lvlPoints < ability.level[i - 1].lvlPoints)
					{
						ability.level[i].lvlPoints = ability.level[i - 1].lvlPoints + 1;
					}
				}
			}
		}

		protected override void ShowSearchBarExtension()
		{
			if(Event.current.type == EventType.Layout)
			{
				EditorFoldout foldout = this.GetFoldout("Level Settings");
				if(this.foldoutLimit != "")
				{
					this.showLevelInBar = this.foldoutLimitList.IndexOf(this.foldoutLimit) > this.foldoutLimitList.IndexOf("Level Settings");
				}
				else
				{
					this.showLevelInBar = foldout != null &&
						foldout.Displayed &&
						foldout.StartPosition > 0 &&
						this.settingsScroll.y > foldout.StartPosition + 100;
				}
			}

			if(this.showLevelInBar)
			{
				Ability ability = this.CurrentSettings;
				if(ability != null)
				{
					EditorGUILayout.BeginVertical(GUILayout.Height(24));
					EditorGUILayout.BeginHorizontal();
					EditorTool.BoldLabel("Levels");
					if(EditorTool.Button(new GUIContent("", EditorContent.Instance.AddIcon, "Add a new level (copy of the last level)."), EditorTool.WIDTH_30))
					{
						ArrayHelper.Add(ref ability.level, ability.level[ability.level.Length - 1].GetCopy());
						this.arrayIndex = ability.level.Length - 1;
					}
					if(EditorTool.Button(new GUIContent("", EditorContent.Instance.CopyIcon, "Copy this level."), EditorTool.WIDTH_30))
					{
						ArrayHelper.Add(ref ability.level, ability.level[this.arrayIndex].GetCopy());
						this.arrayIndex = ability.level.Length - 1;
					}
					EditorGUI.BeginDisabledGroup(ability.level.Length == 1);
					if(EditorTool.Button(new GUIContent("", EditorContent.Instance.RemoveIcon, "Remove this level."), EditorTool.WIDTH_30))
					{
						ArrayHelper.RemoveAt(ref ability.level, this.arrayIndex);
					}
					EditorGUI.EndDisabledGroup();

					if(this.sections.Length != ability.level.Length)
					{
						this.sections = new string[ability.level.Length];
						for(int i = 0; i < this.sections.Length; i++)
						{
							this.sections[i] = (i + 1).ToString();
						}
					}

					EditorTool.SelectionGridCenter("LevelGridSearchbar", ref this.arrayIndex, this.sections, 10, 55);

					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndVertical();
				}
			}
		}

		private void CheckArrayIndex(int max)
		{
			if(this.arrayIndex < 0)
			{
				this.arrayIndex = 0;
			}
			else if(this.arrayIndex >= max)
			{
				this.arrayIndex = max - 1;
			}
		}


		/*
		============================================================================
		Name/description help labels
		============================================================================
		*/
		public override void AutomationCallback(string info)
		{
			if(info == "textcodes:name" ||
				info == "textcodes:shortname")
			{
				EditorGUILayout.HelpBox("<level> = current ability level",
					 MessageType.Info, true);
			}
			else if(info == "textcodes:description" ||
				info == "textcodes:customcontent")
			{
				EditorGUILayout.HelpBox("<bonus> = bonuses\n" +
					"<level> = current ability level",
					 MessageType.Info, true);
			}
			else if(info == "buttons:levels")
			{
				Ability ability = this.CurrentSettings;

				if(ability != null)
				{
					EditorGUILayout.BeginHorizontal();
					if(EditorTool.MediumButton(new GUIContent("Add Level", EditorContent.Instance.AddIcon, "Add a new level (copy of the last level)."),
						"Adds a new ability level.\n" +
						"The new level is a copy of the last ability level.", ""))
					{
						ArrayHelper.Add(ref ability.level, ability.level[ability.level.Length - 1].GetCopy());
						this.arrayIndex = ability.level.Length - 1;
					}
					if(EditorTool.MediumButton(new GUIContent("Copy Level", EditorContent.Instance.CopyIcon, "Copy this level."),
						"The selected ability level will be copied.", ""))
					{
						ArrayHelper.Add(ref ability.level, ability.level[this.arrayIndex].GetCopy());
						this.arrayIndex = ability.level.Length - 1;
					}
					EditorGUI.BeginDisabledGroup(ability.level.Length == 1);
					if(EditorTool.MediumButton(new GUIContent("Remove Level", EditorContent.Instance.RemoveIcon, "Remove this level."),
						"The selected ability level will be removed.", ""))
					{
						ArrayHelper.RemoveAt(ref ability.level, this.arrayIndex);
					}
					EditorGUI.EndDisabledGroup();
					GUILayout.FlexibleSpace();
					EditorGUILayout.EndHorizontal();

					if(this.sections.Length != ability.level.Length)
					{
						this.sections = new string[ability.level.Length];
						for(int i = 0; i < this.sections.Length; i++)
						{
							this.sections[i] = (i + 1).ToString();
						}
					}

					EditorTool.SelectionGridCenter("LevelGrid", ref this.arrayIndex, this.sections, 10, 55);

					EditorTool.Separator(2);
				}
			}
			else
			{
				base.AutomationCallback(info);
			}
		}
	}
}
