
using GamingIsLove.ORKFramework;
using UnityEditor;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;

namespace GamingIsLove.ORKFramework.Editor
{
	public sealed class DefenceModifiersTab : ORKGenericAssetListTab<DefenceModifierAsset, DefenceModifierSetting>
	{
		public DefenceModifiersTab(MakinomEditorWindow parent) : base(parent)
		{
			ORK.DefenceModifiers.SetAssets(this.assetList.Assets);
		}

		public override void Reloaded()
		{
			base.Reloaded();
			ORK.DefenceModifiers.SetAssets(this.assetList.Assets);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Defence Modifiers"; }
		}

		public override string HelpText
		{
			get
			{
				return "Defence modifiers are used to influence status value changes on a percent-basis, they're assigned to combatants.\n" +
					"E.g. Sizes like small or big are defence modifiers, they're assigned to a combatant and use an attacker's modifier value.\n" +
					"'Size' would be the defence modifier, 'Small' or 'Big' are attributes of that modifier.\n" +
					"The attribute is assigned to a combatant, status value changes of abilities or items can use the defence modifiers to influence the value.\n" +
					"The attacker/user's defence modifier attribute value impacts the outcome, " +
					"e.g. 100 will do 100% of the original damage, 200 will do 200% (i.e. double damage), 50 will do 50% damage (i.e. half damage).\n" +
					"0 will completely block the damage, while anything below 0 will actually cause damage to heal (or healing to damage) the target.";
			}
		}

		public override string HelpInfo
		{
			get { return "https://orkframework.com/guide/documentation/features/attack-defence-modifiers/"; }
		}


		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			base.ShowSettings();

			DefenceModifierSetting modifier = this.CurrentSettings;
			if(modifier != null)
			{
				for(int i = 0; i < modifier.attribute.Length; i++)
				{
					ValueHelper.Limit(ref modifier.attribute[i].startValue, modifier.minValue, modifier.maxValue);
				}
			}
		}

		public override void AutomationRemoveCallback(int arrayIndex, string info)
		{
			if(info == "modifier:removed")
			{
				if(this.assetList.AssetExists(this.index))
				{
					DefenceModifierAsset asset = this.assetList.Assets[this.index];
					EditorDataHandler.Instance.SubDataRemoved(asset.GetType(), asset, arrayIndex);
				}
			}
			else
			{
				base.AutomationRemoveCallback(arrayIndex, info);
			}
		}
	}
}

