
using UnityEngine;
using System.Collections;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Components
{
	public abstract class BaseColliderZone : MonoBehaviour
	{
		protected Collider colliderComponent;

		protected Collider2D collider2DComponent;

		protected virtual Collider Collider
		{
			get
			{
				if(this.colliderComponent == null)
				{
					this.colliderComponent = this.GetComponent<Collider>();
				}
				return this.colliderComponent;
			}
		}

		protected virtual Collider2D Collider2D
		{
			get
			{
				if(this.collider2DComponent == null)
				{
					this.collider2DComponent = this.GetComponent<Collider2D>();
				}
				return this.collider2DComponent;
			}
		}

		public virtual bool IsWithin(Vector3 point)
		{
			if(this.Collider != null)
			{
				point.y = this.Collider.bounds.center.y;
				if(this.Collider.bounds.Contains(point))
				{
					point.y = this.Collider.bounds.max.y + 1;
					RaycastHit hit;
					if(this.Collider.Raycast(new Ray(point, -Vector3.up), out hit, this.Collider.bounds.size.y))
					{
						return true;
					}
				}
			}
			else if(this.Collider2D != null)
			{
				return this.Collider2D.OverlapPoint(point);
			}
			return false;
		}

		public virtual void ClosestPoint(ref Vector3 point)
		{
			if(this.Collider != null)
			{
				point = this.Collider.bounds.ClosestPoint(point);
				RaycastHit hit;
				if(this.Collider.Raycast(new Ray(point,
					VectorHelper.GetDirection(point, this.Collider.bounds.center)),
					out hit, Vector3.Distance(point, this.Collider.bounds.center)))
				{
					point = hit.point;
				}
			}
			else if(this.Collider2D != null)
			{
				point = this.Collider2D.bounds.ClosestPoint(point);
				RaycastHit2D[] hit = Physics2D.RaycastAll(point,
					VectorHelper.GetDirection(point, this.Collider2D.bounds.center),
					Vector3.Distance(point, this.Collider2D.bounds.center));
				if(hit != null)
				{
					for(int i = 0; i < hit.Length; i++)
					{
						if(hit[i].collider == this.Collider2D)
						{
							point = hit[i].point;
							break;
						}
					}
				}
			}
		}
	}
}
