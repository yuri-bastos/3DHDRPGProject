﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Combatant Highlight: Radius Scale")]
	public class RadiusCombatantHighlightCursorPrefab : MonoBehaviour, ICombatantHighlightCursorPrefab
	{
		public virtual void StartSelection(Combatant combatant)
		{
			float radius = combatant.Object.Radius;
			if(radius > 0)
			{
				this.transform.localScale = new Vector3(radius, radius, radius);
			}
			else
			{
				this.transform.localScale = Vector3.zero;
			}
		}

		public virtual void StopSelection()
		{
			this.transform.localScale = Vector3.one;
		}
	}
}
