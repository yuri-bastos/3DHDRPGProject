﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Battle/Target Raycast Cursor: Affect Range Scale")]
	public class AffectRangeScaleTargetRaycastCursorPrefab : MonoBehaviour, ITargetRaycastCursorPrefab
	{
		public virtual void StartSelection(Combatant user, BaseAction action)
		{
			bool used = false;
			TargetSettings targetSettings = TargetSettings.Get(action);
			if(targetSettings != null)
			{
				UseRange affectRange = targetSettings.affectRange.GetConditionalRange(
					user, user, action.Shortcut as IVariableSource);
				if(affectRange != null)
				{
					float range = affectRange.GetRangeValue(user);
					if(range > 0)
					{
						used = true;
						this.transform.localScale = new Vector3(range, range, range);
					}
				}
			}
			if(!used)
			{
				this.transform.localScale = Vector3.zero;
			}
		}

		public virtual void StopSelection()
		{
			this.transform.localScale = Vector3.one;
		}
	}
}
