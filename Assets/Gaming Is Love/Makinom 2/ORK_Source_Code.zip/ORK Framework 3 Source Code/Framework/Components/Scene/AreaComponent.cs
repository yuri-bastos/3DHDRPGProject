
using GamingIsLove.ORKFramework;
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework.Components
{
	[AddComponentMenu("ORK Framework/Zone/Area")]
	public class AreaComponent : BaseInteractionComponent, ISerializationCallbackReceiver
	{
		[System.NonSerialized]
		public Settings settings = new Settings();

		[SerializeField]
		[HideInInspector]
		protected ComponentDataFile serialize_setting;

		protected virtual void Reset()
		{
			this.startSettings.triggerStartSetting.isTriggerEnter = true;
		}

		public override void StartInteraction(GameObject startingObject)
		{
			if(this.settings.area.StoredAsset != null)
			{
				this.DoTurns(startingObject);
				this.CancelAutoDestroy();
				ORK.Game.SetArea(this.settings.area.StoredAsset.Settings, this.settings.show);
				this.EndCheck();
			}
		}

		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/ORKFramework/Components/AreaComponent Icon.png");
		}

		public virtual void SetAutoName()
		{
			this.name = "Area: " + (this.settings.area.StoredAsset != null ?
				this.settings.area.StoredAsset.Settings.GetName() : "-");
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public override void OnBeforeSerialize()
		{
			this.serialize_setting = this.settings.GetData().GetComponentDataFile("settings", false);
			base.OnBeforeSerialize();
		}

		public override void OnAfterDeserialize()
		{
			if(this.serialize_setting != null)
			{
				this.settings.SetData(this.serialize_setting.ToDataObject());
				this.serialize_setting = null;
			}
			base.OnAfterDeserialize();
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Area", "Select the area that will be used.")]
			public AssetSelection<AreaAsset> area = new AssetSelection<AreaAsset>();

			[EditorHelp("Show Notification", "Display the new area notification.\n" +
				"If disabled, no notification will be displayed.")]
			public bool show = true;

			[EditorHelp("Auto Name", "Automatically use the area's name as the game object's name.\n" + 
				"The game object will be named 'Area: ' + the area's name.")]
			public bool autoName = true;

			public Settings()
			{

			}
		}
	}
}
