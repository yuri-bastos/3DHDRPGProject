﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public delegate void GUIDIterate<T>(T content);

	public class GUIDCollection<T> where T : IGUID
	{
		protected Dictionary<string, T> dictionary;

		protected List<T> list;

		public GUIDCollection()
		{
			this.dictionary = new Dictionary<string, T>();
			this.list = new List<T>();
		}

		public GUIDCollection(int capacity)
		{
			this.dictionary = new Dictionary<string, T>(capacity);
			this.list = new List<T>(capacity);
		}

		public GUIDCollection(IEnumerable<T> content)
		{
			this.dictionary = new Dictionary<string, T>();
			this.list = new List<T>();

			this.AddRange(content);
		}

		public virtual void Clear()
		{
			this.dictionary.Clear();
			this.list.Clear();
		}


		/*
		============================================================================
		GUID functions
		============================================================================
		*/
		/// <summary>
		/// Creates a new GUID string not yet used in this collection.
		/// The string is formatted in 32 digits, e.g. '00000000000000000000000000000000'.
		/// </summary>
		/// <returns>The new, unused GUID string.</returns>
		public virtual string CreateGUID()
		{
			string guid = GUIDHelper.CreateGUID();
			while(this.dictionary.ContainsKey(guid))
			{
				guid = GUIDHelper.CreateGUID();
			}
			return guid;
		}

		public virtual void GUIDChanged(T content, string oldGUID)
		{
			if(this.dictionary.ContainsKey(oldGUID))
			{
				this.dictionary.Remove(oldGUID);
				this.Add(content);
			}
		}

		public virtual bool Contains(string guid)
		{
			return this.dictionary.ContainsKey(guid);
		}

		public virtual bool Contains(T content)
		{
			return content != null &&
				this.dictionary.ContainsKey(content.GUID);
		}

		public virtual T Get(string guid)
		{
			T content;
			this.dictionary.TryGetValue(guid, out content);
			return content;
		}


		/*
		============================================================================
		Add functions
		============================================================================
		*/
		public virtual void Add(T content)
		{
			if(content != null)
			{
				if(string.IsNullOrEmpty(content.GUID) ||
					this.dictionary.ContainsKey(content.GUID))
				{
					content.GUID = this.CreateGUID();
				}
				this.dictionary.Add(content.GUID, content);
				this.list.Add(content);
			}
		}

		public virtual void AddRange(IEnumerable<T> content)
		{
			if(content != null)
			{
				foreach(T tmp in content)
				{
					this.Add(tmp);
				}
			}
		}

		public virtual void AddIfNotYetAdded(T content)
		{
			if(content != null)
			{
				if(string.IsNullOrEmpty(content.GUID))
				{
					content.GUID = this.CreateGUID();
				}
				if(!this.dictionary.ContainsKey(content.GUID))
				{
					this.dictionary.Add(content.GUID, content);
					this.list.Add(content);
				}
			}
		}


		/*
		============================================================================
		Remove functions
		============================================================================
		*/
		public virtual bool Remove(T content)
		{
			if(content != null &&
				this.dictionary.ContainsKey(content.GUID))
			{
				this.dictionary.Remove(content.GUID);
				this.list.Remove(content);
				return true;
			}
			return false;
		}

		public virtual void Remove(IEnumerable<T> content)
		{
			if(content != null)
			{
				foreach(T tmp in content)
				{
					this.Remove(tmp);
				}
			}
		}

		public virtual void RemoveAt(int index)
		{
			if(index >= 0 &&
				index < this.list.Count)
			{
				this.Remove(this.list[index]);
			}
		}


		/*
		============================================================================
		Iteration functions
		============================================================================
		*/
		public virtual int Count
		{
			get { return this.list.Count; }
		}

		public virtual T this[int index]
		{
			get { return this.list[index]; }
		}

		public virtual int IndexOf(T content)
		{
			return this.list.IndexOf(content);
		}

		public virtual List<T> Values
		{
			get { return this.list; }
		}

		public virtual void Iterate(GUIDIterate<T> call)
		{
			for(int i = 0; i < this.list.Count; i++)
			{
				call(this.list[i]);
			}
		}
	}
}
