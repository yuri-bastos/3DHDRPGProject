﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class SortOption : LanguageContentInformation
	{
		[EditorHelp("Default Sorting", "Uses the default sorting settings.", "")]
		public bool isDefault = true;

		[EditorCondition("isDefault", false)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AdvancedContentSorter sorter;

		public SortOption()
		{

		}
	}
}
