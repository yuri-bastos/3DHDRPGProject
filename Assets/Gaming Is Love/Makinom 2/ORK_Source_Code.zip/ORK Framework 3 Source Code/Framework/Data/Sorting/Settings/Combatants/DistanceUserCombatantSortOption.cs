﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Distance (User)", "Sort the combatants by distance to the user (combatant).", "")]
	public class DistanceUserCombatantSortOption<T> : BaseCombatantSortOption<T> where T : IObjectSelection, new()
	{
		[EditorHelp("Ignore Height Distance", "Height differences between user and sorted combatants are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		public bool ignoreHeightDistance = false;

		[EditorHelp("Ignore Radius", "The radius of the combatants will be ignored when calculating the distance (radius is defined by 'Radius' components).", "")]
		public bool ignoreRadius = false;

		[EditorHelp("Invert Order", "Invert the sort order, i.e. the farthest combatant will be the first in the list.")]
		public bool invertOrder = false;

		[EditorTitleLabel("User (Combatant)")]
		public T user = new T();

		public DistanceUserCombatantSortOption()
		{

		}

		public override string ToString()
		{
			return "Distance(User)";
		}

		public override void Sort(List<Combatant> list, IDataCall call)
		{
			list.Sort(new CombatantDistanceSorter(this.user.GetCombatant(call), this.ignoreHeightDistance, this.ignoreRadius, this.invertOrder));
		}
	}
}
