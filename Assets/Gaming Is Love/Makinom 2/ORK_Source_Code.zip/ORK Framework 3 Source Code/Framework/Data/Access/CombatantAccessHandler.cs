﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.Makinom.Components;

namespace GamingIsLove.ORKFramework
{
	public class CombatantAccessHandler
	{
		public CombatantAccessHandler()
		{

		}

		/// <summary>
		/// Determines if certain combatant status related changes are possible.
		/// E.g. status effects causing changes, auto effects or auto unequip (equipment, AI behaviours/rulesets).
		/// </summary>
		public virtual bool HasStatusAuthority
		{
			get { return true; }
			set { }
		}

		/// <summary>
		/// Determines if the battle AI can be used.
		/// AI controlled combatants will not use actions when not used.
		/// </summary>
		public virtual bool HasBattleAIAuthority
		{
			get { return true; }
			set { }
		}

		/// <summary>
		/// Determines if the move AI can be used.
		/// </summary>
		public virtual bool HasMoveAIAuthority
		{
			get { return true; }
			set { }
		}

		/// <summary>
		/// Determines if new combatants can be created and spawned (doesn't impact the player).
		/// E.g. checked by 'Combatant Spawners', 'Add Combatant' and 'Battle' components when creating new combatants.
		/// </summary>
		public virtual bool HasSpawnCreationAuthority
		{
			get { return true; }
			set { }
		}


		/*
		============================================================================
		Instance functions
		============================================================================
		*/
		/// <summary>
		/// Creates a new instance of a combatant and initializes it with the combatant's start levels and class.
		/// </summary>
		/// <param name="setting">The settings of the combatant that will be created.</param>
		/// <param name="group">The group the combatant will join.</param>
		/// <returns>A new combatant instance initialized with the combatant's start levels and class.</returns>
		public virtual Combatant CreateInstance(CombatantSetting setting, Group group, bool showNotification, bool showConsole)
		{
			Combatant combatant = setting.Create(group, showNotification, showConsole);
			combatant.Init();
			return combatant;
		}

		/// <summary>
		/// Creates a new instance of a combatant and initializes it with the passed on data.
		/// </summary>
		/// <param name="setting">The settings of the combatant that will be created.</param>
		/// <param name="group">The group the combatant will join.</param>
		/// <param name="level">The base level used to initialize the combatant.</param>
		/// <param name="classLevel">The class level used to initialize the combatant.</param>
		/// <param name="startClass">The class the combatant will have.</param>
		/// <param name="loadGame"><c>true</c> if this comes from loading a game.</param>
		/// <param name="learnAbilities"><c>true</c> if the combatant should learn abilities for the level.</param>
		/// <param name="useStartInventory"><c>true</c> if the combatant should receive the defined start inventory.</param>
		/// <param name="useStartEquipment"><c>true</c> if the combatant should receive the defined start equipment.</param>
		/// <param name="useInitSchematic"><c>true</c> if the combatant should use the init schematic.</param>
		/// <param name="useStatusEffects"><c>true</c> if the combatant should use auto status effects when initialized.</param>
		/// <returns>A new combatant instance initialized with the passed on data.</returns>
		public virtual Combatant CreateInstance(CombatantSetting setting, Group group, bool showNotification, bool showConsole,
			int level, int classLevel, Class startClass, bool loadGame,
			bool learnAbilities, bool useStartInventory, bool useStartEquipment,
			bool useInitSchematic, bool useStatusEffects)
		{
			Combatant combatant = setting.Create(group, showNotification, showConsole);
			combatant.Init(level, classLevel, startClass, loadGame,
				learnAbilities, useStartInventory, useStartEquipment,
				useInitSchematic, useStatusEffects);
			return combatant;
		}


		/*
		============================================================================
		Spawn functions
		============================================================================
		*/
		/// <summary>
		/// Destroys a combatant's prefab.
		/// </summary>
		/// <param name="combatant">The combatant.</param>
		public virtual void DestroyPrefab(Combatant combatant)
		{
			combatant.Object.DestroyPrefab();
		}

		/// <summary>
		/// Spawns a combatant's prefab at the last known position.
		/// </summary>
		/// <param name="combatant">The combatant.</param>
		public virtual void SpawnAtLastPosition(Combatant combatant)
		{
			combatant.Object.SpawnAtLastPosition();
		}

		/// <summary>
		/// Spawns a combatant's prefab at a spawn point.
		/// </summary>
		/// <param name="combatant">The combatant.</param>
		/// <param name="spawnPoint">The spawn point that will be used.</param>
		/// <param name="offset">The offset added to the spawn position.</param>
		public virtual void Spawn(Combatant combatant, SpawnPoint spawnPoint, Vector3 offset)
		{
			combatant.Object.Spawn(spawnPoint, offset);
		}

		/// <summary>
		/// Spawns a combatant's prefab.
		/// </summary>
		/// <param name="combatant">The combatant.</param>
		/// <param name="position">The position the combatant is spawned at.</param>
		/// <param name="setRotation"><c>true</c> to set the rotation.</param>
		/// <param name="rotation">The rotation</param>
		/// <param name="setScale"><c>true</c> to set the scale.</param>
		/// <param name="scale">The scale that will be used.</param>
		public virtual void Spawn(Combatant combatant, Vector3 position, bool setRotation, Vector3 rotation, bool setScale, Vector3 scale)
		{
			combatant.Object.Spawn(position, setRotation, rotation, setScale, scale);
		}

		/// <summary>
		/// Places a combatant's game object.
		/// </summary>
		/// <param name="combatant">The combatant.</param>
		/// <param name="position">The position the combatant is placed at.</param>
		/// <param name="setRotation"><c>true</c> to set the rotation.</param>
		/// <param name="rotation">The rotation</param>
		/// <param name="setScale"><c>true</c> to set the scale.</param>
		/// <param name="scale">The scale that will be used.</param>
		public virtual void PlaceAt(Combatant combatant, Vector3 position, bool setRotation, Vector3 rotation, bool setScale, Vector3 scale)
		{
			combatant.Object.PlaceAt(position, setRotation, rotation, setScale, scale);
		}


		/*
		============================================================================
		Status value functions
		============================================================================
		*/
		/// <summary>
		/// Sets the value of a status value of the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="valueID">The ID/index of the status value.</param>
		/// <param name="newValue">The new value that will be used.</param>
		/// <param name="isCritical"><c>true</c> if this is a critical value change.</param>
		/// <param name="ignoreLimit"><c>true</c> if the change damage/refresh limit is ignored.</param>
		/// <param name="ignoreBarrier"><c>true</c> if the change should ignore barrier status values.</param>
		/// <param name="showFlyingText"><c>true</c> if the change should display flying texts.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <param name="source">The source of the value change (e.g. combatant causing the change).</param>
		public virtual void SetStatusValue(Combatant user, int valueID,
			int newValue, bool isCritical, bool ignoreLimit, bool ignoreBarrier,
			bool showFlyingText, bool showConsole, StatusValueChangeSource source)
		{
			user.Status[valueID].SetValue(newValue, isCritical, ignoreLimit, ignoreBarrier,
				showFlyingText, showConsole, source);
		}

		/// <summary>
		/// Adds a value to a status value of the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="valueID">The ID/index of the status value.</param>
		/// <param name="addValue">The value that will be added.</param>
		/// <param name="isCritical"><c>true</c> if this is a critical value change.</param>
		/// <param name="checkDeath"><c>true</c> if the combatant should check for death.</param>
		/// <param name="checkLevelUp"><c>true</c> if the combatant should check for level up.</param>
		/// <param name="ignoreLimit"><c>true</c> if the change damage/refresh limit is ignored.</param>
		/// <param name="ignoreBarrier"><c>true</c> if the change should ignore barrier status values.</param>
		/// <param name="showFlyingText"><c>true</c> if the change should display flying texts.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <param name="source">The source of the value change (e.g. combatant causing the change).</param>
		public virtual void AddStatusValue(Combatant user, int valueID,
			int addValue, bool isCritical, bool checkDeath, bool checkLevelUp,
			bool ignoreLimit, bool ignoreBarrier, bool showFlyingText, bool showConsole, StatusValueChangeSource source)
		{
			user.Status[valueID].AddValue(addValue, isCritical, checkDeath, checkLevelUp,
				ignoreLimit, ignoreBarrier, showFlyingText, showConsole, source);
		}

		/// <summary>
		/// Sets the base value of a status value of the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="valueID">The ID/index of the status value.</param>
		/// <param name="newValue">The new value that will be used.</param>
		public virtual void SetBaseStatusValue(Combatant user, int valueID, int newValue)
		{
			user.Status[valueID].SetBaseValue(newValue);
		}

		/// <summary>
		/// Adds a value to the base value of a status value of the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="valueID">The ID/index of the status value.</param>
		/// <param name="addValue">The value that will be added.</param>
		public virtual void AddBaseStatusValue(Combatant user, int valueID, int addValue)
		{
			user.Status[valueID].AddBaseValue(addValue);
		}

		/// <summary>
		/// Sets the 'Consumable' type status values of a combatant to their maximum value.
		/// </summary>
		/// <param name="user">The combatant that will be used.</param>
		/// <param name="revive"><c>true</c> if a dead combatant should be revived.</param>
		public virtual void Regenerate(Combatant user, bool revive)
		{
			user.Status.Regenerate(revive);
		}


		/*
		============================================================================
		Ability functions
		============================================================================
		*/
		/// <summary>
		/// Lets the user learn an ability.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="isGroupAbility"><c>true</c> if the ability should be learned by the entire group.</param>
		/// <param name="ability">The ability.</param>
		/// <param name="level">The level of the ability.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <returns><c>true</c> if the ability was learned.</returns>
		public virtual bool LearnAbility(Combatant user, bool isGroupAbility,
			Ability ability, int level, bool showNotification, bool showConsole)
		{
			if(isGroupAbility)
			{
				return user.Group.Abilities.Learn(ability, level, showNotification, showConsole);
			}
			else
			{
				return user.Abilities.Learn(ability, level, showNotification, showConsole);
			}
		}

		/// <summary>
		/// Lets the user learn an ability.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="isGroupAbility"><c>true</c> if the ability is learned as a group ability.</param>
		/// <param name="ability">The ability that will be learned.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <returns><c>true</c> if the ability was learned.</returns>
		public virtual bool LearnAbility(Combatant user, bool isGroupAbility,
			AbilityShortcut ability, bool showNotification, bool showConsole)
		{
			if(isGroupAbility)
			{
				return user.Group.Abilities.Learn(ability, showNotification, showConsole);
			}
			else
			{
				return user.Abilities.Learn(ability, showNotification, showConsole);
			}
		}

		/// <summary>
		/// Lets the user forget an ability.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="isGroupAbility"><c>true</c> if a group ability is forgotten.</param>
		/// <param name="ability">The ability.</param>
		/// <param name="showNotification"><c>true</c> if a notification should be displayed.</param>
		/// <param name="showConsole"><c>true</c> if a console line should be added.</param>
		/// <returns><c>true</c> if the ability was forgotten.</returns>
		public virtual bool ForgetAbility(Combatant user, bool isGroupAbility,
			Ability ability, bool showNotification, bool showConsole)
		{
			if(isGroupAbility)
			{
				return user.Group.Abilities.Forget(ability, showNotification, showConsole);
			}
			else
			{
				return user.Abilities.Forget(ability, showNotification, showConsole);
			}
		}


		/*
		============================================================================
		Equipment functions
		============================================================================
		*/
		/// <summary>
		/// Equips an equipment on a combatant.
		/// </summary>
		/// <param name="user">The combatant that will equip the equipment.</param>
		/// <param name="equipmentSlot">The equipment slot it will be equipped on.
		/// Use <c>-1</c> if a matching equipment slot should be searched.</param>
		/// <param name="equip">The <c>EquipShortcut</c> that will be equipped.</param>
		/// <param name="fromInventory">The combatant who's inventory should remove the equipment.</param>
		/// <param name="unequipToInventory">The combatant who's inventory should add equipment currently equipped on the used equipment slot.</param>
		/// <param name="reset"><c>true</c> if the user's status system should be reset (i.e. checking for bonuses, etc.).</param>
		/// <returns><c>true</c> if the equipment was equipped.</returns>
		public virtual bool Equip(Combatant user, EquipmentSlotSetting equipmentSlot, EquipShortcut equip,
			Combatant fromInventory, Combatant unequipToInventory, bool reset)
		{
			return user.Equipment.Equip(equipmentSlot, equip, fromInventory, unequipToInventory, reset);
		}

		/// <summary>
		/// Unequips all currently equipped equipment of the user.
		/// </summary>
		/// <param name="user">The combatant that will unequip the equipment.</param>
		/// <param name="toInventory">The combatant who's inventory should add the unequipped equipment.</param>
		public virtual void UnequipAll(Combatant user, Combatant toInventory)
		{
			user.Equipment.UnequipAll(toInventory);
		}

		/// <summary>
		/// Unequips an equipment from the user.
		/// </summary>
		/// <param name="user">The combatant that will unequip the equipment.</param>
		/// <param name="equip">The equipment that will be unequiped.</param>
		/// <param name="toInventory">The combatant who's inventory should add the unequipped equipment.</param>
		public virtual void Unequip(Combatant user, EquipShortcut equip, Combatant toInventory)
		{
			user.Equipment.Unequip(equip, toInventory);
		}

		/// <summary>
		/// Unequips equipment currently equipped on a defined equipment slot of the user.
		/// </summary>
		/// <param name="user">The combatant that will unequip the equipment.</param>
		/// <param name="equipmentSlot">The equipment slot that will be unequipped.</param>
		/// <param name="toInventory">The combatant who's inventory should add the unequipped equipment.</param>
		/// <param name="reset"><c>true</c> if the user's status system should be reset (i.e. checking for bonuses, etc.).</param>
		/// <param name="force"><c>true</c> if unequipping should be forced.</param>
		public virtual void Unequip(Combatant user, EquipmentSlotSetting equipmentSlot, Combatant toInventory, bool reset, bool force)
		{
			user.Equipment.Unequip(equipmentSlot, toInventory, reset, force);
		}


		/*
		============================================================================
		AI functions
		============================================================================
		*/
		/// <summary>
		/// Equips an AI behaviour on the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="aiBehaviour">The AI behaviour.</param>
		/// <param name="slotIndex">The index of the AI behaviour slot.</param>
		/// <param name="toInventory"><c>true</c> if the currently equipped AI behaviour should be returned to the inventory.</param>
		/// <param name="fromInventory"><c>true</c> if the AI behaviour should be taken from the inventory.</param>
		/// <param name="notifyChange"><c>true</c> if the listeners should be notified of the change.</param>
		public virtual void EquipAIBehaviour(Combatant user, AIBehaviour aiBehaviour, int slotIndex,
			bool toInventory, bool fromInventory, bool notifyChange)
		{
			user.AI.EquipAIBehaviour(aiBehaviour, slotIndex, toInventory, fromInventory, notifyChange);
		}

		/// <summary>
		/// Unequips an AI behaviour from the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="slotIndex">The index of the AI behaviour slot.</param>
		/// <param name="toInventory"><c>true</c> if it should be returned to the inventory.</param>
		/// <param name="notifyChange"><c>true</c> if the listeners should be notified of the change.</param>
		public virtual void UnequipAIBehaviourSlot(Combatant user, int slotIndex, bool toInventory, bool notifyChange)
		{
			user.AI.UnequipAIBehaviourSlot(slotIndex, toInventory, notifyChange);
		}

		/// <summary>
		/// Equips an AI ruleset on the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="aiRuleset">The AI ruleset.</param>
		/// <param name="slotIndex">The index of the AI behaviour slot.</param>
		/// <param name="toInventory"><c>true</c> if the currently equipped AI ruleset should be returned to the inventory.</param>
		/// <param name="fromInventory"><c>true</c> if the AI ruleset should be taken from the inventory.</param>
		/// <param name="notifyChange"><c>true</c> if the listeners should be notified of the change.</param>
		public virtual void EquipAIRuleset(Combatant user, AIRuleset aiRuleset, int slotIndex,
			bool toInventory, bool fromInventory, bool notifyChange)
		{
			user.AI.EquipAIRuleset(aiRuleset, slotIndex, toInventory, fromInventory, notifyChange);
		}

		/// <summary>
		/// Unequips an AI ruleset from the user.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="slotIndex">The index of the AI ruleset slot.</param>
		/// <param name="toInventory"><c>true</c> if it should be returned to the inventory.</param>
		/// <param name="notifyChange"><c>true</c> if the listeners should be notified of the change.</param>
		public virtual void UnequipAIRulesetSlot(Combatant user, int slotIndex, bool toInventory, bool notifyChange)
		{
			user.AI.UnequipAIRulesetSlot(slotIndex, toInventory, notifyChange);
		}


		/*
		============================================================================
		Class functions
		============================================================================
		*/
		/// <summary>
		/// Changes if a combatant's class slot is available or not.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="slotSettings">The class slot.</param>
		/// <param name="available"><c>true</c> if the slot is available, otherwise <c>false</c>.</param>
		/// <param name="showNotification"><c>true</c> if notifications should be shown, otherwise <c>false</c>.</param>
		/// <param name="showConsole"><c>true</c> if console texts should be shown, otherwise <c>false</c>.</param>
		public virtual void ChangeSlotAvailable(Combatant user, ClassSlotSetting slotSettings, bool available, bool showNotification, bool showConsole)
		{
			user.Class.ChangeSlotAvailable(slotSettings, available, showNotification, showConsole);
		}

		/// <summary>
		/// Equips a class on a class slot.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="slotSettings">The class slot.</param>
		/// <param name="settings">The class.</param>
		/// <returns><c>true</c> if the class was equipped.</returns>
		public virtual bool EquipClass(Combatant user, ClassSlotSetting slotSettings, Class settings)
		{
			return user.Class.Equip(slotSettings, settings);
		}

		/// <summary>
		/// Equips a class on the first free class slot.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="slotSettings">The class slot.</param>
		/// <param name="settings">The class.</param>
		/// <returns><c>true</c> if the class was equipped.</returns>
		public virtual bool EquipClass(Combatant user, Class settings)
		{
			return user.Class.Equip(settings);
		}

		/// <summary>
		/// Unequips a class slot.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="slotSettings">The class slot.</param>
		public virtual void UnequipClass(Combatant user, ClassSlotSetting slotSettings)
		{
			user.Class.Unequip(slotSettings);
		}

		/// <summary>
		/// Unequips a class slot.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="slotSettings">The class slot.</param>
		public virtual void UnequipClass(Combatant user, Class settings)
		{
			user.Class.Unequip(settings);
		}

		/// <summary>
		/// Adds a class to a combatant.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="settings">The class.</param>
		/// <param name="level">The class level.</param>
		/// <param name="showNotification"><c>true</c> if notifications should be shown, otherwise <c>false</c>.</param>
		/// <param name="showConsole"><c>true</c> if console texts should be shown, otherwise <c>false</c>.</param>
		public virtual void AddClass(Combatant user, Class settings, int level, bool showNotification, bool showConsole)
		{
			user.Class.AddClass(settings, level, showNotification, showConsole);
		}

		/// <summary>
		/// Removes a class from a combatant.
		/// </summary>
		/// <param name="user">The user combatant.</param>
		/// <param name="settings">The class.</param>
		/// <param name="showNotification"><c>true</c> if notifications should be shown, otherwise <c>false</c>.</param>
		/// <param name="showConsole"><c>true</c> if console texts should be shown, otherwise <c>false</c>.</param>
		public virtual void RemoveClass(Combatant user, Class settings, bool showNotification, bool showConsole)
		{
			user.Class.RemoveClass(settings, showNotification, showConsole);
		}


		/*
		============================================================================
		Research functions
		============================================================================
		*/
		/// <summary>
		/// Starts research on a research item.
		/// </summary>
		/// <param name="researchItem">The research item.</param>
		public virtual void StartResearch(ResearchItem researchItem)
		{
			researchItem.StartResearch();
		}

		/// <summary>
		/// Cancels research on a research item.
		/// </summary>
		/// <param name="researchItem">The research item.</param>
		public virtual void CancelResearch(ResearchItem researchItem)
		{
			researchItem.CancelResearch();
		}


		/*
		============================================================================
		State functions
		============================================================================
		*/
		/// <summary>
		/// Checks if a combatant's aggression state is changed due to an aggression of another combatant.
		/// Also causes the move AI to react to damage in case it's a damage aggression type.
		/// </summary>
		/// <param name="combatant">The combatant who's checked.</param>
		/// <param name="aggressionType">The aggression type that is checked for.</param>
		/// <param name="origin">The combatant who's the origin of the aggression.</param>
		public virtual void CheckAggressive(Combatant combatant, AggressionType aggressionType, Combatant origin)
		{
			combatant.CheckAggressive(aggressionType, origin);
		}

		/// <summary>
		/// Adds an attacker to a combatant's attacked by list.
		/// </summary>
		/// <param name="combatant">The combatant who's list is changed.</param>
		/// <param name="attacker">The attacker.</param>
		/// <param name="addFaction"><c>true</c> if the attacker's faction should be recorded as well.</param>
		public virtual void SetAttackedBy(Combatant combatant, Combatant attacker, bool addFaction)
		{
			combatant.Battle.SetAttackedBy(attacker, addFaction);
		}

		/// <summary>
		/// Removes an attacker from a combatant's attacked by list.
		/// </summary>
		/// <param name="combatant">The combatant who's list is changed.</param>
		/// <param name="attacker">The attacker</param>
		/// <param name="removeFaction"><c>true</c> if the combatant's faction should be removed (in case no other faction membe attacked the combatant).</param>
		public virtual void RemoveAttackedBy(Combatant combatant, Combatant attacker, bool removeFaction)
		{
			combatant.Battle.RemoveAttackedBy(attacker, removeFaction);
		}

		/// <summary>
		/// Clears a combatant's attacked by list.
		/// </summary>
		/// <param name="combatant">The combatant who's list is cleared.</param>
		public virtual void ClearAttackedBy(Combatant combatant)
		{
			combatant.Battle.ClearAttackedBy();
		}

		/// <summary>
		/// Sets a combatant's killed by mark to another combatant.
		/// </summary>
		/// <param name="combatant">The combatant.</param>
		/// <param name="attacker">The attacker.</param>
		public virtual void SetKilledBy(Combatant combatant, Combatant attacker)
		{
			combatant.Battle.SetKilledBy(attacker);
		}
	}
}
