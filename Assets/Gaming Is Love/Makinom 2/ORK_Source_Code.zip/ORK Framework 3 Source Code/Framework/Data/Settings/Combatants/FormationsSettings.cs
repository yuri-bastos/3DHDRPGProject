﻿
using UnityEngine;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class FormationsSettings : GenericAssetListSettings<FormationAsset, Formation>
	{
		public FormationsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Formations"; }
		}
	}
}
