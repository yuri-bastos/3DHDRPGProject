﻿
using UnityEngine;
using GamingIsLove.ORKFramework.UI;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;

namespace GamingIsLove.ORKFramework
{
	public class QuantitySelectionsSettings : BaseSettings
	{
		// default quantity selections
		[EditorFoldout("Default Quantity Selections", "Define the default quantity selection options.", "",
			"Remove Selection", "Used when removing items from the inventory.", "")]
		[EditorEndFoldout]
		public QuantityDefault quantityRemove = new QuantityDefault();

		[EditorFoldout("Drop Selection", "Used when dropping items from the inventory into the world.")]
		[EditorEndFoldout]
		public QuantityDefault quantityDrop = new QuantityDefault();

		[EditorFoldout("Give Selection", "Used when giving items to another combatant, inventory or item box.")]
		[EditorEndFoldout]
		public QuantityDefault quantityGive = new QuantityDefault();

		[EditorFoldout("Buy Selection", "Used when buying items from a shop.")]
		[EditorEndFoldout]
		public QuantityDefault quantityBuy = new QuantityDefault();

		[EditorFoldout("Sell Quantity", "Used when selling items to a shop.")]
		[EditorEndFoldout(2)]
		public QuantityDefault quantitySell = new QuantityDefault();

		public QuantitySelectionsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Quantity Selections"; }
		}
	}
}
