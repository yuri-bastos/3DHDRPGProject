
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class LogTextsSettings : GenericAssetListSettings<LogTextAsset, LogText>
	{
		public LogTextsSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Log Texts"; }
		}


		/*
		============================================================================
		Log functions
		============================================================================
		*/
		public List<LogTextAsset> GetLogTexts(Log log)
		{
			List<LogTextAsset> list = new List<LogTextAsset>();

			for(int i = 0; i < this.assets.Count; i++)
			{
				if(this.assets[i].Settings.log.Is(log))
				{
					list.Add(this.assets[i]);
				}
			}

			return list;
		}
	}
}
