﻿
using UnityEngine;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ActionCombosSettings : GenericAssetListSettings<ActionComboAsset, ActionComboSettings>
	{
		public ActionCombosSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
			this.CreateGUIDLookup();
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Action Combos"; }
		}
	}
}
