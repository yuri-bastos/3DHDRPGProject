﻿
using UnityEngine;
using GamingIsLove.ORKFramework.UI;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public enum ShortcutOncePerListMode { None, Prevent, Remove }

	public class ShortcutSettings : BaseSettings
	{
		[EditorHelp("Shortcut List Count", "The number of available shortcut lists of a combatant or class.\n" +
			"Each list consists of a variable amount of slots (index based). Lists can be switched using schematics.\n" +
			"Combatants and classes can optionally override the shortcut list count.", "")]
		[EditorFoldout("Shortcut Settings", "Shortcuts are used to quickly use items or abilities, or equip equipment.\n" +
			"They can be used via control maps or 'Combatant' type HUDs with shortcut elements.\n" +
			"Shortcuts are organized in lists, each list consists of a variable amount of slots (index based). " +
			"Only the currently active list can be used - switching between lists can be done using schematics, " +
			"e.g. with a global machine called when pressing an input key.\n" +
			"Combatants can optionally use their own shortcut lists, disabling the class shortcut lists.", "")]
		[EditorLimit(0, false)]
		public int shortcutListCount = 1;

		[EditorHelp("Group Shortcut List Count", "The number of available group shortcut lists.\n" +
			"Each list consists of a variable amount of slots (index based). " +
			"Lists can be changed using schematics.", "")]
		[EditorLimit(0, false)]
		public int groupShortcutListCount = 1;

		[EditorHelp("Keep Unavailable", "Keep shortcuts that are currently unavailable.\n" +
			"A shortcut becomes unavailable if the underlying item or action is no longer available, " +
			"e.g. after equipping an equipment using the last item of that kind.\n" +
			"If disabled, these shortcuts will be overridden or removed.", "")]
		public bool keepUnavailableShortcuts = true;

		[EditorHelp("Show Unavailable", "Unavailable shortcuts will be displayed in 'Shortcut' HUD elements.", "")]
		[EditorIndent]
		[EditorCondition("keepUnavailableShortcuts", true)]
		[EditorEndCondition]
		public bool showUnavailableShortcuts = false;

		[EditorHelp("Only Same Item Instance", "Only the same, matching instance of an item will be kept in shortcut slots.\n" +
			"If disabled, a matching item will be selected from the inventory instead.")]
		public bool onlySameItemInstance = false;

		[EditorHelp("Only Same Equipment Instance", "Only the same, matching instance of an equipment will be kept in shortcut slots.\n" +
			"If disabled, a matching equipment will be selected from the inventory instead.")]
		public bool onlySameEquipmentInstance = false;

		[EditorHelp("Only Same Currency Instance", "Only the same, matching instance of a currency will be kept in shortcut slots.\n" +
			"If disabled, a matching currency will be selected from the inventory instead.")]
		public bool onlySameCurrencyInstance = false;

		[EditorHelp("2nd Call Deactivate", "An active shortcut (i.e. during target selection) is deactivated when used a 2nd time.\n" +
			"This is possible for control maps and click use in shortcut HUDs.", "")]
		public bool deactivateOn2ndCall = false;

		[EditorHelp("HUD Check Timeout (s)", "The time in seconds between checking a shortcut's useable state in HUDs.\n" +
			"The check includes searching for available targets, which can have an impact on performance " +
			"(especially during grid battles) when used each frame (i.e. a timeout of 0)", "")]
		[EditorSeparator]
		[EditorLimit(0.0f, false)]
		public float hudCheckTimeout = 0.1f;

		// once per list
		[EditorHelp("Once Per List Mode", "Select if and how assigning the same shortcut is limited to once per shortcut list:\n" +
			"- None: No limitation.\n" +
			"- Prevent: The same shortcut can't be added again.\n" +
			"- Remove: The same shortcut is added, removing the other assigned slot.")]
		[EditorSeparator]
		[EditorTitleLabel("Assign Once Per List")]
		[EditorLabel("Optionally prevent the same shortcut from being assigned more than once per shortcut list.\n" +
			"Please note that shortcuts can differ, even if they represent the same thing - " +
			"e.g. an item can be different from the same item when it has other item variable values.")]
		public ShortcutOncePerListMode oncePerListMode = ShortcutOncePerListMode.None;

		[EditorHelp("Abilities", "The same ability can only be assigned once per shortcut list.")]
		[EditorCondition("oncePerListMode", ShortcutOncePerListMode.None)]
		[EditorElseCondition]
		public bool oncePerListAbilities = false;

		[EditorHelp("Items", "The same item can only be assigned once per shortcut list.")]
		public bool oncePerListItems = false;

		[EditorHelp("Equipment", "The same equipment can only be assigned once per shortcut list.")]
		public bool oncePerListEquipment = false;

		[EditorHelp("Currencies", "The same currency can only be assigned once per shortcut list.")]
		public bool oncePerListCurrencies = false;

		[EditorHelp("Special Actions", "The same special action (e.g. defend, escape, etc.) can only be assigned once per shortcut list.")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public bool oncePerListSpecialActions = false;

		// slot content
		[EditorHelp("Slot Index Display", "Offset added to the index of the slot when displayed in the slot content ('<slotindex>').\n" +
			"E.g. if you want to display slot index 0 as index 1, set this setting to 1.", "")]
		[EditorFoldout("Slot Content Information", "The default content information used for AI ruleset slots.")]
		public int slotIndexDisplay = 0;

		[EditorFoldout("Default Slot Content", "The default content information used for shortcut slots.\n" +
			"You can optionally define content information for individual shortcut slot lists and shortcut slots.")]
		[EditorEndFoldout]
		[EditorLabel("<slotindex> = slot index")]
		public LanguageContentInformation defaultSlotContent = new LanguageContentInformation("Slot <slotindex>");

		[EditorFoldout("List Content", "Optionally define separate content information for defined shortcut lists (by shortcut list index).")]
		[EditorEndFoldout]
		[EditorArray("Add List Content", "Add content information for a defined shortcut list.", "",
			"Remove", "Remove this list content.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"List Content", "Define the content and shortcut list it'll be used for.", ""
			})]
		public ShortcutListContentInformation[] listContent = new ShortcutListContentInformation[0];

		[EditorFoldout("Slot Content", "Optionally define separate content information for defined shortcut slots (by shortcut list index and slot index).")]
		[EditorEndFoldout(2)]
		[EditorArray("Add Slot Content", "Add content information for a defined shortcut slot.", "",
			"Remove", "Remove this slot content.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Slot Content", "Define the content and shortcut slot it'll be used for.", ""
			})]
		public ShortcutSlotContentInformation[] slotContent = new ShortcutSlotContentInformation[0];



		// default shortcut assignments
		[EditorFoldout("Default Shortcut Assignments", "Shortcuts can be either bound to the combatant or the combatant's class " +
			"(i.e. the shortcuts are changed when changing the class).\n" +
			"The default shortcut assignments are set up when a combatant or class is first used by a combatant. " +
			"Default shortcuts are used by all combatants/classes, each combatant or class can " +
			"add to or replace the default shortcuts.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Shortcut", "Adds a default shortcut.", "",
			"Remove", "Removes this shortcut.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Shortcut Assignment", "The selected shortcut slot will be assigned with the defined shortcut.", ""
		})]
		public ShortcutSlotAssignment[] defaultShortcut = new ShortcutSlotAssignment[0];


		// auto add shortcuts
		[EditorFoldout("Default Auto Add Slots", "Shortcuts can be added automatically to shortcut slots upon getting them.\n" +
			"This is used when a combatant learns a new ability or gets a new item, equipment or currency.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Auto Add Slots", "Adds default auto add slots.", "",
			"Remove", "Removes these auto add slots.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Auto Add Slots", "Define the slot range and used shortcuts that will be added automatically.", ""
		})]
		public AutoShortcutSlots[] autoAddShortcuts = new AutoShortcutSlots[0];


		// auto arrange shortcuts
		[EditorFoldout("Default Auto Arrange Slots", "Shortcuts can be arranged automatically to fill empty slots when removing shortcuts.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Auto Arrange Slots", "Adds default auto arrange slots.", "",
			"Remove", "Removes these auto arrange slots.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Auto Arrange Slots", "Define the slot range and used shortcuts that will be arranged automatically.", ""
		})]
		public AutoShortcutSlots[] autoArrangeShortcuts = new AutoShortcutSlots[0];


		// default UI
		[EditorFoldout("Default UI Settings", "Define the default setup used by shortcuts in UI (e.g. HUDs displaying shortcut slots).", "",
			"Default Empty UI", "The default setup used to show empty shortcut slots.", "")]
		[EditorEndFoldout]
		public UIShortcutSettings defaultEmptyUI = new UIShortcutSettings();

		[EditorFoldout("Default Shortcut UI", "The default setup used by all shortcuts that don't have any other UI setup.", "")]
		[EditorEndFoldout]
		public UIShortcutSettings defaultUI = new UIShortcutSettings();

		// ability
		[EditorHelp("Own Ability UI", "Use a different UI setup for abilities.")]
		[EditorFoldout("Default Ability UI", "The default setup used by abilities.\n" +
			"Each ability can optionally override this.")]
		public bool ownAbilityUI = false;

		[EditorEndFoldout]
		[EditorCondition("ownAbilityUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings abilityUI;

		// item
		[EditorHelp("Own Item UI", "Use a different UI setup for items.")]
		[EditorFoldout("Default Item UI", "The default setup used by items.\n" +
			"Each item can optionally override this.")]
		public bool ownItemUI = false;

		[EditorEndFoldout]
		[EditorCondition("ownItemUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings itemUI;

		// equipment
		[EditorHelp("Own Equipment UI", "Use a different UI setup for equipment.")]
		[EditorFoldout("Default Equipment UI", "The default setup used by equipment.\n" +
			"Each equipment can optionally override this.")]
		public bool ownEquipmentUI = false;

		[EditorEndFoldout]
		[EditorCondition("ownEquipmentUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings equipmentUI;

		// currency
		[EditorHelp("Own Currency UI", "Use a different UI setup for currencies.")]
		[EditorFoldout("Default Currency UI", "The default setup used by currencies.\n" +
			"Each currency can optionally override this.")]
		public bool ownCurrencyUI = false;

		[EditorEndFoldout]
		[EditorCondition("ownCurrencyUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings currencyUI;

		// AI behaviour
		[EditorHelp("Own AI Behaviour UI", "Use a different UI setup for AI behaviours.")]
		[EditorFoldout("Default AI Behaviour UI", "The default setup used by AI behaviours.\n" +
			"Each AI behaviour can optionally override this.")]
		public bool ownAIBehaviourUI = false;

		[EditorEndFoldout]
		[EditorCondition("ownAIBehaviourUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings aiBehaviourUI;

		// AI ruleset
		[EditorHelp("Own AI Ruleset UI", "Use a different UI setup for AI rulesets.")]
		[EditorFoldout("Default AI Ruleset UI", "The default setup used by AI rulesets.\n" +
			"Each AI ruleset can optionally override this.")]
		public bool ownAIRulesetUI = false;

		[EditorEndFoldout]
		[EditorCondition("ownAIRulesetUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings aiRulesetUI;

		// crafting recipe
		[EditorHelp("Own Crafting Recipe UI", "Use a different UI setup for crafting recipes.")]
		[EditorFoldout("Default Crafting Recipe UI", "The default setup used by crafting recipes.\n" +
			"Each crafting recipe can optionally override this.")]
		public bool ownCraftingRecipeUI = false;

		[EditorEndFoldout]
		[EditorCondition("ownCraftingRecipeUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings craftingRecipeUI;

		// class
		[EditorHelp("Own Class UI", "Use a different UI setup for classes.")]
		[EditorFoldout("Default Class UI", "The default setup used by classes.\n" +
			"Each class can optionally override this.")]
		public bool ownClassUI = false;

		[EditorEndFoldout(2)]
		[EditorCondition("ownClassUI", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public UIShortcutSettings classUI;

		public ShortcutSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Shortcut Settings"; }
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual string GetFormattedSlotIndex(int index)
		{
			return ORK.TextDisplaySettings.numberFormatting.FormatInt(index + this.slotIndexDisplay);
		}

		public virtual LanguageContentInformation GetSlotContent(int listIndex, int slotIndex)
		{
			// slots
			for(int i = 0; i < this.slotContent.Length; i++)
			{
				if((this.slotContent[i].listIndex == -1 ||
						this.slotContent[i].listIndex == listIndex) &&
					this.slotContent[i].index == slotIndex)
				{
					return this.slotContent[i].content;
				}
			}
			// lists
			for(int i = 0; i < this.listContent.Length; i++)
			{
				if(this.listContent[i].listIndex == listIndex)
				{
					return this.listContent[i].content;
				}
			}
			// default
			return this.defaultSlotContent;
		}

		public virtual void ReplaceSlotContent(UIText text, ShortcutSlotOrigin origin)
		{
			if(origin != null)
			{
				this.ReplaceSlotContent(text, origin.ListIndex, origin.SlotIndex);
			}
			else
			{
				text.ReplaceContent(null,
					"<slotname>", "<slotshortname>", "<slotdescription>", "<sloticon>", "<slotcustomcontent=",
					"", "", "", "", "");
				text.Replace("<slotindex>", "");
			}
		}

		public virtual void ReplaceSlotContent(UIText text, int listIndex, int slotIndex)
		{
			text.ReplaceContent(this.GetSlotContent(listIndex, slotIndex),
				"<slotname>", "<slotshortname>", "<slotdescription>", "<sloticon>", "<slotcustomcontent=",
				"", "", "", "", "");
			text.Replace("<slotindex>", this.GetFormattedSlotIndex(slotIndex));
		}
	}
}
