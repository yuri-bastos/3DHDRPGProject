﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class QuestSettings : BaseSettings
	{
		// quest settings
		[EditorHelp("Active Quests", "Define the number of quests that can be active at the same time.\n" +
			"If the number of active quests is succeeded (e.g. by activating an inactive quest or adding a new quest), " +
			"one of the currently active quests will be set inactive.", "")]
		[EditorFoldout("Quest Settings", "The basic quest settings are defined here.", "")]
		[EditorLimit(1, false)]
		public int activeQuests = 5;

		[EditorHelp("Display Initial Tasks", "Display the notifications of a quest's initial tasks when adding the quest.\n" +
			"Initial tasks are tasks that will be activated when the quest is added.", "")]
		public bool displayInitialTasks = false;

		[EditorEndFoldout]
		public NotificationQueueSettings queueQuestNotifications = new NotificationQueueSettings();


		// default quest icons
		[EditorFoldout("Default Quest Status Icons", "You can optionally override a quest's icon for different states.\n" +
			"These icons (except the unavailable icon) will only be used if the quest has been added to the player's quests, " +
			"otherwise the quest doesn't have a status.\n" +
			"The unavailable icon is only used when the quest isn't yet added to the player's quest list and the quest's requirements failed.", "")]
		[EditorEndFoldout]
		public QuestStatusIconSettings questStatusIcons = new QuestStatusIconSettings();


		// default task icons
		[EditorFoldout("Default Task Status Icons", "You can optionally override the task's icon for different states.\n" +
			"These icons will only be used if the quest has been added to the player's quests, " +
			"otherwise the task doesn't have a status.", "")]
		[EditorEndFoldout]
		public QuestTaskStatusIconSettings taskStatusIcons = new QuestTaskStatusIconSettings();


		// default quest layout
		[EditorFoldout("Default Quest Layout", "The quest layout is used to display " +
			"quest information (e.g. tasks, rewards) in menus and dialogues.\n" +
			"The default quest layout can be overridden by each quest individually.", "")]
		[EditorEndFoldout]
		public QuestLayout questLayout = new QuestLayout();


		// quest notifications
		public QuestNotificationSettings notifications = new QuestNotificationSettings();

		public QuestSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Quest Settings"; }
		}
	}
}
