﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public enum GridSelectionType { None, Placement, Orientation, Move, Examine, Target, Custom }

	public class BattleGridSettings : BaseSettings
	{
		// grid settings
		[EditorHelp("Grid Type", "Select which type of grid will be used:\n" +
			"- Square: The grid consists of square cells.\n" +
			"- Hexagonal: The grid consists of hexagonal cells.", "")]
		[EditorFoldout("Grid Settings", "Base settings of the battle grid.\n" +
			"Battles using the 'Battle' component can optionally be used as grid battles, taking place on a grid.\n" +
			"You can create a battle grid in scenes using a 'Battle Grid' component.", "")]
		public BattleGridType type = BattleGridType.Square;

		// square grid
		[EditorHelp("Diagonal Distance 1", "Diagonal cells are also a distance of 1 instead of 2.", "")]
		[EditorCondition("type", BattleGridType.Square)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool squareDiagonalDistanceOne = false;

		// hexagonal grid
		[EditorHelp("Hexagonal Type", "Select which type of hexagonal grid will be used:\n" +
			"- Horizontal Even: Pointy topped, every even row will be offset by half X cell offset.\n" +
			"- Horizontal Odd: Pointy topped, every odd row will be offset by half X cell offset.\n" +
			"- Vertical Even: Flat topped, every even column will be offset by half Y cell offset.\n" +
			"- Vertical Odd: Flat topped, every odd column will be offset by half Y cell offset.", "")]
		[EditorCondition("type", BattleGridType.Hexagonal)]
		[EditorEndCondition]
		public HexagonalGridType hexagonalType = HexagonalGridType.HorizontalEven;

		// cell size
		[EditorHelp("Cell Size", "The size of individual cells in world units.", "")]
		[EditorSeparator]
		[EditorLimit(0.0f, false)]
		public float cellSize = 1;

		[EditorHelp("Cell Offset", "The offset between individual cells.\n" +
			"X is the horizontal/column offset (X-axis), Y is the vertical/row offset (Z-axis).", "")]
		public Vector2 cellOffset = Vector2.zero;

		[EditorHelp("Horizontal Plane", "The horizontal plane used by grids.\n" +
			"Use 'XY' for 2D top down scenes.", "")]
		public HorizontalPlaneOverride horizontalPlane = new HorizontalPlaneOverride();

		// raycast settings
		[EditorHelp("Layer Mask", "Select the layer the raycast will use.\n" +
			"Only objects on this layer can be hit by the raycast.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Raycast Settings")]
		[EditorLabel("A raycast is used to find the nearest cell to the click/touch of the user, e.g. when selecting a cell for moving.")]
		public LayerMask rayLayerMask = -1;

		[EditorHelp("Distance", "The distance the raycast will use (from the camera).\n" +
			"If nothing is hit within this distance, no cell will be found.", "")]
		[EditorEndFoldout]
		public float rayDistance = 100.0f;


		// cell selection
		[EditorFoldout("Cell Selection", "Define the how cells can be selected " +
			"(e.g. to select a target cell for the move command).", "")]
		[EditorEndFoldout]
		public GridCellSelectionSettings cellSelection = new GridCellSelectionSettings();


		// cell selection
		[EditorFoldout("Orientation Selection", "Define the how the orientation of a combatant can be selected.", "")]
		[EditorEndFoldout]
		public GridOrientationSelectionSettings orientationSelection = new GridOrientationSelectionSettings();


		// combatant placement
		[EditorFoldout("Combatant Placement", "Define the settings for the player's combatant placement on the grid.", "")]
		[EditorEndFoldout]
		public GridCombatantPlacementSettings combatantPlacement = new GridCombatantPlacementSettings();


		// move command
		[EditorFoldout("Move Command", "Define the base move range and pathfinding settings for the grid move command.", "")]
		[EditorEndFoldout]
		public GridMoveCommandSettings moveCommand = new GridMoveCommandSettings();


		// target cell selection
		[EditorFoldout("Target Cell Selection", "Define the settings for the target cell selection of abilities and items that target a grid cell.\n" +
			"Abilities and items can target a grid cell by using the 'None' target range and enabling 'Select Target Cell'.", "")]
		[EditorEndFoldout]
		public GridTargetCellSelectionSettings targetCellSelection = new GridTargetCellSelectionSettings();


		// examine combatants
		[EditorFoldout("Examine Grid", "Define how examining the grid is handled and displayed.", "")]
		[EditorEndFoldout]
		public GridExamineSettings examine = new GridExamineSettings();


		// in-game
		private Combatant selectingCombatant;

		private BattleGridCellComponent selectedCell;

		private GridSelectionType selectionType = GridSelectionType.None;

		private GridCustomCellSelectionSettings customCellSelection;

		public BattleGridSettings(MakinomProjectAsset project)
		{
			this.LoadProject(project);
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Filename
		{
			get { return "Battle Grid Settings"; }
		}


		/*
		============================================================================
		Cell selection functions
		============================================================================
		*/
		public virtual GridSelectionType SelectionType
		{
			get { return this.selectionType; }
			set { this.selectionType = value; }
		}

		public virtual Combatant SelectingCombatant
		{
			get
			{
				if(this.selectingCombatant == null)
				{
					return ORK.Game.ActiveGroup.BattleLeader;
				}
				return this.selectingCombatant;
			}
			set { this.selectingCombatant = value; }
		}

		public virtual BattleGridCellComponent SelectedCell
		{
			get { return this.selectedCell; }
			set { this.selectedCell = value; }
		}

		public virtual void InitSelection(GridSelectionType type, Combatant combatant)
		{
			if(this.selectingCombatant != null)
			{
				this.selectingCombatant.Shortcuts.Active = null;
			}
			if(GridSelectionType.Move == this.selectionType)
			{
				this.moveCommand.Clear();
			}
			else if(GridSelectionType.Orientation == this.selectionType)
			{
				this.orientationSelection.Clear();
			}
			else if(GridSelectionType.Target == this.selectionType)
			{
				this.targetCellSelection.Clear();
			}
			else if(GridSelectionType.Examine == this.selectionType)
			{
				this.examine.Clear();
			}
			else if(GridSelectionType.Custom == this.selectionType)
			{
				if(this.customCellSelection != null)
				{
					this.customCellSelection.Clear();
					this.customCellSelection = null;
				}
			}
			this.examine.ExternalExamine(null, false, false);

			this.selectionType = type;
			this.selectingCombatant = combatant;
		}

		public virtual void InitCustomSelection(GridCustomCellSelectionSettings customSelection, Combatant combatant)
		{
			this.InitSelection(GridSelectionType.Custom, combatant);
			this.customCellSelection = customSelection;
		}

		public virtual void CloseAlwaysActiveExamineTarget()
		{
			if(GridSelectionType.Examine == this.selectionType &&
				this.examine.IsAlwaysActiveOn &&
				!this.examine.alwaysActiveDuringTargetSelection)
			{
				this.examine.Close();
			}
		}

		public virtual void ResetToSelectingCombatantCell()
		{
			this.SelectedCell = this.selectingCombatant != null ?
				this.selectingCombatant.Grid.Cell : null;
		}

		public virtual void ClearCellSelection()
		{
			this.selectionType = GridSelectionType.None;
			this.selectingCombatant = null;
			this.customCellSelection = null;
			this.examine.ExternalExamine(null, false, false);
		}

		public virtual void CloseSelections(Combatant combatant)
		{
			if(this.selectingCombatant == combatant ||
				combatant == null)
			{
				if(GridSelectionType.Move == this.selectionType)
				{
					this.moveCommand.Clear();
					this.ClearCellSelection();
				}
				else if(GridSelectionType.Orientation == this.selectionType)
				{
					this.orientationSelection.Clear();
					this.ClearCellSelection();
				}
				else if(GridSelectionType.Target == this.selectionType)
				{
					this.targetCellSelection.Clear();
					this.ClearCellSelection();
				}
				else if(GridSelectionType.Examine == this.selectionType)
				{
					if(!this.examine.IsAlwaysActiveOn)
					{
						this.examine.Clear();
						this.ClearCellSelection();
					}
				}
				else if(GridSelectionType.Custom == this.selectionType)
				{
					if(this.customCellSelection != null)
					{
						this.customCellSelection.Clear();
					}
					this.ClearCellSelection();
				}
			}
		}

		public virtual void RotateToSelectedCell(bool gridRotation)
		{
			if(this.selectingCombatant != null &&
				this.selectedCell != null)
			{
				this.selectingCombatant.Object.LookAt(this.selectedCell.transform.position);
				if(ORK.Battle.Grid != null &&
					gridRotation)
				{
					Vector3 tmpRotation = this.selectingCombatant.GameObject.transform.eulerAngles;
					if(this.horizontalPlane.IsXZ)
					{
						tmpRotation.y = BattleGridHelper.GetDirectionRotation(
							this.selectingCombatant.GameObject, GridDirectionRotationType.Nearest, true);
					}
					else
					{
						tmpRotation.z = BattleGridHelper.GetDirectionRotation(
							this.selectingCombatant.GameObject, GridDirectionRotationType.Nearest, true);
					}
					this.selectingCombatant.GameObject.transform.eulerAngles = tmpRotation;
				}
			}
		}

		public virtual void Tick()
		{
			// selection updates
			if(GridSelectionType.None == this.selectionType)
			{
				if(this.examine.alwaysActive &&
					ORK.Battle.IsBattleRunning() &&
					(this.examine.alwaysActiveDuringActions ||
						!ORK.Battle.Actions.HasActive()) &&
					ORK.Battle.System.settings.CanUseAlwaysActiveGridExamine(this.examine.alwaysActiveOnlyPlayerPhase))
				{
					Combatant combatant = ORK.Battle.SelectingCombatant;
					if(combatant == null)
					{
						combatant = ORK.Game.ActiveGroup.BattleLeader;
					}
					if(combatant != null &&
						(this.examine.alwaysActiveDuringTargetSelection ||
							(combatant.Battle.BattleMenu != null &&
								BattleMenuMode.Target != combatant.Battle.BattleMenu.Mode)))
					{
						this.examine.StartAlwaysActive(combatant,
							this.selectedCell != null ?
								this.selectedCell : combatant.Grid.Cell);
					}
				}
			}
			else
			{
				if(GridSelectionType.Placement == this.selectionType)
				{
					this.combatantPlacement.Tick();
				}
				else if(GridSelectionType.Move == this.selectionType)
				{
					this.moveCommand.Tick();
				}
				else if(GridSelectionType.Orientation == this.selectionType)
				{
					this.orientationSelection.Tick();
				}
				else if(GridSelectionType.Target == this.selectionType)
				{
					this.targetCellSelection.Tick();
				}
				else if(GridSelectionType.Examine == this.selectionType)
				{
					if(this.examine.IsAlwaysActiveOn &&
						(!ORK.Battle.IsBattleRunning() ||
						(!this.examine.alwaysActiveDuringTargetSelection &&
							this.selectingCombatant != null &&
							this.selectingCombatant.Battle.BattleMenu != null &&
							BattleMenuMode.Target == this.selectingCombatant.Battle.BattleMenu.Mode) ||
						(!this.examine.alwaysActiveDuringActions &&
							ORK.Battle.Actions.HasActive()) ||
						!ORK.Battle.System.settings.CanUseAlwaysActiveGridExamine(this.examine.alwaysActiveOnlyPlayerPhase)))
					{
						this.examine.Close();
					}
					else
					{
						this.examine.Tick();
					}
				}
				else if(GridSelectionType.Custom == this.selectionType)
				{
					if(this.customCellSelection != null)
					{
						this.customCellSelection.Tick();
					}
				}
				if(this.examine.IsExternalCall)
				{
					this.examine.TickExternalCall();
				}
			}

			this.examine.TickToggles();
		}

		public virtual void TargetCellSelectionCursor(BattleGridCellComponent cell)
		{
			if(GridSelectionType.Target == this.selectionType)
			{
				this.targetCellSelection.TargetCellCursor(cell);
			}
		}

		public virtual void EndBattle()
		{
			if(this.examine.IsAlwaysActiveOn ||
				this.examine.IsExternalCall)
			{
				this.examine.Close();
			}

			this.moveCommand.Clear();
			this.orientationSelection.Clear();
			this.targetCellSelection.Clear();
			this.examine.Clear();
			if(this.customCellSelection != null)
			{
				this.customCellSelection.Clear();
			}
			this.ClearCellSelection();
		}


		/*
		============================================================================
		Type functions
		============================================================================
		*/
		public virtual bool IsSquare
		{
			get { return BattleGridType.Square == this.type; }
		}

		public virtual bool IsHorizontalHex
		{
			get
			{
				return BattleGridType.Hexagonal == this.type &&
				  (HexagonalGridType.HorizontalEven == this.hexagonalType ||
				  HexagonalGridType.HorizontalOdd == this.hexagonalType);
			}
		}

		public virtual bool IsVerticalHex
		{
			get
			{
				return BattleGridType.Hexagonal == this.type &&
				  (HexagonalGridType.VerticalEven == this.hexagonalType ||
				  HexagonalGridType.VerticalOdd == this.hexagonalType);
			}
		}


		/*
		============================================================================
		Size functions
		============================================================================
		*/
		public virtual Vector2 CellSize
		{
			get
			{
				if(this.IsSquare)
				{
					return new Vector2(this.cellSize, this.cellSize);
				}
				else if(this.IsHorizontalHex)
				{
					return new Vector2(
						this.cellSize * (Mathf.Sqrt(3) / 2.0f),
						this.cellSize);
				}
				else if(this.IsVerticalHex)
				{
					return new Vector2(
						this.cellSize,
						this.cellSize * (Mathf.Sqrt(3) / 2.0f));
				}
				return new Vector2(this.cellSize, this.cellSize);
			}
		}

		public virtual float CellRadius
		{
			get
			{
				if(this.IsSquare)
				{
					return Mathf.Sqrt((this.cellSize * this.cellSize) * 2) / 2;
				}
				else
				{
					return this.cellSize * (Mathf.Sqrt(3) / 2.0f);
				}
			}
		}

		public virtual Vector2 CellDistance
		{
			get
			{
				if(this.IsSquare)
				{
					return new Vector2(this.cellSize, this.cellSize);
				}
				else if(this.IsHorizontalHex)
				{
					return new Vector2(
						this.cellSize * (Mathf.Sqrt(3) / 2.0f),
						this.cellSize * (3.0f / 4.0f));
				}
				else if(this.IsVerticalHex)
				{
					return new Vector2(
						this.cellSize * (3.0f / 4.0f),
						this.cellSize * (Mathf.Sqrt(3) / 2.0f));
				}
				return new Vector2(this.cellSize, this.cellSize);
			}
		}

		public virtual Vector2 CellOffset
		{
			get
			{
				if(this.IsSquare)
				{
					return new Vector2(
						this.cellSize + this.cellOffset.x,
						this.cellSize + this.cellOffset.y);
				}
				else if(this.IsHorizontalHex)
				{
					return new Vector2(
						this.cellSize * (Mathf.Sqrt(3) / 2.0f) + this.cellOffset.x,
						this.cellSize * (3.0f / 4.0f) + this.cellOffset.y);
				}
				else if(this.IsVerticalHex)
				{
					return new Vector2(
						this.cellSize * (3.0f / 4.0f) + this.cellOffset.x,
						this.cellSize * (Mathf.Sqrt(3) / 2.0f) + this.cellOffset.y);
				}
				return new Vector2(
					this.cellSize + this.cellOffset.x,
					this.cellSize + this.cellOffset.y);
			}
		}

		public virtual Vector3 GetCorner(Vector3 center, int direction, float distanceToCenter)
		{
			if(this.IsSquare)
			{
				if(direction < 0)
				{
					direction += 8;
				}
				else if(direction >= 8)
				{
					direction -= 8;
				}

				float size = (this.cellSize / 2) * distanceToCenter;
				if(this.horizontalPlane.IsXZ)
				{
					if(direction == 0 ||
						direction == 7)
					{
						return center + new Vector3(-size, 0, size);
					}
					else if(direction == 1 ||
						direction == 2)
					{
						return center + new Vector3(size, 0, size);
					}
					else if(direction == 3 ||
						direction == 4)
					{
						return center + new Vector3(size, 0, -size);
					}
					else if(direction == 5 ||
						direction == 6)
					{
						return center + new Vector3(-size, 0, -size);
					}
				}
				else
				{
					if(direction == 0 ||
						direction == 7)
					{
						return center + new Vector3(-size, size, 0);
					}
					else if(direction == 1 ||
						direction == 2)
					{
						return center + new Vector3(size, size, 0);
					}
					else if(direction == 3 ||
						direction == 4)
					{
						return center + new Vector3(size, -size, 0);
					}
					else if(direction == 5 ||
						direction == 6)
					{
						return center + new Vector3(-size, -size, 0);
					}
				}
			}
			else if(this.IsHorizontalHex)
			{
				if(direction < 0)
				{
					direction += 6;
				}
				else if(direction >= 6)
				{
					direction -= 6;
				}

				float size = (this.cellSize / 2) * distanceToCenter;
				float angleDeg = 150.0f - (60.0f * direction);
				float angleRad = (Mathf.PI / 180.0f) * angleDeg;
				if(this.horizontalPlane.IsXZ)
				{
					return center + new Vector3(
						size * Mathf.Cos(angleRad), 0,
						size * Mathf.Sin(angleRad));
				}
				else
				{
					return center + new Vector3(
						size * Mathf.Cos(angleRad),
						size * Mathf.Sin(angleRad), 0);
				}
			}
			else if(this.IsVerticalHex)
			{
				if(direction < 0)
				{
					direction += 6;
				}
				else if(direction >= 6)
				{
					direction -= 6;
				}

				float size = (this.cellSize / 2) * distanceToCenter;
				float angleDeg = 120.0f - (60.0f * direction);
				float angleRad = (Mathf.PI / 180.0f) * angleDeg;
				if(this.horizontalPlane.IsXZ)
				{
					return center + new Vector3(
						size * Mathf.Cos(angleRad), 0,
						size * Mathf.Sin(angleRad));
				}
				else
				{
					return center + new Vector3(
						size * Mathf.Cos(angleRad),
						size * Mathf.Sin(angleRad), 0);
				}
			}
			return center;
		}
	}
}
