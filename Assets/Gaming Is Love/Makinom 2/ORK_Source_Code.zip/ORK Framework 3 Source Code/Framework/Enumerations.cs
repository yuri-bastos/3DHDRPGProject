﻿
namespace GamingIsLove.ORKFramework
{
	// new content mark
	public enum MarkNewContentType { None, FirstAdd, EachAdd, EachChange }
	public enum UnmarkNewContentType { None, View, Selection }


	// input/control
	public enum BattleControlBlock { None, Battle, AllActions, PlayerActions }
	public enum AllowTurnControl { None, Always, WhileChoosing, WhileInAction }


	// formula
	public enum StatusValueOrigin { Base, Current, Maximum, ToMaximum }


	// development
	public enum StatDevType { None, Curve, Formula, Percent }
	public enum LevelUpType { None, Auto, Spend, Uses }
	public enum LearnCostType { StatusValue, Item }

	// research trees
	public enum ResearchItemDuration { None, Manual, Time }
	public enum ResearchTreeStateCheck { Known, Unknown, Complete }
	public enum ResearchItemState { Unresearched, InResearch, Researched, Complete }
	public enum ResearchSelection { All, ResearchType, ResearchTree, ResearchItem }
	public enum ResearchDisplayType { Researchable, LimitFail, CostsFail, RequirementsFail, InResearch, Complete }


	// inventory
	public enum CombatantScope { Group, Individual }
	public enum InventoryAddType { Add, AutoStack, AutoSplit }


	// schematics
	public enum LootVariableOrigin { Global, Combatant, Spawner }
	public enum PlayerSpawnTarget { SpawnPoint, Position, Object, LastPosition, ScenePosition }
	public enum StoreGridCellType { BattleRangeTemplate, Custom, Path }
	public enum DataStoreType { Save, Load, Clear }
	public enum ActorAlliedCheckType { Player, MachineObject, StartingObject }

	// dialogue
	public enum CombatantSelectionDialogueType
	{
		Defined,
		BattleGroup, NonBattleGroup, LockedBattleGroup,
		Members, InactiveMembers, HiddenMembers, BattleReserve
	}


	// animation
	public enum MoveAnimationMode
	{
		None, Idle, Walk, Run, Sprint, Jump, Fall, Land,
		ActionChooseIdle, ActionWaitIdle, ActionCastIdle, TurnEndedIdle
	};
	public enum MecanimRotationType { FullDegree, Direction4, Direction8 }


	// scene
	public enum SceneIDChangeType { Item, Battle }


	// cursor type > value is used for sorting, lower value == higher priority
	public enum CursorType
	{
		Custom, Default,
		TargetSelfValid, TargetAllyValid, TargetEnemyValid, TargetAllValid,
		TargetSelfInvalid, TargetAllyInvalid, TargetEnemyInvalid, TargetAllInvalid,
		TargetSelfNone, TargetAllyNone, TargetEnemyNone, TargetAllNone,
		AttackRange,
		InActionPlayer, InActionAlly, InActionEnemy,
		GridPlacementSelection, GridNoPlacementSelection,
		GridMoveSelection, GridNoMoveSelection, GridOrientationSelection,
		GridExamineSelection, GridExamineSelectionBlocked
	}


	// menu
	public enum MenuCombatantScope { Current, Battle, Group, NonBattle, BattleReserve, GroupBattleSorted, NonBattleReserve }
	public enum GroupMenuCombatantScope { Battle, NonBattle, Both }
	public enum MenuTypeDisplay { None, UIBox, Merged, Tabs }
	public enum MenuTypeDisplayNoMerge { None, UIBox, Tabs }
	public enum MenuBoxDisplay { Same, One, Multi, Sequence }
	public enum MenuStatus { Opening, Opened, Closing, Closed }
	public enum CraftingListCreationType { Exact, One, Multi, ExactOrder }
	public enum MenuDetailsBoxMode { None, Use, Info, HUD }


	// quantity selection
	public enum QuantitySelectionMode { Remove, Drop, Give, Buy, Sell }
	public enum QuantityType { Default, One, All, Select }


	// battle menu
	public enum BMTypeDisplay { Combined, Type, List }
	public enum BattleMenuMode
	{
		None, List, AbilityType, Ability, ItemType, Item,
		Target, EquipmentSlot, Equipment, Command, ChangeMember,
		AIType, AIBehaviourSlot, AIBehaviour, AIRulesetSlot, AIRuleset,
		GridMove, GridOrientation, GridExamine, Reset, Back, ClassSlot, ClassSlotClass, ClassSingle
	}
	public enum BestiaryLearnType { None, Encounter, Attack, AttackedBy, Death }


	// shop
	public enum ShopMode { Buy, Sell, Exit }
	public enum ShopTypeDisplay { UIBox, Tabs, Merged }


	// game settings
	public enum StatisticType
	{
		TotalKilled, SingleKilled,
		TotalUsed, SingleUsed,
		TotalCreated, SingleCreatedItem, SingleCreatedEquipment,
		TotalBattles, WonBattles, LostBattles, EscapedBattles,
		Custom,
		SingleCreatedAIBehaviour, SingleCreatedAIRuleset, SingleCreatedCraftingRecipes,
		TotalGained, SingleGainedItem, SingleGainedEquipment,
		SingleGainedAIBehaviour, SingleGainedAIRuleset, SingleGainedCraftingRecipes
	}


	// div
	public enum ValueSetter { Percent, Value }
	public enum Consider { Yes, No, Ignore }
	public enum ShortcutListChange { Next, Previous, DefinedIndex }
	public enum RequirementTargetType { None, User, Target }
	public enum GroupMemberSelectionType { Combatant, Leader, Index, Offset }


	// change types
	public enum SimpleChangeType { Add, Remove }


	// status values
	public enum StatusValueType { Normal, Consumable, Experience }
	public enum StatusValueDeathType { None, OnMinimum, OnMaximum }
	public enum ExperienceType { None, Level, ClassLevel }
	public enum StatusValueGetValue { CurrentValue, BaseValue, MinValue, MaxValue, DisplayValue, PreviewValue, PreviewMaxValue, PreviewMinValue }
	public enum UpgradeDisplayType { Upgradeable, CostsFail, ConditionsFail, NoUpgrade }
	public enum NoneExperienceMaxType { NextLevel, CurrentLevel, MaxValue }


	// status effect
	public enum EndAfterType { None, TurnStart, TurnEnd, Time, ActionStart, ActionEnd, BattleTurnStart, BattleTurnEnd }
	public enum EffectRecast { Add, Reset, None }
	public enum EffectStacking { None, Enabled, OncePerCombatant }
	public enum EffectStatusValueSetOn { Apply, Remove, TurnStart, TurnEnd, Time, ActionStart, ActionEnd, BattleTurnStart, BattleTurnEnd }
	public enum ChangeBlock { None, Negative, Positive, All }


	// ability/item
	public enum EffectCast { Add, Remove, Toggle }
	public enum EffectTypeRemoveType { All, Random, First, Last }
	public enum TargetType { Self, Ally, Enemy, All }
	public enum TargetRange { None, Single, Group }
	public enum UseableIn { Field, Battle, Both, None }
	public enum AbilityCheckType { Known, Learned, GroupAbility, Temporary }
	public enum IncludeCheckType { Yes, No, Only }
	public enum ItemAbilityType { None, Learn, Use }
	public enum UseCostAutoConsumeType { No, WithoutTargets, Always, OnSelection }
	public enum BattleRangeType { None, Template, Custom }
	public enum AffectRangeType { None, Calculation, Execution }
	public enum ActionReuseStartType { Start, Calculation, End }


	// equipment
	public enum EquipType { Single, Multi }
	public enum EquipmentDurabilityType { NoBonuses, Unequip, Destroy, None, Schematic }
	public enum AddRandomBonus { All, Random, First }


	// combatant
	public enum AggressionType { Always, OnDamage, OnSelection, OnAction }
	public enum CombatantAffiliationType { Player, Ally, Enemy }
	public enum CombatantDeathState { Alive, Dying, Dead }


	// ai
	public enum FoundTargets { Keep, Check, Clear, CheckKeep }
	public enum MoveDetectionType { Sight, Movement, CombatantTrigger }
	public enum MoveConditionType { Level, ClassLevel, GroupSize, Status }
	public enum MoveAIMode { Idle, Waypoint, Follow, GiveWay, Hunt, Flee, CautionHunt, CautionFlee, Protect }
	public enum MoveAIUseMode { Auto, Idle, Hunt, Flee, Caution, Protect }
	public enum BattleAITargetType { Self, Ally, Enemy, All, None }
	public enum BattleAISelectedDataUser { Self, Ally, Enemy, All, FoundTargets }
	public enum AIGridMove { MoveTowardTarget, FleeFromTarget, Random, GridFormation, GridCellType }
	public enum AIGridMoveTargetType { Nearest, North, East, South, West, Front, Back, Left, Right }
	public enum AIGridMoveRangeType { Distance, BattleRangeTemplate, Custom, UseRange }
	public enum AIRuleType { Action, BattleAI, BlockAbility, BlockAttack, BlockCounterAttack, BlockItem, Target, MoveAI }
	public enum AIRuleTargetType { Self, Ally, Enemy, All, MemberTarget, TargetingMember }
	public enum BattleAITargetOrigin { User, Leader, Group, Allies, Enemies, FoundTargets, SelectedData }
	public enum WeightedGroupType { Smallest, Largest }
	public enum DistanceType { Nearest, NearestAverage, Farthest, FarthestAverage, All }


	// battle system
	public enum BattleSystemType { TurnBased, ActiveTime, RealTime, Phase }
	public enum TurnBasedMode { Classic, Active, MultiTurns }
	public enum TargetRayOrigin { User, Screen }
	public enum EnemyCounting { None, Letters, Numbers }
	public enum EnemyCountingType { ID, Name }
	public enum UseTimebarAction { ActionBorder, MaxTimebar, EndTurn }
	public enum GroupAdvantageType { None, Player, Enemy }
	public enum BattleOutcome { None, Victory, Escape, Defeat, LeaveArena }
	public enum ActionTimeDecreaseType { Always, WhileChoosing, WhileInAction }
	public enum PhaseTurnStartType { None, PhaseStart, PhaseEnd }

	// battle grid
	public enum BattleGridType { Square, Hexagonal }
	public enum HexagonalGridType { VerticalEven, VerticalOdd, HorizontalEven, HorizontalOdd }
	public enum GridBaseHighlight { Area, Selection, NoSelection }
	public enum GridCellHighlight
	{
		None,
		// placement
		Placement, PlacementSelection, NoPlacementSelection,
		PlacementSelectionPlayer, PlacementSelectionAlly, PlacementSelectionEnemy,
		// move command
		MoveRange, MoveRangeBlocked, MoveRangePassable, MoveSelection, NoMoveSelection, MovePath,
		MoveSelectionPlayer, MoveSelectionAlly, MoveSelectionEnemy,
		// orientation 
		OrientationSelection, OrientationSelectionPlayer,
		OrientationSelectionAlly, OrientationSelectionEnemy,
		// marked cell
		MarkedCell,
		// ranges
		UseRange, AffectRange,
		// available targets
		AvailableTargetPlayer, AvailableTargetAlly, AvailableTargetEnemy,
		// selected targets
		SelectedTargetPlayer, SelectedTargetAlly, SelectedTargetEnemy,
		// target cell
		TargetCellSelection, NoTargetCellSelection,
		TargetCellSelectionPlayer, TargetCellSelectionAlly, TargetCellSelectionEnemy,
		// examine
		ExamineSelection, ExamineSelectionBlocked, ExamineMoveRange, ExamineMoveRangeBlocked, ExamineMoveRangePassable, ExamineUseRange,
		ExamineSelectionPlayer, ExamineSelectionAlly, ExamineSelectionEnemy,
		// selecting combatant
		SelectingPlayer, SelectingAlly, SelectingEnemy,
		// combatant cell
		CellPlayer, CellPlayerTurnEnded, CellAlly, CellAllyTurnEnded, CellEnemy, CellEnemyTurnEnded,
		// grid formation
		GridFormation, GridFormationPosition,
		// custom
		Custom1, Custom2, Custom3, Custom4, Custom5
	}
	public enum GridShapeType { None, All, Range, Mask, Ring }
	public enum GridUseBattleType { NoGrid, NearestGrid, DefinedGrid }
	public enum GridPathCellSelection { Next, Last, All }
	public enum GridDirectionRotationType { Nearest, Left, Right, Target }
	public enum GridCellEventStartType { None, Any, MoveTo, MoveOver, StartTurn, EndTurn, MoveFrom }
	public enum SetCellCombatantType { Combatant, Guest, Move, Remove }
	public enum GridMoveState { Available, Selected, Performed }
	public enum AutoGridMoveType { None, FirstAction, Always }


	// actions
	public enum ActionSelectType
	{
		Attack, CounterAttack, Ability, Item,
		Defend, Escape, Death, None, ChangeMember,
		ClassAbility, Shortcut,
		AbilityType, ItemType
	}
	public enum ActionType { Attack, CounterAttack, Ability, Item, Defend, Escape, Death, None, ChangeMember, Join, GridMove }
	public enum AbilityActionType { Ability, BaseAttack, CounterAttack }
	public enum AutoAttackTargetType { All, GroupTargets, IndividualTargets, GroupAndIndividual }
	public enum BattleActionAddType { Try, NextAction, SubAction }
	public enum NextBattleActionChange { Add, Set, First }
	public enum BaseAttackScope { Current, Index, All }
	public enum CombatantActionState { Available, Casting, InAction, EndingAction }
	public enum CombatantTurnState { BeforeTurn, InTurn, AfterTurn }
	public enum CastingScopeCheck { Single, Type, RootType, All };


	// quests
	public enum QuestStatusType { Inactive, Active, Finished, Failed }
	public enum QuestCheckType { Inactive, Active, Finished, Failed, NotAdded }
	public enum QuestRemoveType { Quest, QuestType, All, SelectedData }
}
