﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class AIBehaviourSlot : ISaveData, IContent
	{
		protected LanguageContentInformation slotContent;

		protected Combatant owner;

		protected int index = 0;

		protected bool blocked = false;

		protected AIBehaviourShortcut behaviour;

		protected List<VariableHandler> unregisterHandlers;

		public AIBehaviourSlot(Combatant owner, int index)
		{
			this.owner = owner;
			this.index = index;
			this.slotContent = ORK.AIBehaviours.GetSlotContent(this.index);
		}

		public virtual Combatant Owner
		{
			get { return this.owner; }
		}

		public virtual int Index
		{
			get { return this.index; }
		}

		public virtual bool Blocked
		{
			get { return this.blocked; }
			set { this.blocked = false; }
		}

		public virtual bool Equipped
		{
			get { return this.behaviour != null; }
		}

		public virtual AIBehaviourShortcut AIBehaviour
		{
			get { return this.behaviour; }
			set { this.behaviour = value; }
		}

		public virtual void Unequip()
		{
			if(this.behaviour != null)
			{
				this.owner.AI.UnequipAIBehaviourSlot(this.index, true, true);
			}
		}

		public virtual void Equip(AIBehaviourShortcut behaviour)
		{
			if(behaviour != null)
			{
				this.owner.AI.EquipAIBehaviour(behaviour.Setting, this.index, true, true, true);
			}
			else
			{
				this.Unequip();
			}
		}

		public virtual bool IsHighlighted
		{
			get { return ORK.Game.Previews.HighlightedAIBehaviourSlot == this; }
		}

		public virtual void SetHighlighted()
		{
			ORK.Game.Previews.HighlightedAIBehaviourSlot = this;
		}


		/*
		============================================================================
		Register condition functions
		============================================================================
		*/
		public virtual void CheckSlot()
		{
			if(this.Equipped &&
				this.AIBehaviour.Setting.equipConditions.Has &&
				this.AIBehaviour.Setting.autoUnequip &&
				!this.AIBehaviour.Setting.CanEquip(this.owner))
			{
				this.owner.AI.UnequipAIBehaviourSlot(this.index, true, true);
			}
		}

		public virtual void Register()
		{
			if(this.Equipped)
			{
				if(this.AIBehaviour.Setting.equipConditions.Has &&
					this.AIBehaviour.Setting.autoUnequip &&
					ORK.Access.Combatant.HasStatusAuthority)
				{
					this.AIBehaviour.Setting.equipConditions.conditions.Register(
						this.owner.Call, this.CheckSlot, ref this.unregisterHandlers);
				}
			}
		}

		public virtual void Unregister()
		{
			if(this.Equipped &&
				this.AIBehaviour.Setting.equipConditions.Has &&
				this.AIBehaviour.Setting.autoUnequip &&
				ORK.Access.Combatant.HasStatusAuthority)
			{
				this.AIBehaviour.Setting.equipConditions.conditions.Unregister(
					this.owner.Call, this.CheckSlot, this.unregisterHandlers);
				Maki.Pooling.VariableHandlerLists.Add(this.unregisterHandlers);
				this.unregisterHandlers = null;
			}
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public virtual int ID
		{
			get { return this.index; }
		}

		public virtual string GetName()
		{
			return this.slotContent.GetName().
				Replace("<slotindex>", ORK.AIBehaviours.GetFormattedSlotIndex(this.index));
		}

		public virtual string GetShortName()
		{
			return this.slotContent.GetShortName().
				Replace("<slotindex>", ORK.AIBehaviours.GetFormattedSlotIndex(this.index));
		}

		public virtual string GetDescription()
		{
			return this.slotContent.GetDescription().
				Replace("<slotindex>", ORK.AIBehaviours.GetFormattedSlotIndex(this.index));
		}

		public virtual Sprite GetIconSprite()
		{
			return this.slotContent.GetIconSprite();
		}

		public virtual Texture GetIconTexture()
		{
			return this.slotContent.GetIconTexture();
		}

		public virtual string GetIconTextCode()
		{
			return this.slotContent.GetIconTextCode();
		}

		public virtual string GetCustomContent(string contentKey)
		{
			return this.slotContent.GetCustomContent(contentKey).
				Replace("<slotindex>", ORK.AIBehaviours.GetFormattedSlotIndex(this.index));
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public virtual DataObject SaveGame()
		{
			DataObject data = new DataObject();

			if(this.behaviour != null)
			{
				data.Set("behaviour", this.behaviour.SaveGame());
			}

			data.Set("blocked", this.blocked);

			return data;
		}

		public virtual void LoadGame(DataObject data)
		{
			this.behaviour = null;
			if(data != null)
			{
				DataObject tmpBehaviour = data.GetFile("behaviour");
				if(tmpBehaviour != null)
				{
					this.behaviour = new AIBehaviourShortcut();
					this.behaviour.LoadGame(tmpBehaviour);
					if(this.behaviour.ID < 0 ||
						this.behaviour.ID >= ORK.AIBehaviours.Count)
					{
						this.behaviour = null;
					}
				}

				data.Get("blocked", ref this.blocked);
			}
		}
	}
}
