﻿
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.ORKFramework.Components;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Use Grid Formation", "Initiates a defined grid formation for the user's group or the found targets.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation")]
	public class UseGridFormationNode : BaseAINode
	{
		[EditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		public AssetSelection<BattleGridFormationAsset> formation = new AssetSelection<BattleGridFormationAsset>();

		[EditorHelp("Use On Target", "Use the grid formation on the found target(s).\n" +
			"Uses the target as the leader.", "")]
		public bool useOnTarget = false;

		public UseGridFormationNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				this.formation.StoredAsset != null)
			{
				if(this.useOnTarget)
				{
					for(int i = 0; i < call.foundTargets.Count; i++)
					{
						if(call.foundTargets[i] != null)
						{
							call.foundTargets[i].Group.GridFormation.InitFormation(
								this.formation.StoredAsset.Settings, call.foundTargets[i]);
						}
					}
				}
				else
				{
					call.user.Group.GridFormation.InitFormation(
						this.formation.StoredAsset.Settings, call.user);
				}
			}
			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formation.ToString() + (this.useOnTarget ? " on targets" : " on user");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.functionNodeColor; }
		}
	}

	[EditorHelp("Break Grid Formation", "Ends the current or only a defined grid formation of the user's group.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation")]
	public class BreakGridFormationNode : BaseAINode
	{
		[EditorHelp("Any Formation", "Ends the current grid formation of the user's group.", "")]
		public bool any = true;

		[EditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[EditorCondition("any", false)]
		[EditorEndCondition]
		public AssetSelection<BattleGridFormationAsset> formation = new AssetSelection<BattleGridFormationAsset>();

		public BreakGridFormationNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Group.InGridFormation)
			{
				if(this.any)
				{
					call.user.Group.GridFormation.EndFormation(null);
				}
				else if(this.formation.StoredAsset != null)
				{
					call.user.Group.GridFormation.EndFormation(this.formation.StoredAsset.Settings);
				}
			}
			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.any ? "Any" : this.formation.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.functionNodeColor; }
		}
	}

	[EditorHelp("Update Grid Formation", "Updates the user group's grid formation (formation positions, filling empty positions).\n" +
		"Please note that this also happens automatically - the formation positions are updated when the leader's cell changes and " +
		"empty positions are filled when a combatant is removed from the formation (e.g. upon death or leaving group).\n" +
		"Only used in grid battles and when the user's group is using a grid formation.", "")]
	[NodeInfo("Grid Formation")]
	public class UpdateGridFormationNode : BaseAINode
	{
		[EditorHelp("Update Positions", "Update the cell positions of the individual grid formation positions.", "")]
		public bool updatePositions = true;

		[EditorHelp("Fill Positions", "Find combatants for empty grid formation positions.", "")]
		public bool fillPositions = false;

		public UpdateGridFormationNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Group.InGridFormation)
			{
				if(this.updatePositions)
				{
					call.user.Group.GridFormation.UpdatePositionCoords();
				}
				if(this.fillPositions)
				{
					call.user.Group.GridFormation.FindPositionCombatants();
				}
				call.user.Group.GridFormation.UpdateHighlight();
			}
			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.updatePositions && this.fillPositions ? "Update and fill positions" :
				((this.updatePositions ? "Update positions" : "") +
				(this.fillPositions ? "Fill positions" : ""));
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.functionNodeColor; }
		}
	}

	[EditorHelp("Use Grid Formation Rotation", "Uses the rotations on the grid formation positions (e.g. using leader's rotation).\n" +
		"Changes the rotation of the user or all combatants of the formation that are on their formation position cells.\n" +
		"Only used in grid battles and when the user's group is using a grid formation.", "")]
	[NodeInfo("Grid Formation")]
	public class UseGridFormationRotationNode : BaseAINode
	{
		[EditorHelp("Whole Formation", "All combatants that are part of the formation " +
			"(and on their formation position cells) will use the rotation.\n" +
			"If disabled, only the user will rotate.", "")]
		public bool wholeFormation = true;

		public UseGridFormationRotationNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Group.InGridFormation)
			{
				if(this.wholeFormation)
				{
					call.user.Group.GridFormation.UsePositionRotations();
				}
				else
				{
					call.user.Group.GridFormation.UsePositionRotations(call.user);
				}
			}
			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.wholeFormation ? "Whole Formation" : "User";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.functionNodeColor; }
		}
	}

	[EditorHelp("In Grid Formation", "Checks if the user's group currently is in any or a defined grid formation, " +
		"or checks if a combatant is part of a formation.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation", "Check")]
	public class InGridFormationNode : BaseAICheckNode
	{
		[EditorHelp("Check Combatant", "Checks if a combatant is part of a formation.", "")]
		public bool checkCombatant = false;


		// combatant
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		[EditorCondition("checkCombatant", true)]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;


		// formation
		[EditorHelp("Any Formation", "Checks if the user's group is in any grid formation.", "")]
		[EditorElseCondition]
		public bool anyFormation = true;

		[EditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[EditorCondition("anyFormation", false)]
		[EditorEndCondition(2)]
		public AssetSelection<BattleGridFormationAsset> formation = new AssetSelection<BattleGridFormationAsset>();

		public InGridFormationNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;

			if(ORK.Battle.Grid != null)
			{
				if(this.checkCombatant)
				{
					if(FoundTargets.Clear == this.foundType)
					{
						call.foundTargets.Clear();
					}
					else if(FoundTargets.Check == this.foundType)
					{
						List<Combatant> tmp = new List<Combatant>(call.foundTargets);
						call.foundTargets.Clear();
						this.Check(ref any, tmp, call.foundTargets);
					}
					else if(FoundTargets.CheckKeep == this.foundType)
					{
						this.Check(ref any, call.foundTargets, call.foundTargets);
					}

					// check all possible targets
					this.Check(ref any,
						BattleAISettings.GetTargetList(this.targetType,
							this.targetExcludeSelf, this.targetExcludeFoundTargets,
							call),
						call.foundTargets);
				}
				else if(call.user.Group.InGridFormation &&
					(this.anyFormation ||
						(this.formation.StoredAsset != null &&
							call.user.Group.GridFormation.IsFormation(this.formation.StoredAsset.Settings))))
				{
					any = true;
				}
			}

			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Group.InGridFormation &&
					list[i].Group.GridFormation.IsInFormation(list[i]))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.checkCombatant ?
				(this.targetType + ", " + this.foundType + " found") :
				(this.anyFormation ? "Any" : this.formation.ToString());
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.functionNodeColor; }
		}
	}

	[EditorHelp("Is Grid Formation Leader", "Checks if a combatant is the leader of a grid formation.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation", "Check")]
	public class IsGridFormationLeaderNode : BaseAICheckNode
	{
		// combatant
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;

		public IsGridFormationLeaderNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any,
					BattleAISettings.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Group.InGridFormation &&
					list[i].Group.GridFormation.Leader == list[i])
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.functionNodeColor; }
		}
	}

	[EditorHelp("In Grid Formation Position", "Checks if a combatant is on the assigned grid formation position cell.\n" +
		"The formation leader is always in formation position.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation", "Check")]
	public class InGridFormationPositionNode : BaseAICheckNode
	{
		// combatant
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;

		public InGridFormationPositionNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any,
					BattleAISettings.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].Group.InGridFormation &&
					list[i].Group.GridFormation.IsInPosition(list[i]))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.functionNodeColor; }
		}
	}

	[EditorHelp("Grid Formation Finished", "Checks if all combatants reached their grid formation position.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation", "Check")]
	public class GridFormationFinishedNode : BaseAICheckNode
	{
		// combatant
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;


		// settings
		[EditorHelp("Only Filled Positions", "Only positions that have a combatant assigned will be checked.\n" +
			"If disabled, an empty position will result in failure.", "")]
		public bool onlyFilled = true;

		[EditorHelp("Check Rotation", "Checks if the combatant's rotation matches the rotation defined by the position " +
			"(e.g. matching the leader's rotatin).\n" +
			"If disabled, rotations are ignored.", "")]
		public bool checkRotation = false;

		[EditorHelp("Check Grid Distance", "Only positions where the combatant is " +
			"a defined grid distance away from the cell will be checked.\n" +
			"If the combatant is farther away, the position will be ignored.", "")]
		public bool checkGridDistance = false;

		[EditorHelp("Distance", "The distance that will be used.")]
		[EditorCondition("checkGridDistance", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<BattleAIObjectSelection> distance;

		public GridFormationFinishedNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, call, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any, call,
					BattleAISettings.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			call.checkTarget = null;
			return null;
		}

		private void Check(ref bool any, BattleAICall call, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				call.checkTarget = list[i];
				if(list[i] != null &&
					list[i].Group.InGridFormation &&
					list[i].Group.GridFormation.PositionsFilled(this.onlyFilled, this.checkRotation,
						(int)(this.checkGridDistance ? this.distance.GetValue(call) : -1)))
				{
					any = true;
					if(!this.dontAddTargets &&
						!foundTargets.Contains(list[i]))
					{
						foundTargets.Add(list[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found";
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.functionNodeColor; }
		}
	}

	[EditorHelp("Grid Formation Possible", "Checks if a combatant group's formation is possible " +
		"or a defined grid formation is possible at a combatant's cell.\n" +
		"A formation isn't possible if one of the position cells is blocked or invalid (outside the grid).\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Only used in grid battles.", "")]
	[NodeInfo("Grid Formation", "Check")]
	public class GridFormationPossibleNode : BaseAICheckNode
	{
		// combatant
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;


		// settings
		[EditorHelp("Use Current Formation", "Uses the combatant group's current formation for the check.\n" +
			"The check fails if the combatant's group isn't in formation.\n"+
			"If disabled, a defined grid formation is used.", "")]
		public bool useCurrentFormation = true;

		[EditorHelp("Grid Formation", "Select the grid formation that will be used.", "")]
		[EditorCondition("useCurrentFormation", false)]
		[EditorEndCondition]
		public AssetSelection<BattleGridFormationAsset> formation = new AssetSelection<BattleGridFormationAsset>();

		public GridFormationPossibleNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(ORK.Battle.Grid != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					call.foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(call.foundTargets);
					call.foundTargets.Clear();
					this.Check(ref any, tmp, call.foundTargets);
				}
				else if(FoundTargets.CheckKeep == this.foundType)
				{
					this.Check(ref any, call.foundTargets, call.foundTargets);
				}

				// check all possible targets
				this.Check(ref any,
					BattleAISettings.GetTargetList(this.targetType,
						this.targetExcludeSelf, this.targetExcludeFoundTargets,
						call),
					call.foundTargets);
			}

			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}

		private void Check(ref bool any, List<Combatant> list, List<Combatant> foundTargets)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.useCurrentFormation)
					{
						if(list[i].Group.InGridFormation &&
							list[i].Group.GridFormation.IsFormationPossible())
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
					else if(this.formation.StoredAsset != null &&
						this.formation.StoredAsset.Settings.IsFormationPossible(list[i]))
					{
						any = true;
						if(!this.dontAddTargets &&
							!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetType + ", " + this.foundType + " found: " +
				(this.useCurrentFormation ? "Current" : this.formation.ToString());
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.functionNodeColor; }
		}
	}

	[EditorHelp("Reassign Formation Position", "Reassigns the user's grid formation position with a new combatant.\n" +
		"The user will be assigned to a new formation position afterwards (if possible).\n" +
		"Only used in grid battles and when the user's group is using a grid formation.", "")]
	[NodeInfo("Grid Formation")]
	public class ReassignGridFormationPositionNode : BaseAINode
	{
		public ReassignGridFormationPositionNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ORK.Battle.Grid != null &&
				call.user.Group.InGridFormation)
			{
				call.user.Group.GridFormation.ReassignPosition(call.user);
				call.user.Group.GridFormation.AssignToFreePosition(call.user);
			}
			currentNode = this.next;
			return null;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.functionNodeColor; }
		}
	}
}
