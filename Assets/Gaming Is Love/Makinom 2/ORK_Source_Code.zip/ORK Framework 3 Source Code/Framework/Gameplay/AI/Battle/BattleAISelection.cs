
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class BattleAISelection : BaseData
	{
		[EditorHelp("Battle AI", "Select the battle AI that will be used.\n" +
			"If no action is found in this battle AI, the next battle AI will be used.\n" +
			"If no battle AI finds an action, the base attack will be used.", "")]
		public AssetSelection<BattleAIAsset> battleAI = new AssetSelection<BattleAIAsset>();

		[EditorHelp("Use Mode", "Select the use mode of the battle AI:\n" +
			"- First Useable: Uses the first useable action. The battle AI exits at this point and doesn't process any further.\n" +
			"- Queue: Actions will be enqueued, using them in order they're added.")]
		[EditorSeparator]
		public BattleAIUseMode useMode = BattleAIUseMode.FirstUseable;

		[EditorHelp("Execute With Queued", "Execute this battle AI when queued AI actions are available.\n" +
			"This only applies when AI actions are where already queued before starting the AI action selection, " +
			"i.e. from previous battle AI executions.")]
		public bool executeWithQueued = false;


		// chance
		[EditorHelp("Chance (%)", "The chance this battle AI will be used.", "")]
		[EditorSeparator]
		public FloatValue<GameObjectSelection> chanceValue = new FloatValue<GameObjectSelection>(100);


		// battle system
		[EditorSeparator]
		public BattleSystemCheck battleSystemCheck = new BattleSystemCheck();


		// conditions
		[EditorSeparator]
		public CombatantGeneralConditionSettings conditions = new CombatantGeneralConditionSettings();

		public BattleAISelection()
		{

		}

		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		public virtual bool CanUse(Combatant user)
		{
			return Maki.GameSettings.CheckRandom(this.chanceValue.GetValue(user.Call)) &&
				this.battleSystemCheck.Check() &&
				this.conditions.Check(user);
		}

		public virtual BaseAction GetAction(BattleAICall call)
		{
			if(this.battleAI.StoredAsset != null &&
				(!call.hadQueuedActions || this.executeWithQueued) &&
				this.CanUse(call.user))
			{
				call.useMode = this.useMode;
				return this.battleAI.StoredAsset.Settings.GetAction(call);
			}
			return null;
		}
	}
}
