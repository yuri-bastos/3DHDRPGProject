﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI
{
	public class MoveAICaution : BaseData
	{
		[EditorHelp("Use Caution", "The caution settings are enabled.\n" +
			"The combatant will move toward a target until a defined range is reached.\n" +
			"If the target enters a critical range, the combatant will flee from the target.", "")]
		public bool enabled = false;

		[EditorHelp("Use Target Change", "Allow changing targets if another detected target is nearer than the current target.", "")]
		[EditorCondition("enabled", true)]
		public bool useTargetChange = false;

		[EditorHelp("Stopped Look At Target", "Look at the target while the combatant is stopped.", "")]
		public bool stoppedLookAtTarget = false;


		// detection schematic
		[EditorHelp("Detection Schematic", "Select a schematic asset that will be started when the combatant detects a target and starts being cautious of it.\n" +
			"The combatant will be used as 'Machine Object', the detected target as 'Starting Object'.", "")]
		[EditorSeparator]
		public AssetSource<MakinomSchematicAsset> detectionSchematic = new AssetSource<MakinomSchematicAsset>();

		[EditorHelp("Wait", "Wait for the detection schematic to finish before starting to be cautious of the target.", "")]
		[EditorCondition("detectionSchematic.HasAsset", true)]
		[EditorEndCondition]
		[EditorIndent]
		public bool detectionWaitForSchematic = false;


		// caution range
		[EditorHelp("Use Caution Range", "The combatant will only be cautious within a range of its start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving the caution range, the combatant will return to its start position.\n" +
			"If disabled, there is no limit to the caution range.", "")]
		[EditorFoldout("Caution Range", "Optionally only use caution within a defined range of the combatant's start position.", "")]
		public bool useRange = false;

		[EditorEndFoldout]
		[EditorCondition("useRange", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public RangeValue range;


		// critical range
		[EditorFoldout("Critical Range", "The combatant will flee from the target when it's within critical range.\n" +
			"The combatant will flee until the target is outside of the stop range.\n" +
			"The critical range must be smaller than the stop range.", "")]
		[EditorLabel("The critical range must be smaller than the stop range.")]
		public RangeValue criticalRange = new RangeValue(3);

		[EditorHelp("Cancel Casting", "Cancel casting an ability (if possible).", "")]
		[EditorSeparator]
		public bool criticalCancelCasting = false;

		[EditorHelp("Cancel Move Into Range", "Cancel moving into use range of an ability.", "")]
		public bool criticalCancelMoveIntoRange = false;

		[EditorHelp("Prevent Cornered", "The combatant will try to prevent being cornered.\n" +
			"I.e. if the combatant can't move, it'll try to move into different directions, e.g. fleeing toward the enemy.", "")]
		public bool preventCornered = false;

		[EditorHelp("Always Check Critical", "The critical range is checked in all modes.\n" +
			"If disabled, the critical range is only checked when being in caution mode and during casting.", "")]
		public bool criticalAlwaysCheck = false;

		[EditorHelp("Use All Detected", "The combatant will flee from all detected targets that enter the critical range.\n" +
			"If disabled, the combatant only flees from the current target.", "")]
		public bool criticalUseAllDetected = false;

		[EditorHelp("Ignore Conditions", "Ignore the caution conditions for the critical range, " +
			"i.e. the combatant will flee from all detected targets entering the critical range.", "")]
		[EditorEndFoldout]
		[EditorCondition("criticalUseAllDetected", true)]
		[EditorEndCondition]
		public bool criticalIgnoreConditions = false;


		// stop range
		[EditorFoldout("Stop Range", "The combatant will hunt the target until reaching the stop range.\n" +
			"The stop range must be greater than the critical range.", "")]
		[EditorLabel("The stop range must be greater than the critical range.")]
		public RangeValue stopRange = new RangeValue(5);

		[EditorHelp("Use Action Range", "The use range of a selected action is used when moving into range.\n" +
			"A combatant will only move into range when the used action is out of range to the target.\n" +
			"If the action doesn't have a use range, the stop range will be used.", "")]
		[EditorSeparator]
		public bool useActionStopRange = false;


		// stop angle
		[EditorSeparator]
		[EditorTitleLabel("Stop Angle")]
		[EditorEndFoldout]
		public MoveAIStopAngle stopAngle = new MoveAIStopAngle();


		// conditions
		[EditorHelp("Conditions Needed", "Select if all or just one condition must be valid to be cautious of the target.", "")]
		[EditorFoldout("Caution Conditions", "Optionally only use caution when defined conditions are valid.", "")]
		public Needed needed = Needed.One;

		[EditorEndFoldout]
		[EditorEndCondition]
		[EditorArray("Add Caution Condition", "Adds a caution condition.\n" +
			"You can use multiple conditions to determine if the combatant is cautious of the target.", "",
			"Remove", "Removes this caution condition.", "", isMove = true, isCopy = true,
			foldout = true, foldoutText = new string[] {
				"Caution Condition", "Caution conditions determine if the combatant is cautious of the target.", ""
			})]
		public MoveCondition[] condition = new MoveCondition[0];

		public MoveAICaution()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useStopAngle"))
			{
				this.stopAngle.SetData(data);
			}
		}


		/*
		============================================================================
		Caution functions
		============================================================================
		*/
		public bool IsCautious(Combatant combatant, Combatant target)
		{
			if(this.enabled && combatant.IsAggressive)
			{
				if(this.condition != null && this.condition.Length > 0)
				{
					for(int i = 0; i < this.condition.Length; i++)
					{
						if(this.condition[i].IsValid(combatant, target))
						{
							if(Needed.One == this.needed)
							{
								return true;
							}
						}
						else if(Needed.All == this.needed)
						{
							return false;
						}
					}

					if(Needed.All == this.needed)
					{
						return true;
					}
					else if(Needed.One == this.needed)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public bool IsInRange(Vector3 startPosition, Combatant combatant)
		{
			return !this.useRange ||
				this.range == null ||
				this.range.InRange(startPosition, combatant.GameObject);
		}

		public bool IsOutOfRange(Vector3 startPosition, Combatant combatant)
		{
			return this.useRange &&
				this.range != null &&
				this.range.OutOfRange(startPosition, combatant.GameObject);
		}

		public void Use(MoveAIComponent moveAI)
		{
			// change target
			if(this.useTargetChange &&
				moveAI.DetectedTargets.Count > 1)
			{
				for(int i = 0; i < moveAI.DetectedTargets.Count; i++)
				{
					if(moveAI.DetectedTargets[i] == moveAI.TargetCombatant)
					{
						break;
					}
					else if(this.IsCautious(moveAI.Combatant, moveAI.DetectedTargets[i]))
					{
						moveAI.SetTarget(moveAI.DetectedTargets[i], MoveAIMode.CautionHunt);
						return;
					}
				}
			}

			// out of caution range, back to start position
			if(this.IsOutOfRange(moveAI.startPosition, moveAI.Combatant))
			{
				moveAI.targetLostTimeout = -1;
				moveAI.ClearTarget(false);

				moveAI.SetMode(MoveAIMode.Waypoint);
				moveAI.SetMovePosition(moveAI.startPosition);
			}
			// fleeing
			else if(MoveAIMode.CautionFlee == moveAI.mode)
			{
				if(moveAI.CautionStopRange.OutOfRange(moveAI.Combatant.GameObject, moveAI.TargetCombatant.GameObject))
				{
					moveAI.targetPosTimeout = -1;
					moveAI.targetLostTimeout = -1;
					moveAI.SetMode(MoveAIMode.CautionHunt);
				}
				else if(this.preventCornered)
				{
					moveAI.CheckStuck();
				}
			}
			// hunting
			else if(MoveAIMode.CautionHunt == moveAI.mode)
			{
				if(!this.CheckCritical(moveAI))
				{
					Vector3 targetPosition = this.GetTargetPosition(moveAI);

					if(moveAI.CautionStopRange.InRange(targetPosition, moveAI.Combatant.GameObject, true, 0.1f))
					{
						moveAI.targetPosTimeout = -1;
						moveAI.Stop();
					}
					else if(!moveAI.IsTargetLost())
					{
						moveAI.UpdateTargetPosition(true);
					}
				}
			}
		}

		public bool CheckCritical(MoveAIComponent moveAI)
		{
			if(this.enabled &&
				moveAI.TargetCombatant != null &&
				(this.criticalCancelMoveIntoRange || !moveAI.HasActionRange))
			{
				if(this.criticalRange.InRange(moveAI.Combatant.GameObject, moveAI.TargetCombatant.GameObject))
				{
					if(this.criticalCancelCasting)
					{
						moveAI.Combatant.Actions.CancelCast();
					}
					moveAI.targetPosTimeout = -1;
					moveAI.targetLostTimeout = -1;
					moveAI.SetActionTarget(null);
					moveAI.SetMode(MoveAIMode.CautionFlee);
					return true;
				}
				else if(this.criticalUseAllDetected)
				{
					for(int i = 0; i < moveAI.DetectedTargets.Count; i++)
					{
						if((this.criticalIgnoreConditions ||
							this.IsCautious(moveAI.Combatant, moveAI.DetectedTargets[i])) &&
							this.criticalRange.InRange(moveAI.Combatant.GameObject, moveAI.DetectedTargets[i].GameObject))
						{
							if(this.criticalCancelCasting)
							{
								moveAI.Combatant.Actions.CancelCast();
							}
							moveAI.targetPosTimeout = -1;
							moveAI.targetLostTimeout = -1;
							moveAI.SetActionTarget(null);
							moveAI.SetTarget(moveAI.DetectedTargets[i], MoveAIMode.CautionFlee);
							return true;
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public Vector3 GetTargetPosition(MoveAIComponent moveAI)
		{
			if(moveAI.TargetCombatant != null &&
				moveAI.TargetCombatant.GameObject != null)
			{
				MoveAIStopAngle stopAngle = moveAI.StopAngle != null ? moveAI.StopAngle : this.stopAngle;
				if(stopAngle.useStopAngle)
				{
					return moveAI.CautionStopRange.GetAngledPosition(
						moveAI.TargetCombatant.GameObject,
						stopAngle.stopAngle, stopAngle.stopAngleLocal,
						moveAI.settings.horizontalPlane);
				}
				else
				{
					return Vector3.MoveTowards(
						moveAI.TargetCombatant.GameObject.transform.position,
						moveAI.Combatant.GameObject.transform.position,
						moveAI.CautionStopRange.GetInRangeDistance(
							moveAI.Combatant.GameObject, moveAI.TargetCombatant.GameObject));
				}
			}
			else
			{
				return moveAI.Combatant.GameObject.transform.position;
			}
		}

		public bool ReachedTarget(MoveAIComponent moveAI)
		{
			if(this.enabled)
			{
				if(moveAI.CautionStopRange.InRange(this.GetTargetPosition(moveAI), moveAI.Combatant.GameObject, true, 0.1f))
				{
					return true;
				}
				return false;
			}
			return true;
		}
	}
}
