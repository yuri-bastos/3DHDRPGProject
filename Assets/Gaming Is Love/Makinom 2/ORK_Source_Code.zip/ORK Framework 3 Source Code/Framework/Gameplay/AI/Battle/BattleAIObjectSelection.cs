﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.AI
{
	public enum BattleAIObjectType
	{
		User, Target, Player,
		Allies, Enemies, FoundTargets,
		SelectedData, SelectedObject,
		GridRoot, GridCell
	}

	[HighlightSettings(4)]
	public class BattleAIObjectSelection : BaseData, IObjectSelection
	{
		[EditorHelp("Game Object", "Select the game object that will be used:\n" +
			"- User: The user of the battle AI.\n" +
			"- Target: The currently checked target combatant.\n" +
			"- Player: The player. If there is no player, no object will be used.\n" +
			"- Allies: The allies of the user.\n" +
			"- Enemies: The enemies of the user.\n" +
			"- Found Targets: The currently found targets.\n" +
			"- Selected Data: Combatant(s) stored in selected data. If none is found, no object will be used.\n" +
			"- Selected Object: The currently selected object " +
			"(see 'Base/Control > Game Controls > Object Selection' for details).\n" +
			"- Grid Root: The root game object of a grid.\n" +
			"- Grid Cell: The game object(s) of grid cells.", "")]
		public BattleAIObjectType type = BattleAIObjectType.User;


		// selected data
		[EditorCondition("type", BattleAIObjectType.SelectedData)]
		[EditorAutoInit]
		public SelectedData<BattleAIObjectSelection> selectedData;

		[EditorHelp("Only Game Objects", "Only use actual stored game objects, " +
			"e.g. game objects of stored components will not be used.", "")]
		[EditorEndCondition]
		public bool selectedOnlyGameObjects = false;


		// grid root
		[EditorHelp("Grid Key", "The key used to store the grid.\n" +
			"You can store multiple grids by using different keys.", "")]
		[EditorCondition("type", BattleAIObjectType.GridRoot)]
		[EditorEndCondition]
		[EditorAutoInit]
		public StringValue<BattleAIObjectSelection> gridKey;


		// grid cell
		[EditorCondition("type", BattleAIObjectType.GridCell)]
		[EditorEndCondition]
		[EditorAutoInit]
		public GridIndex<BattleAIObjectSelection> gridIndex;


		// child object
		[EditorHelp("Use Root", "Use the root of the game object (i.e. the uppermost parent game object).\n" +
			"When using 'Child Object' they'll be searched from the root.", "")]
		public bool useRoot = false;

		[EditorHelp("Child Object", "A child object of the selected object will be used (e.g. Path/to/Child).\n" +
			"Leave empty if you don't want to use a child object.", "")]
		[EditorWidth(true)]
		public string childName = "";

		public BattleAIObjectSelection()
		{

		}

		public bool Equals(BattleAIObjectSelection check)
		{
			if(this.useRoot == check.useRoot &&
				this.childName == check.childName)
			{
				if(BattleAIObjectType.SelectedData == this.type)
				{
					return this.selectedOnlyGameObjects == check.selectedOnlyGameObjects &&
						this.selectedData.Equals(check.selectedData);
				}
				else if(BattleAIObjectType.GridRoot == this.type)
				{
					return this.gridKey.Equals(check.gridKey);
				}
				else if(BattleAIObjectType.GridCell == this.type)
				{
					return this.gridIndex.Equals(check.gridIndex);
				}
				else
				{
					return this.type == check.type;
				}
			}
			return false;
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public Combatant GetCombatant(IDataCall call)
		{
			return this.GetCombatant(call as BattleAICall);
		}

		public Combatant GetCombatant(BattleAICall call)
		{
			Combatant combatant = null;
			if(call != null)
			{
				if(BattleAIObjectType.User == this.type)
				{
					combatant = call.user;
				}
				else if(BattleAIObjectType.Target == this.type)
				{
					combatant = call.checkTarget;
				}
				else if(BattleAIObjectType.Player == this.type)
				{
					combatant = ORK.Game.ActiveGroup.Leader;
				}
				else if(BattleAIObjectType.Allies == this.type)
				{
					if(call.allies != null)
					{
						for(int i = 0; i < call.allies.Count; i++)
						{
							if(call.allies[i] != null)
							{
								combatant = call.allies[i];
								break;
							}
						}
					}
				}
				else if(BattleAIObjectType.Enemies == this.type)
				{
					if(call.enemies != null)
					{
						for(int i = 0; i < call.enemies.Count; i++)
						{
							if(call.enemies[i] != null &&
								call.enemies[i].GameObject != null)
							{
								combatant = call.enemies[i];
								break;
							}
						}
					}
				}
				else if(BattleAIObjectType.FoundTargets == this.type)
				{
					if(call.foundTargets != null)
					{
						for(int i = 0; i < call.foundTargets.Count; i++)
						{
							if(call.foundTargets[i] != null &&
								call.foundTargets[i].GameObject != null)
							{
								combatant = call.foundTargets[i];
								break;
							}
						}
					}
				}
				else if(BattleAIObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> handlers = this.selectedData.GetHandlers(call);
					if(handlers.Count > 0)
					{
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < handlers.Count; i++)
						{
							if(handlers[i] != null)
							{
								combatant = ORKSelectedDataHelper.GetCombatant(handlers[i].Get(tmpKey));
								if(combatant != null)
								{
									break;
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
				}
				else if(BattleAIObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						combatant = ORKComponentHelper.ToCombatant(Maki.Game.Interactions.Selected.gameObject);
					}
				}
				else if(BattleAIObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null)
					{
						combatant = ORKComponentHelper.ToCombatant(grid.GameObject);
					}
				}
				else if(BattleAIObjectType.GridCell == this.type)
				{
					combatant = ORKComponentHelper.ToCombatant(this.gridIndex.GetFirstCellObject(call));
				}
			}
			return combatant;
		}

		public List<Combatant> GetCombatants(IDataCall call)
		{
			return this.GetCombatants(call as BattleAICall);
		}

		public List<Combatant> GetCombatants(BattleAICall call)
		{
			List<Combatant> list = null;
			if(call != null)
			{
				if(BattleAIObjectType.User == this.type)
				{
					list = new List<Combatant>();
					list.Add(call.user);
				}
				else if(BattleAIObjectType.Target == this.type)
				{
					if(call.checkTarget != null)
					{
						list = new List<Combatant>();
						list.Add(call.checkTarget);
					}
				}
				else if(BattleAIObjectType.Player == this.type)
				{
					if(ORK.Game.ActiveGroup.Leader != null)
					{
						list = new List<Combatant>();
						list.Add(ORK.Game.ActiveGroup.Leader);
					}
				}
				else if(BattleAIObjectType.Allies == this.type)
				{
					if(call.allies != null &&
						call.allies.Count > 0)
					{
						list = new List<Combatant>();
						for(int i = 0; i < call.allies.Count; i++)
						{
							if(call.allies[i] != null)
							{
								list.Add(call.allies[i]);
							}
						}
					}
				}
				else if(BattleAIObjectType.Enemies == this.type)
				{
					if(call.enemies != null &&
						call.enemies.Count > 0)
					{
						list = new List<Combatant>();
						for(int i = 0; i < call.enemies.Count; i++)
						{
							if(call.enemies[i] != null)
							{
								list.Add(call.enemies[i]);
							}
						}
					}
				}
				else if(BattleAIObjectType.FoundTargets == this.type)
				{
					if(call.foundTargets != null &&
						call.foundTargets.Count > 0)
					{
						list = new List<Combatant>();
						for(int i = 0; i < call.foundTargets.Count; i++)
						{
							if(call.foundTargets[i] != null)
							{
								list.Add(call.foundTargets[i]);
							}
						}
					}
				}
				else if(BattleAIObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> handlers = this.selectedData.GetHandlers(call);
					if(handlers.Count > 0)
					{
						list = new List<Combatant>();
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < handlers.Count; i++)
						{
							if(handlers[i] != null)
							{
								ORKSelectedDataHelper.GetCombatants(handlers[i].Get(tmpKey), ref list);
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
				}
				else if(BattleAIObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						list = new List<Combatant>();
						Combatant combatant = ORKComponentHelper.ToCombatant(Maki.Game.Interactions.Selected.gameObject);
						if(combatant != null)
						{
							list.Add(combatant);
						}
					}
				}
				else if(BattleAIObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null && grid.GameObject != null)
					{
						list = new List<Combatant>();
						Combatant combatant = ORKComponentHelper.ToCombatant(grid.GameObject);
						if(combatant != null)
						{
							list.Add(combatant);
						}
					}
				}
				else if(BattleAIObjectType.GridCell == this.type)
				{
					List<GameObject> cells = Maki.Pooling.GameObjectLists.Get();
					this.gridIndex.GetCellObjects(ref cells, call);
					if(cells.Count > 0)
					{
						list = new List<Combatant>();
						for(int i = 0; i < cells.Count; i++)
						{
							Combatant combatant = ORKComponentHelper.ToCombatant(cells[i]);
							if(combatant != null)
							{
								list.Add(combatant);
							}
						}
					}
					Maki.Pooling.GameObjectLists.Add(cells);
				}
			}
			return list;
		}


		/*
		============================================================================
		Formula object functions
		============================================================================
		*/
		public object GetFormulaObject(IDataCall call)
		{
			return this.GetCombatant(call as BattleAICall);
		}


		/*
		============================================================================
		Game object functions
		============================================================================
		*/
		public GameObject GetObject(IDataCall call)
		{
			return this.GetObject(call as BattleAICall);
		}

		public GameObject GetObject(BattleAICall call)
		{
			GameObject gameObject = null;
			if(call != null)
			{
				if(BattleAIObjectType.User == this.type)
				{
					gameObject = call.user.GameObject;
				}
				else if(BattleAIObjectType.Target == this.type)
				{
					gameObject = call.checkTarget != null ? call.checkTarget.GameObject : null;
				}
				else if(BattleAIObjectType.Player == this.type)
				{
					gameObject = ORK.Game.ActiveGroup.Leader != null ? ORK.Game.ActiveGroup.Leader.GameObject : null;
				}
				else if(BattleAIObjectType.Allies == this.type)
				{
					if(call.allies != null)
					{
						for(int i = 0; i < call.allies.Count; i++)
						{
							if(call.allies[i] != null &&
								call.allies[i].GameObject != null)
							{
								gameObject = call.allies[i].GameObject;
								break;
							}
						}
					}
				}
				else if(BattleAIObjectType.Enemies == this.type)
				{
					if(call.enemies != null)
					{
						for(int i = 0; i < call.enemies.Count; i++)
						{
							if(call.enemies[i] != null &&
								call.enemies[i].GameObject != null)
							{
								gameObject = call.enemies[i].GameObject;
								break;
							}
						}
					}
				}
				else if(BattleAIObjectType.FoundTargets == this.type)
				{
					if(call.foundTargets != null)
					{
						for(int i = 0; i < call.foundTargets.Count; i++)
						{
							if(call.foundTargets[i] != null &&
								call.foundTargets[i].GameObject != null)
							{
								gameObject = call.foundTargets[i].GameObject;
								break;
							}
						}
					}
				}
				else if(BattleAIObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> handlers = this.selectedData.GetHandlers(call);
					if(handlers.Count > 0)
					{
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < handlers.Count; i++)
						{
							if(handlers[i] != null)
							{
								gameObject = this.selectedOnlyGameObjects ?
									handlers[i].GetOnlyGameObject(tmpKey) :
									handlers[i].GetGameObject(tmpKey);
								if(gameObject != null)
								{
									break;
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
				}
				else if(BattleAIObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						gameObject = Maki.Game.Interactions.Selected.gameObject;
					}
				}
				else if(BattleAIObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null)
					{
						gameObject = grid.GameObject;
					}
				}
				else if(BattleAIObjectType.GridCell == this.type)
				{
					gameObject = this.gridIndex.GetFirstCellObject(call);
				}

				if(gameObject != null)
				{
					if(this.useRoot)
					{
						gameObject = gameObject.transform.root.gameObject;
					}
					if(this.childName != "")
					{
						gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
					}
				}
			}
			return gameObject;
		}

		public List<GameObject> GetObjects(IDataCall call)
		{
			return this.GetObjects(call as BattleAICall);
		}

		public List<GameObject> GetObjects(BattleAICall call)
		{
			List<GameObject> list = null;
			if(call != null)
			{
				if(BattleAIObjectType.User == this.type)
				{
					if(call.user.GameObject != null)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						list.Add(call.user.GameObject);
					}
				}
				else if(BattleAIObjectType.Target == this.type)
				{
					if(call.checkTarget != null &&
						call.checkTarget.GameObject != null)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						list.Add(call.checkTarget.GameObject);
					}
				}
				else if(BattleAIObjectType.Player == this.type)
				{
					if(ORK.Game.ActiveGroup.Leader != null &&
						ORK.Game.ActiveGroup.Leader.GameObject != null)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						list.Add(ORK.Game.ActiveGroup.Leader.GameObject);
					}
				}
				else if(BattleAIObjectType.Allies == this.type)
				{
					if(call.allies != null &&
						call.allies.Count > 0)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						for(int i = 0; i < call.allies.Count; i++)
						{
							if(call.allies[i] != null &&
								call.allies[i].GameObject != null)
							{
								list.Add(call.allies[i].GameObject);
							}
						}
					}
				}
				else if(BattleAIObjectType.Enemies == this.type)
				{
					if(call.enemies != null &&
						call.enemies.Count > 0)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						for(int i = 0; i < call.enemies.Count; i++)
						{
							if(call.enemies[i] != null &&
								call.enemies[i].GameObject != null)
							{
								list.Add(call.enemies[i].GameObject);
							}
						}
					}
				}
				else if(BattleAIObjectType.FoundTargets == this.type)
				{
					if(call.foundTargets != null &&
						call.foundTargets.Count > 0)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						for(int i = 0; i < call.foundTargets.Count; i++)
						{
							if(call.foundTargets[i] != null &&
								call.foundTargets[i].GameObject != null)
							{
								list.Add(call.foundTargets[i].GameObject);
							}
						}
					}
				}
				else if(BattleAIObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> handlers = this.selectedData.GetHandlers(call);
					if(handlers.Count > 0)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < handlers.Count; i++)
						{
							if(handlers[i] != null)
							{
								if(this.selectedOnlyGameObjects)
								{
									handlers[i].GetOnlyGameObjects(tmpKey, ref list);
								}
								else
								{
									handlers[i].GetGameObjects(tmpKey, ref list);
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
				}
				else if(BattleAIObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						list.Add(Maki.Game.Interactions.Selected.gameObject);
					}
				}
				else if(BattleAIObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null && grid.GameObject != null)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						list.Add(grid.GameObject);
					}
				}
				else if(BattleAIObjectType.GridCell == this.type)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					this.gridIndex.GetCellObjects(ref list, call);
				}
			}

			if(list == null)
			{
				list = Maki.Pooling.GameObjectLists.Get();
			}
			else if(list.Count > 0)
			{
				if(this.useRoot)
				{
					for(int i = 0; i < list.Count; i++)
					{
						list[i] = list[i].transform.root.gameObject;
					}
				}
				if(this.childName != "")
				{
					for(int i = 0; i < list.Count; i++)
					{
						list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
					}
				}
			}
			return list;
		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public T GetFirstComponent<T>(IDataCall call, ComponentScopeSingle scope) where T : Component
		{
			return this.GetFirstComponent<T>(call as BattleAICall, scope);
		}

		public T GetFirstComponent<T>(BattleAICall call, ComponentScopeSingle scope) where T : Component
		{
			List<GameObject> list = null;
			GameObject gameObject = null;

			if(call != null)
			{
				if(BattleAIObjectType.User == this.type)
				{
					if(call.user.GameObject != null)
					{
						gameObject = call.user.GameObject;
					}
				}
				else if(BattleAIObjectType.Target == this.type)
				{
					if(call.checkTarget != null &&
						call.checkTarget.GameObject != null)
					{
						gameObject = call.checkTarget.GameObject;
					}
				}
				else if(BattleAIObjectType.Player == this.type)
				{
					if(ORK.Game.ActiveGroup.Leader != null &&
						ORK.Game.ActiveGroup.Leader.GameObject != null)
					{
						gameObject = ORK.Game.ActiveGroup.Leader.GameObject;
					}
				}
				else if(BattleAIObjectType.Allies == this.type)
				{
					if(call.allies != null &&
						call.allies.Count > 0)
					{
						for(int i = 0; i < call.allies.Count; i++)
						{
							if(call.allies[i] != null &&
								call.allies[i].GameObject != null)
							{
								gameObject = call.allies[i].GameObject;
								if(this.useRoot)
								{
									gameObject = gameObject.transform.root.gameObject;
								}
								if(this.childName != "")
								{
									gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
								}

								T comp = ComponentHelper.Get<T>(gameObject, scope);
								if(comp != null)
								{
									return comp;
								}
								else
								{
									gameObject = null;
								}
							}
						}
					}
				}
				else if(BattleAIObjectType.Enemies == this.type)
				{
					if(call.enemies != null &&
						call.enemies.Count > 0)
					{
						for(int i = 0; i < call.enemies.Count; i++)
						{
							if(call.enemies[i] != null &&
								call.enemies[i].GameObject != null)
							{
								gameObject = call.enemies[i].GameObject;
								if(this.useRoot)
								{
									gameObject = gameObject.transform.root.gameObject;
								}
								if(this.childName != "")
								{
									gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
								}

								T comp = ComponentHelper.Get<T>(gameObject, scope);
								if(comp != null)
								{
									return comp;
								}
								else
								{
									gameObject = null;
								}
							}
						}
					}
				}
				else if(BattleAIObjectType.FoundTargets == this.type)
				{
					if(call.foundTargets != null &&
						call.foundTargets.Count > 0)
					{
						for(int i = 0; i < call.foundTargets.Count; i++)
						{
							if(call.foundTargets[i] != null &&
								call.foundTargets[i].GameObject != null)
							{
								gameObject = call.foundTargets[i].GameObject;
								if(this.useRoot)
								{
									gameObject = gameObject.transform.root.gameObject;
								}
								if(this.childName != "")
								{
									gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
								}

								T comp = ComponentHelper.Get<T>(gameObject, scope);
								if(comp != null)
								{
									return comp;
								}
								else
								{
									gameObject = null;
								}
							}
						}
					}
				}
				else if(BattleAIObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> handlers = this.selectedData.GetHandlers(call);
					if(handlers.Count > 0)
					{
						if(this.selectedOnlyGameObjects)
						{
							list = Maki.Pooling.GameObjectLists.Get();
						}
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < handlers.Count; i++)
						{
							if(handlers[i] != null)
							{
								if(this.selectedOnlyGameObjects)
								{
									handlers[i].GetOnlyGameObjects(tmpKey, ref list);
								}
								else
								{
									T component = handlers[i].GetComponent<T>(
										tmpKey, ComponentHelper.FromSingleScope(scope));
									if(component != null)
									{
										Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
										return component;
									}
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
				}
				else if(BattleAIObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						gameObject = Maki.Game.Interactions.Selected.gameObject;
					}
				}
				else if(BattleAIObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null && grid.GameObject != null)
					{
						gameObject = grid.GameObject;
					}
				}
				else if(BattleAIObjectType.GridCell == this.type)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					this.gridIndex.GetCellObjects(ref list, call);
				}
			}

			if(gameObject != null)
			{
				if(this.useRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				if(this.childName != "")
				{
					gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
				}

				T comp = ComponentHelper.Get<T>(gameObject, scope);
				if(comp != null)
				{
					return comp;
				}
			}
			else if(list != null)
			{
				if(list.Count > 0)
				{
					if(this.useRoot)
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = list[i].transform.root.gameObject;
						}
					}
					if(this.childName != "")
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
						}
					}

					T comp = ComponentHelper.Get<T>(list, scope);
					if(comp != null)
					{
						Maki.Pooling.GameObjectLists.Add(list);
						return comp;
					}
				}
				Maki.Pooling.GameObjectLists.Add(list);
			}
			return null;
		}

		public List<Component> GetAllComponents(BattleAICall call, ComponentScope scope, string componentName)
		{
			List<Component> components = null;
			List<GameObject> list = null;
			GameObject gameObject = null;

			if(BattleAIObjectType.User == this.type)
			{
				if(call.user.GameObject != null)
				{
					gameObject = call.user.GameObject;
				}
			}
			else if(BattleAIObjectType.Target == this.type)
			{
				if(call.checkTarget != null &&
					call.checkTarget.GameObject != null)
				{
					gameObject = call.checkTarget.GameObject;
				}
			}
			else if(BattleAIObjectType.Player == this.type)
			{
				if(Maki.Game.Player.GameObject != null)
				{
					gameObject = Maki.Game.Player.GameObject;
				}
			}
			else if(BattleAIObjectType.Allies == this.type)
			{
				if(call.allies != null &&
					call.allies.Count > 0)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					for(int i = 0; i < call.allies.Count; i++)
					{
						if(call.allies[i] != null &&
							call.allies[i].GameObject != null)
						{
							list.Add(call.allies[i].GameObject);
						}
					}
				}
			}
			else if(BattleAIObjectType.Enemies == this.type)
			{
				if(call.enemies != null &&
					call.enemies.Count > 0)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					for(int i = 0; i < call.enemies.Count; i++)
					{
						if(call.enemies[i] != null &&
							call.enemies[i].GameObject != null)
						{
							list.Add(call.enemies[i].GameObject);
						}
					}
				}
			}
			else if(BattleAIObjectType.FoundTargets == this.type)
			{
				if(call.foundTargets != null &&
					call.foundTargets.Count > 0)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					for(int i = 0; i < call.foundTargets.Count; i++)
					{
						if(call.foundTargets[i] != null &&
							call.foundTargets[i].GameObject != null)
						{
							list.Add(call.foundTargets[i].GameObject);
						}
					}
				}
			}
			else if(BattleAIObjectType.SelectedData == this.type)
			{
				List<SelectedDataHandler> handlers = this.selectedData.GetHandlers(call);
				if(handlers.Count > 0)
				{
					if(this.selectedOnlyGameObjects)
					{
						list = Maki.Pooling.GameObjectLists.Get();
					}
					else
					{
						components = new List<Component>();
					}
					string tmpKey = this.selectedData.key.GetValue(call);
					for(int i = 0; i < handlers.Count; i++)
					{
						if(handlers[i] != null)
						{
							if(this.selectedOnlyGameObjects)
							{
								handlers[i].GetOnlyGameObjects(tmpKey, ref list);
							}
							else
							{
								handlers[i].GetComponents(tmpKey, ref components, scope, componentName);
							}
						}
					}
				}
				Maki.Pooling.SelectedDataHandlerLists.Add(handlers);
			}
			else if(BattleAIObjectType.SelectedObject == this.type)
			{
				if(Maki.Game.Interactions.Selected != null)
				{
					gameObject = Maki.Game.Interactions.Selected.gameObject;
				}
			}
			else if(BattleAIObjectType.GridRoot == this.type)
			{
				GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
				if(grid != null && grid.GameObject != null)
				{
					gameObject = grid.GameObject;
				}
			}
			else if(BattleAIObjectType.GridCell == this.type)
			{
				list = Maki.Pooling.GameObjectLists.Get();
				this.gridIndex.GetCellObjects(ref list, call);
			}

			if(gameObject != null)
			{
				if(this.useRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				if(this.childName != "")
				{
					gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
				}

				components = new List<Component>();
				if(ComponentHelper.IsSingleScope(scope))
				{
					Component comp = ComponentHelper.GetSingle(gameObject, scope, componentName);
					if(comp != null)
					{
						components.Add(comp);
					}
				}
				else
				{
					Component[] comps = ComponentHelper.GetAll(gameObject, scope, componentName);
					if(comps != null)
					{
						components.AddRange(comps);
					}
				}
			}
			else if(list != null)
			{
				if(list.Count > 0)
				{
					if(this.useRoot)
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = list[i].transform.root.gameObject;
						}
					}
					if(this.childName != "")
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
						}
					}

					components = ComponentHelper.Get(list, scope, componentName);
				}
				Maki.Pooling.GameObjectLists.Add(list);
			}
			if(components == null)
			{
				components = new List<Component>();
			}
			return components;
		}


		/*
		============================================================================
		Object variables functions
		============================================================================
		*/
		public void GetObjectVariables(IDataCall call, List<VariableHandler> handlers, ComponentScope scope)
		{
			this.GetObjectVariables(call as BattleAICall, handlers, scope);
		}

		public void GetObjectVariables(BattleAICall call, List<VariableHandler> handlers, ComponentScope scope)
		{
			List<GameObject> list = null;
			GameObject gameObject = null;

			if(call != null)
			{
				if(BattleAIObjectType.User == this.type)
				{
					handlers.Add(call.user.Variables);
				}
				else if(BattleAIObjectType.Target == this.type)
				{
					if(call.checkTarget != null)
					{
						handlers.Add(call.checkTarget.Variables);
					}
				}
				else if(BattleAIObjectType.Player == this.type)
				{
					if(ORK.Game.ActiveGroup.Leader != null)
					{
						handlers.Add(ORK.Game.ActiveGroup.Leader.Variables);
					}
				}
				else if(BattleAIObjectType.Allies == this.type)
				{
					if(call.allies != null &&
						call.allies.Count > 0)
					{
						for(int i = 0; i < call.allies.Count; i++)
						{
							if(call.allies[i] != null)
							{
								handlers.Add(call.allies[i].Variables);
							}
						}
					}
				}
				else if(BattleAIObjectType.Enemies == this.type)
				{
					if(call.enemies != null &&
						call.enemies.Count > 0)
					{
						for(int i = 0; i < call.enemies.Count; i++)
						{
							if(call.enemies[i] != null)
							{
								handlers.Add(call.enemies[i].Variables);
							}
						}
					}
				}
				else if(BattleAIObjectType.FoundTargets == this.type)
				{
					if(call.foundTargets != null &&
						call.foundTargets.Count > 0)
					{
						for(int i = 0; i < call.foundTargets.Count; i++)
						{
							if(call.foundTargets[i] != null)
							{
								handlers.Add(call.foundTargets[i].Variables);
							}
						}
					}
				}
				else if(BattleAIObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> tmp = this.selectedData.GetHandlers(call);
					if(tmp.Count > 0)
					{
						if(this.selectedOnlyGameObjects)
						{
							list = Maki.Pooling.GameObjectLists.Get();
						}
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < tmp.Count; i++)
						{
							if(tmp[i] != null)
							{
								if(this.selectedOnlyGameObjects)
								{
									tmp[i].GetOnlyGameObjects(tmpKey, ref list);
								}
								else
								{
									tmp[i].GetVariableHandlers(tmpKey, ref handlers, scope);
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(tmp);
				}
				else if(BattleAIObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						gameObject = Maki.Game.Interactions.Selected.gameObject;
					}
				}
				else if(BattleAIObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null && grid.GameObject != null)
					{
						gameObject = grid.GameObject;
					}
				}
				else if(BattleAIObjectType.GridCell == this.type)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					this.gridIndex.GetCellObjects(ref list, call);
				}
			}

			if(gameObject != null)
			{
				if(this.useRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				if(this.childName != "")
				{
					gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
				}

				if(ComponentHelper.IsSingleScope(scope))
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetSingle<ObjectVariablesComponent>(gameObject, scope);
					if(comp != null &&
						!handlers.Contains(comp.Handler))
					{
						handlers.Add(comp.Handler);
					}
				}
				else
				{
					ObjectVariablesComponent[] comps = ComponentHelper.
						GetAll<ObjectVariablesComponent>(gameObject, scope);
					if(comps != null)
					{
						for(int j = 0; j < comps.Length; j++)
						{
							if(!handlers.Contains(comps[j].Handler))
							{
								handlers.Add(comps[j].Handler);
							}
						}
					}
				}
			}
			else if(list != null)
			{
				if(list.Count > 0)
				{
					if(this.useRoot)
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = list[i].transform.root.gameObject;
						}
					}
					if(this.childName != "")
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
						}
					}

					if(ComponentHelper.IsSingleScope(scope))
					{
						for(int i = 0; i < list.Count; i++)
						{
							ObjectVariablesComponent comp = ComponentHelper.
								GetSingle<ObjectVariablesComponent>(list[i], scope);
							if(comp != null &&
								!handlers.Contains(comp.Handler))
							{
								handlers.Add(comp.Handler);
							}
						}
					}
					else
					{
						for(int i = 0; i < list.Count; i++)
						{
							ObjectVariablesComponent[] comps = ComponentHelper.
								GetAll<ObjectVariablesComponent>(list[i], scope);
							if(comps != null)
							{
								for(int j = 0; j < comps.Length; j++)
								{
									if(!handlers.Contains(comps[j].Handler))
									{
										handlers.Add(comps[j].Handler);
									}
								}
							}
						}
					}
				}
				Maki.Pooling.GameObjectLists.Add(list);
			}
		}

		public void GetSelectedData(IDataCall call, List<SelectedDataHandler> handlers, ComponentScope scope)
		{
			this.GetSelectedData(call as BattleAICall, handlers, scope);
		}

		public void GetSelectedData(BattleAICall call, List<SelectedDataHandler> handlers, ComponentScope scope)
		{
			List<GameObject> list = null;
			GameObject gameObject = null;

			if(call != null)
			{
				if(BattleAIObjectType.User == this.type)
				{
					handlers.Add(call.user.SelectedData);
				}
				else if(BattleAIObjectType.Target == this.type)
				{
					if(call.checkTarget != null)
					{
						handlers.Add(call.checkTarget.SelectedData);
					}
				}
				else if(BattleAIObjectType.Player == this.type)
				{
					if(ORK.Game.ActiveGroup.Leader != null)
					{
						handlers.Add(ORK.Game.ActiveGroup.Leader.SelectedData);
					}
				}
				else if(BattleAIObjectType.Allies == this.type)
				{
					if(call.allies != null &&
						call.allies.Count > 0)
					{
						for(int i = 0; i < call.allies.Count; i++)
						{
							if(call.allies[i] != null)
							{
								handlers.Add(call.allies[i].SelectedData);
							}
						}
					}
				}
				else if(BattleAIObjectType.Enemies == this.type)
				{
					if(call.enemies != null &&
						call.enemies.Count > 0)
					{
						for(int i = 0; i < call.enemies.Count; i++)
						{
							if(call.enemies[i] != null)
							{
								handlers.Add(call.enemies[i].SelectedData);
							}
						}
					}
				}
				else if(BattleAIObjectType.FoundTargets == this.type)
				{
					if(call.foundTargets != null &&
						call.foundTargets.Count > 0)
					{
						for(int i = 0; i < call.foundTargets.Count; i++)
						{
							if(call.foundTargets[i] != null)
							{
								handlers.Add(call.foundTargets[i].SelectedData);
							}
						}
					}
				}
				else if(BattleAIObjectType.SelectedData == this.type)
				{
					List<SelectedDataHandler> tmp = this.selectedData.GetHandlers(call);
					if(tmp.Count > 0)
					{
						list = Maki.Pooling.GameObjectLists.Get();
						string tmpKey = this.selectedData.key.GetValue(call);
						for(int i = 0; i < tmp.Count; i++)
						{
							if(tmp[i] != null)
							{
								if(this.selectedOnlyGameObjects)
								{
									tmp[i].GetOnlyGameObjects(tmpKey, ref list);
								}
								else
								{
									tmp[i].GetGameObjects(tmpKey, ref list);
								}
							}
						}
					}
					Maki.Pooling.SelectedDataHandlerLists.Add(tmp);
				}
				else if(BattleAIObjectType.SelectedObject == this.type)
				{
					if(Maki.Game.Interactions.Selected != null)
					{
						gameObject = Maki.Game.Interactions.Selected.gameObject;
					}
				}
				else if(BattleAIObjectType.GridRoot == this.type)
				{
					GameObjectGrid grid = Maki.Game.GetGrid(this.gridKey.GetValue(call));
					if(grid != null && grid.GameObject != null)
					{
						gameObject = grid.GameObject;
					}
				}
				else if(BattleAIObjectType.GridCell == this.type)
				{
					list = Maki.Pooling.GameObjectLists.Get();
					this.gridIndex.GetCellObjects(ref list, call);
				}
			}

			if(gameObject != null)
			{
				if(this.useRoot)
				{
					gameObject = gameObject.transform.root.gameObject;
				}
				if(this.childName != "")
				{
					gameObject = TransformHelper.GetChildObject(this.childName, gameObject);
				}

				if(ComponentHelper.IsSingleScope(scope))
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetSingle<ObjectVariablesComponent>(gameObject, scope);
					if(comp != null &&
						!handlers.Contains(comp.SelectedData))
					{
						handlers.Add(comp.SelectedData);
					}
				}
				else
				{
					ObjectVariablesComponent[] comps = ComponentHelper.
						GetAll<ObjectVariablesComponent>(gameObject, scope);
					if(comps != null)
					{
						for(int j = 0; j < comps.Length; j++)
						{
							if(!handlers.Contains(comps[j].SelectedData))
							{
								handlers.Add(comps[j].SelectedData);
							}
						}
					}
				}
			}
			else if(list != null)
			{
				if(list.Count > 0)
				{
					if(this.useRoot)
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = list[i].transform.root.gameObject;
						}
					}
					if(this.childName != "")
					{
						for(int i = 0; i < list.Count; i++)
						{
							list[i] = TransformHelper.GetChildObject(this.childName, list[i]);
						}
					}

					if(ComponentHelper.IsSingleScope(scope))
					{
						for(int i = 0; i < list.Count; i++)
						{
							ObjectVariablesComponent comp = ComponentHelper.
								GetSingle<ObjectVariablesComponent>(list[i], scope);
							if(comp != null &&
								!handlers.Contains(comp.SelectedData))
							{
								handlers.Add(comp.SelectedData);
							}
						}
					}
					else
					{
						for(int i = 0; i < list.Count; i++)
						{
							ObjectVariablesComponent[] comps = ComponentHelper.
								GetAll<ObjectVariablesComponent>(list[i], scope);
							if(comps != null)
							{
								for(int j = 0; j < comps.Length; j++)
								{
									if(!handlers.Contains(comps[j].SelectedData))
									{
										handlers.Add(comps[j].SelectedData);
									}
								}
							}
						}
					}
				}
				Maki.Pooling.GameObjectLists.Add(list);
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override string ToString()
		{
			if(BattleAIObjectType.SelectedData == this.type)
			{
				return this.selectedData.ToString();
			}
			else if(BattleAIObjectType.GridRoot == this.type)
			{
				return "Grid Root(" + this.gridKey.ToString() + ")";
			}
			else if(BattleAIObjectType.GridCell == this.type)
			{
				return "Grid Cell(" + this.gridIndex.gridKey.ToString() + ")";
			}
			else
			{
				return this.type.ToString();
			}
		}
	}
}
