﻿
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.ORKFramework.Components;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Change Move AI", "Changes the move AI of the user.", "")]
	[NodeInfo("Move AI")]
	public class ChangeMoveAINode : BaseAINode
	{
		[EditorHelp("Restore Move AI", "Restore the move AI to the one originally used by the combatant.", "")]
		public bool restore = false;

		[EditorHelp("Move AI", "Select the move AI that will be used.", "")]
		[EditorCondition("restore", false)]
		[EditorEndCondition]
		public AssetSelection<MoveAIAsset> move = new AssetSelection<MoveAIAsset>();

		public ChangeMoveAINode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(call.user.Object.MoveAI != null)
			{
				if(this.restore)
				{
					call.user.Object.MoveAI.ChangeMoveAI(call.user.Object.MoveAI.originalSettings);
				}
				else if(this.move.StoredAsset != null)
				{
					call.user.Object.MoveAI.ChangeMoveAI(this.move.StoredAsset.Settings);
				}
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.restore ? "Restore" : this.move.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Change Move AI Mode", "Changes the use mode of the user's move AI.", "")]
	[NodeInfo("Move AI")]
	public class ChangeMoveAIModeNode : BaseAINode
	{
		[EditorHelp("Restore Default", "Restore the default use mode of the move AI (defined in the move AI's settings).", "")]
		public bool restore = false;

		[EditorHelp("Use Mode", "Select the use mode of the move AI:\n" +
			"- Auto: Automatically uses the different behaviours (e.g. hunting, fleeing).\n" +
			"- Idle: Forces idle mode, only following waypoints (if used).\n" +
			"- Hunt: Forces hunting.\n" +
			"- Flee: Forces fleeing.\n" +
			"- Caution: Forces caution.\n" +
			"- Protect: Forces protecting group members.", "")]
		[EditorCondition("restore", false)]
		[EditorEndCondition]
		public MoveAIUseMode useMode = MoveAIUseMode.Auto;

		public ChangeMoveAIModeNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(call.user.Object.MoveAI != null)
			{
				call.user.Object.MoveAI.UseMode = this.restore ?
					call.user.Object.MoveAI.settings.useMode : this.useMode;
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.restore ? "Restore" : this.useMode.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Change Move AI Stop Angle", "Changes the stop angle of the user's move AI.\n" +
		"The stop angle is used by hunting and caution modes to optionally move to a specific position around the target.\n" +
		"The used angle value defined here is calcualted only when setting the stop angle, not for each time it's used by the move AI.", "")]
	[NodeInfo("Move AI")]
	public class ChangeMoveAIStopAngleNode : BaseAINode
	{
		[EditorHelp("Restore Default", "Restore the default stop angle (defined in the move AI's settings).", "")]
		public bool restore = false;

		[EditorCondition("restore", false)]
		[EditorEndCondition]
		public MoveAIStopAngle<BattleAIObjectSelection> stopAngle = new MoveAIStopAngle<BattleAIObjectSelection>();

		public ChangeMoveAIStopAngleNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(call.user.Object.MoveAI != null)
			{
				call.user.Object.MoveAI.StopAngle = this.restore ? null : this.stopAngle.ToStopAngle(call);
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.restore ? "Restore" : this.stopAngle.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Move AI Detection", "Checks if the targets are detected by the combatant's move AI detection.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Move AI", "Check")]
	public class CheckMoveAIDetectionNode : BaseAICheckNode
	{
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;

		public CheckMoveAIDetectionNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAISettings.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(user.Object.MoveAI != null &&
				user.Object.MoveAI.settings.useDetection)
			{
				// check for status conditions
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(user.Object.MoveAI.settings.Detect(user, list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Move AI Hunting", "Checks if the targets are valid for hunting due to the " +
		"combatant's move AI hunting conditions. " +
		"The combatant needs to be aggressive in order to hunt targets.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Move AI", "Check")]
	public class CheckMoveAIHuntingNode : BaseAICheckNode
	{
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;

		public CheckMoveAIHuntingNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAISettings.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(user.Object.MoveAI != null &&
				user.Object.MoveAI.settings.hunting.enabled)
			{
				// check for status conditions
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(user.Object.MoveAI.settings.hunting.IsHunting(user, list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Move AI Flee", "Checks if the targets are valid for fleeing due to the " +
		"combatant's move AI flee conditions.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Move AI", "Check")]
	public class CheckMoveAIFleeNode : BaseAICheckNode
	{
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;

		public CheckMoveAIFleeNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAISettings.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(user.Object.MoveAI != null &&
				user.Object.MoveAI.settings.flee.enabled)
			{
				// check for status conditions
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(user.Object.MoveAI.settings.flee.IsFlee(user, list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Move AI Caution", "Checks if the targets are valid for being cautious due to the " +
		"combatant's move AI caution conditions.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Move AI", "Check")]
	public class CheckMoveAICautionNode : BaseAICheckNode
	{
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;

		public CheckMoveAICautionNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAISettings.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(user.Object.MoveAI != null &&
				user.Object.MoveAI.settings.caution.enabled)
			{
				// check for status conditions
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(user.Object.MoveAI.settings.caution.IsCautious(user, list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}

	[EditorHelp("Check Move AI Target", "Checks if the targets are the current target of the combatant's move AI.\n" +
		"If the check is valid, 'Success' will be executed next, otherwise 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[NodeInfo("Move AI", "Check")]
	public class CheckMoveAITargetNode : BaseAICheckNode
	{
		[EditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this node's settings, removing those that don't match the requirement.\n" +
			"- Clear: The targets will be removed from the list.\n" +
			"- Check Keep: The targets will be checked, but kept even if they don't match the requirement.", "")]
		public FoundTargets foundType = FoundTargets.Keep;

		[EditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[EditorHelp("Don't Add Targets", "Don't add 'Target' combatants to the found targets.", "")]
		public bool dontAddTargets = false;

		[EditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeSelf = false;

		[EditorHelp("Exclude Found Targets", "Exclude the already found targets from the targets.", "")]
		[EditorCondition("targetType", BattleAITargetType.Ally)]
		[EditorCondition("targetType", BattleAITargetType.Enemy)]
		[EditorCondition("targetType", BattleAITargetType.All)]
		[EditorEndCondition]
		[EditorDefaultValue(false)]
		public bool targetExcludeFoundTargets = false;

		public CheckMoveAITargetNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				call.foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				call.foundTargets.Clear();
				this.Check(ref any, call.user, tmp, call.foundTargets);
			}
			else if(FoundTargets.CheckKeep == this.foundType)
			{
				this.Check(ref any, call.user, call.foundTargets, call.foundTargets);
			}

			// check all possible targets
			this.Check(ref any, call.user,
				BattleAISettings.GetTargetList(this.targetType,
					this.targetExcludeSelf, this.targetExcludeFoundTargets,
					call),
				call.foundTargets);

			// any target found?
			if(any)
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			if(user.Object.MoveAI != null)
			{
				// check for status conditions
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(user.Object.MoveAI.IsTarget(list[i]))
						{
							any = true;
							if(!this.dontAddTargets &&
								!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.movementNodeColor; }
		}
	}
}
