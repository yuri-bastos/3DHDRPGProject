﻿
using GamingIsLove.ORKFramework;
using GamingIsLove.ORKFramework.AI;
using GamingIsLove.ORKFramework.Components;
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Queued Action Count", "Checks how many actions are already queued in the user's AI action queue.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Action Queue")]
	public class QueuedActionCountNode : BaseAICheckNode
	{
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public QueuedActionCountNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.check.Check(call.user.AI.ActionQueue.Count, call))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}

			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.machineNodeColor; }
		}
	}

	[EditorHelp("Queued Action", "Performs the combatant's next queued AI action.\n" +
		"If the action can't be performed, 'Next' is executed.", "")]
	[NodeInfo("Action", "Action Queue")]
	public class QueuedActionNode : BaseAINode
	{
		public QueuedActionNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			BaseAction action = call.user.AI.GetNextQueuedAction();

			// check AI blocks
			if(!call.user.AI.CanUseAction(action))
			{
				action = null;
			}

			return action;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.machineNodeColor; }
		}
	}

	[EditorHelp("Clear Queued Actions", "Remove all currently queued AI actions of the combatant.", "")]
	[NodeInfo("Action Queue")]
	public class ClearQueuedActionsNode : BaseAINode
	{
		public ClearQueuedActionsNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			call.user.AI.ActionQueue.Clear();
			return null;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.machineNodeColor; }
		}
	}
}
