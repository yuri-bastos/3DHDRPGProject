﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.AI.Nodes
{
	[EditorHelp("Clear Found Targets", "All found targets will be removed.", "")]
	[NodeInfo("Target")]
	public class ClearFoundTargetsNode : BaseAINode
	{
		public ClearFoundTargetsNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			call.foundTargets.Clear();
			currentNode = this.next;
			return null;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameNodeColor; }
		}
	}

	[EditorHelp("Check Target Count", "Checks the number of found targets.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.\n" +
		"Doesn't influence the target list.", "")]
	[NodeInfo("Target", "Check")]
	public class CheckTargetCountNode : BaseAICheckNode
	{
		public ValueCheck<BattleAIObjectSelection> check = new ValueCheck<BattleAIObjectSelection>();

		public CheckTargetCountNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.check.Check(call.foundTargets.Count, call))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameNodeColor; }
		}
	}

	[EditorHelp("Use Last Targets", "Adds the last targets of the user (or other combatants) to the found targets list.", "")]
	[NodeInfo("Target")]
	public class UseLastTargetsNode : BaseAINode
	{
		[EditorHelp("Target Origin", "Select which combatant's last targets will be used:\n" +
			"- User: The user of this battle AI.\n" +
			"- Leader: The leader of the user's group.\n" +
			"- Group: Members of the user's battle group.\n" +
			"- Allies: The allies of the user.\n" +
			"- Enemies: The enemies of the user.\n" +
			"- Found Targets: The already found targets.\n" +
			"- Selected Data: Combatants stored in selected data.", "")]
		public BattleAITargetOrigin targetOrigin = BattleAITargetOrigin.User;


		// selected data
		[EditorCondition("targetOrigin", BattleAITargetOrigin.SelectedData)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SelectedData<BattleAIObjectSelection> selectedData;

		public UseLastTargetsNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(BattleAITargetOrigin.User == this.targetOrigin)
			{
				this.Add(call.user.Battle.LastTargets, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Leader == this.targetOrigin)
			{
				this.Add(call.user.Group.Leader.Battle.LastTargets, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Group == this.targetOrigin)
			{
				List<Combatant> group = call.user.Group.GetBattle();
				for(int i = 0; i < group.Count; i++)
				{
					this.Add(group[i].Battle.LastTargets, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Allies == this.targetOrigin)
			{
				for(int i = 0; i < call.allies.Count; i++)
				{
					this.Add(call.allies[i].Battle.LastTargets, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Enemies == this.targetOrigin)
			{
				for(int i = 0; i < call.enemies.Count; i++)
				{
					this.Add(call.enemies[i].Battle.LastTargets, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.FoundTargets == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				for(int i = 0; i < tmp.Count; i++)
				{
					this.Add(tmp[i].Battle.LastTargets, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.SelectedData == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>();
				List<SelectedDataHandler> dataList = this.selectedData.GetHandlers(call);
				for(int i = 0; i < dataList.Count; i++)
				{
					if(dataList[i] != null)
					{
						ORKSelectedDataHelper.GetCombatants(
							dataList[i].Get(this.selectedData.key.GetValue(call)),
							ref tmp);
					}
				}
				Maki.Pooling.SelectedDataHandlerLists.Add(dataList);
				for(int i = 0; i < tmp.Count; i++)
				{
					this.Add(tmp[i].Battle.LastTargets, call.foundTargets);
				}
			}

			currentNode = this.next;
			return null;
		}

		private void Add(List<Combatant> targets, List<Combatant> foundTargets)
		{
			if(targets != null)
			{
				for(int i = 0; i < targets.Count; i++)
				{
					if(targets[i] != null &&
						!foundTargets.Contains(targets[i]))
					{
						foundTargets.Add(targets[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetOrigin.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameNodeColor; }
		}
	}

	[EditorHelp("Use Attacked By", "Adds the combatants that attacked the user (or other combatants) to the found targets list.", "")]
	[NodeInfo("Target")]
	public class UseAttackedByNode : BaseAINode
	{
		[EditorHelp("Target Origin", "Select which combatant's attacked by list will be used:\n" +
			"- User: The user of this battle AI.\n" +
			"- Leader: The leader of the user's group.\n" +
			"- Group: Members of the user's battle group.\n" +
			"- Allies: The allies of the user.\n" +
			"- Enemies: The enemies of the user.\n" +
			"- Found Targets: The already found targets.\n" +
			"- Selected Data: Combatants stored in selected data.", "")]
		public BattleAITargetOrigin targetOrigin = BattleAITargetOrigin.User;


		// selected data
		[EditorCondition("targetOrigin", BattleAITargetOrigin.SelectedData)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SelectedData<BattleAIObjectSelection> selectedData;

		public UseAttackedByNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(BattleAITargetOrigin.User == this.targetOrigin)
			{
				this.Add(call.user.Battle.AttackedBy, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Leader == this.targetOrigin)
			{
				this.Add(call.user.Group.Leader.Battle.AttackedBy, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Group == this.targetOrigin)
			{
				List<Combatant> group = call.user.Group.GetBattle();
				for(int i = 0; i < group.Count; i++)
				{
					this.Add(group[i].Battle.AttackedBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Allies == this.targetOrigin)
			{
				for(int i = 0; i < call.allies.Count; i++)
				{
					this.Add(call.allies[i].Battle.AttackedBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Enemies == this.targetOrigin)
			{
				for(int i = 0; i < call.enemies.Count; i++)
				{
					this.Add(call.enemies[i].Battle.AttackedBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.FoundTargets == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				for(int i = 0; i < tmp.Count; i++)
				{
					this.Add(tmp[i].Battle.AttackedBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.SelectedData == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>();
				List<SelectedDataHandler> dataList = this.selectedData.GetHandlers(call);
				for(int i = 0; i < dataList.Count; i++)
				{
					if(dataList[i] != null)
					{
						ORKSelectedDataHelper.GetCombatants(
							dataList[i].Get(this.selectedData.key.GetValue(call)),
							ref tmp);
					}
				}
				Maki.Pooling.SelectedDataHandlerLists.Add(dataList);
				for(int i = 0; i < tmp.Count; i++)
				{
					this.Add(tmp[i].Battle.AttackedBy, call.foundTargets);
				}
			}

			currentNode = this.next;
			return null;
		}

		private void Add(List<Combatant> targets, List<Combatant> foundTargets)
		{
			if(targets != null)
			{
				for(int i = 0; i < targets.Count; i++)
				{
					if(targets[i] != null &&
						!foundTargets.Contains(targets[i]))
					{
						foundTargets.Add(targets[i]);
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetOrigin.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameNodeColor; }
		}
	}

	[EditorHelp("Use Killed By", "Adds the combatant that killed the user to the found targets list.\n" +
		"This is only available if the combatant was previously killed by someone in battle.", "")]
	[NodeInfo("Target")]
	public class UseKilledByNode : BaseAINode
	{
		[EditorHelp("Target Origin", "Select which combatant's attacked by list will be used:\n" +
			"- User: The user of this battle AI.\n" +
			"- Leader: The leader of the user's group.\n" +
			"- Group: Members of the user's battle group.\n" +
			"- Allies: The allies of the user.\n" +
			"- Enemies: The enemies of the user.\n" +
			"- Found Targets: The already found targets.\n" +
			"- Selected Data: Combatants stored in selected data.", "")]
		public BattleAITargetOrigin targetOrigin = BattleAITargetOrigin.User;


		// selected data
		[EditorCondition("targetOrigin", BattleAITargetOrigin.SelectedData)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SelectedData<BattleAIObjectSelection> selectedData;

		public UseKilledByNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(BattleAITargetOrigin.User == this.targetOrigin)
			{
				this.Add(call.user.Battle.KilledBy, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Leader == this.targetOrigin)
			{
				this.Add(call.user.Group.Leader.Battle.KilledBy, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Group == this.targetOrigin)
			{
				List<Combatant> group = call.user.Group.GetBattle();
				for(int i = 0; i < group.Count; i++)
				{
					this.Add(group[i].Battle.KilledBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Allies == this.targetOrigin)
			{
				for(int i = 0; i < call.allies.Count; i++)
				{
					this.Add(call.allies[i].Battle.KilledBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Enemies == this.targetOrigin)
			{
				for(int i = 0; i < call.enemies.Count; i++)
				{
					this.Add(call.enemies[i].Battle.KilledBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.FoundTargets == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				for(int i = 0; i < tmp.Count; i++)
				{
					this.Add(tmp[i].Battle.KilledBy, call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.SelectedData == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>();
				List<SelectedDataHandler> dataList = this.selectedData.GetHandlers(call);
				for(int i = 0; i < dataList.Count; i++)
				{
					if(dataList[i] != null)
					{
						ORKSelectedDataHelper.GetCombatants(
							dataList[i].Get(this.selectedData.key.GetValue(call)),
							ref tmp);
					}
				}
				Maki.Pooling.SelectedDataHandlerLists.Add(dataList);
				for(int i = 0; i < tmp.Count; i++)
				{
					this.Add(tmp[i].Battle.KilledBy, call.foundTargets);
				}
			}

			currentNode = this.next;
			return null;
		}

		private void Add(Combatant target, List<Combatant> foundTargets)
		{
			if(target != null &&
				!foundTargets.Contains(target))
			{
				foundTargets.Add(target);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetOrigin.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameNodeColor; }
		}
	}

	[EditorHelp("Use Combatant", "Adds the combatant's group/individual target, last target, " +
		"attacked by target, killed by target or linked combatant to the found targets list.", "")]
	[NodeInfo("Target")]
	public class UseCombatantNode : BaseAINode
	{
		[EditorHelp("Target Origin", "Select which combatant's attacked by list will be used:\n" +
			"- User: The user of this battle AI.\n" +
			"- Leader: The leader of the user's group.\n" +
			"- Group: Members of the user's battle group.\n" +
			"- Allies: The allies of the user.\n" +
			"- Enemies: The enemies of the user.\n" +
			"- Found Targets: The already found targets.\n" +
			"- Selected Data: Combatants stored in selected data.", "")]
		public BattleAITargetOrigin targetOrigin = BattleAITargetOrigin.User;


		// selected data
		[EditorCondition("targetOrigin", BattleAITargetOrigin.SelectedData)]
		[EditorEndCondition]
		[EditorAutoInit]
		public SelectedData<BattleAIObjectSelection> selectedData;


		// combatant
		[EditorSeparator]
		public SelectCombatantSettings<BattleAIObjectSelection> selectCombatant = new SelectCombatantSettings<BattleAIObjectSelection>();

		public UseCombatantNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(BattleAITargetOrigin.User == this.targetOrigin)
			{
				call.checkTarget = call.user;
				this.selectCombatant.Get(call, call.user, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Leader == this.targetOrigin)
			{
				call.checkTarget = call.user.Group.Leader;
				this.selectCombatant.Get(call, call.user.Group.Leader, call.foundTargets);
			}
			else if(BattleAITargetOrigin.Group == this.targetOrigin)
			{
				List<Combatant> group = call.user.Group.GetBattle();
				for(int i = 0; i < group.Count; i++)
				{
					call.checkTarget = group[i];
					this.selectCombatant.Get(call, group[i], call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Allies == this.targetOrigin)
			{
				for(int i = 0; i < call.allies.Count; i++)
				{
					call.checkTarget = call.allies[i];
					this.selectCombatant.Get(call, call.allies[i], call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.Enemies == this.targetOrigin)
			{
				for(int i = 0; i < call.enemies.Count; i++)
				{
					call.checkTarget = call.enemies[i];
					this.selectCombatant.Get(call, call.enemies[i], call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.FoundTargets == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>(call.foundTargets);
				for(int i = 0; i < tmp.Count; i++)
				{
					call.checkTarget = tmp[i];
					this.selectCombatant.Get(call, tmp[i], call.foundTargets);
				}
			}
			else if(BattleAITargetOrigin.SelectedData == this.targetOrigin)
			{
				List<Combatant> tmp = new List<Combatant>();
				List<SelectedDataHandler> dataList = this.selectedData.GetHandlers(call);
				for(int i = 0; i < dataList.Count; i++)
				{
					if(dataList[i] != null)
					{
						ORKSelectedDataHelper.GetCombatants(
							dataList[i].Get(this.selectedData.key.GetValue(call)),
							ref tmp);
					}
				}
				Maki.Pooling.SelectedDataHandlerLists.Add(dataList);
				for(int i = 0; i < tmp.Count; i++)
				{
					call.checkTarget = tmp[i];
					this.selectCombatant.Get(call, tmp[i], call.foundTargets);
				}
			}

			currentNode = this.next;
			call.checkTarget = null;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.targetOrigin.ToString() + ": " + this.selectCombatant.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameNodeColor; }
		}
	}

	[EditorHelp("Store Targets", "Store the currently found targets list.\n" +
		"Targets are stored using a 'target key' to allow storing different target lists.\n" +
		"You can store targets for the group or the user (individual combatant), " +
		"storing targets for the group allow all group members to access the targets.", "")]
	[NodeInfo("Target")]
	public class StoreTargetsNode : BaseAINode
	{
		[EditorHelp("Group Target", "Store the targets as group targets.\n" +
			"All members of the group have access to the group targets.\n" +
			"If disabled, the targets are stored for the user.", "")]
		public bool useGroup = false;

		[EditorHelp("Change Type", "Select how the found targets will change the stored targets:\n" +
			"- Add: Adds them to the stored targets.\n" +
			"- Remove: Removes them from the stored targets.\n" +
			"- Clear: Removes all stored targets of the defined key.\n" +
			"- Set: Sets them as the stored targets, overriding previously stored targets.", "")]
		public ListChangeType changeType = ListChangeType.Set;


		// key
		[EditorSeparator]
		[EditorHelp("Target Key", "The target key that will be used.")]
		public StringValue<BattleAIObjectSelection> targetKey = new StringValue<BattleAIObjectSelection>();

		public StoreTargetsNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.useGroup)
			{
				call.user.Group.SelectedTargets.ChangeStoredTargets(
					this.targetKey.GetValue(call), call.foundTargets, this.changeType);
			}
			else
			{
				call.user.SelectedTargets.ChangeStoredTargets(
					this.targetKey.GetValue(call), call.foundTargets, this.changeType);
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useGroup ? "Group: " : "User: ") + this.changeType +
				" " + this.targetKey.ToString();
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameNodeColor; }
		}
	}

	[EditorHelp("Load Targets", "Loads previously stored targets into the found targets list.", "")]
	[NodeInfo("Target")]
	public class LoadTargetsNode : BaseAINode
	{
		[EditorHelp("Group Target", "Load the targets from group targets.\n" +
			"All members of the group have access to the group targets.\n" +
			"If disabled, the targets are loaded from the user.", "")]
		public bool useGroup = false;

		[EditorHelp("Change Type", "Select how the loaded targets will change the found targets:\n" +
			"- Add: Adds them to the found targets.\n" +
			"- Remove: Removes them from the found targets.\n" +
			"- Clear: Removes all found targets.\n" +
			"- Set: Sets them as the found targets, overriding previously found targets.", "")]
		public ListChangeType changeType = ListChangeType.Set;


		// key
		[EditorSeparator]
		[EditorHelp("Target Key", "The target key that will be used.")]
		[EditorCondition("changeType", ListChangeType.Clear)]
		[EditorElseCondition]
		[EditorEndCondition]
		public StringValue<BattleAIObjectSelection> targetKey = new StringValue<BattleAIObjectSelection>();

		public LoadTargetsNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(ListChangeType.Clear == this.changeType)
			{
				call.foundTargets.Clear();
			}
			else
			{
				if(ListChangeType.Set == this.changeType)
				{
					call.foundTargets.Clear();
				}

				List<Combatant> targets = this.useGroup ?
					call.user.Group.SelectedTargets.GetStoredTargets(this.targetKey.GetValue(call)) :
					call.user.SelectedTargets.GetStoredTargets(this.targetKey.GetValue(call));

				if(targets != null)
				{
					if(ListChangeType.Set == this.changeType)
					{
						call.foundTargets.AddRange(targets);
					}
					else
					{
						if(ListChangeType.Add == this.changeType)
						{
							for(int i = 0; i < targets.Count; i++)
							{
								if(targets[i] != null &&
									!call.foundTargets.Contains(targets[i]))
								{
									call.foundTargets.Add(targets[i]);
								}
							}
						}
						else if(ListChangeType.Remove == this.changeType)
						{
							for(int i = 0; i < targets.Count; i++)
							{
								if(targets[i] != null &&
									call.foundTargets.Contains(targets[i]))
								{
									call.foundTargets.Remove(targets[i]);
								}
							}
						}
					}
				}
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useGroup ? "Group: " : "User: ") + this.changeType +
				(ListChangeType.Clear == this.changeType ? "" : " " + this.targetKey.ToString());
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameNodeColor; }
		}
	}

	[EditorHelp("Has Stored Targets", "Checks if stored targets of a defined key exist, " +
		"optionally also checking for status conditions (e.g. not being dead).\n" +
		"Can also remove combatants from the stored targets that don't match the status conditions.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[NodeInfo("Target", "Check")]
	public class HasStoredTargetsNode : BaseAICheckNode
	{
		[EditorHelp("Group Target", "Load the targets from group targets.\n" +
			"All members of the group have access to the group targets.\n" +
			"If disabled, the targets are loaded from the user.", "")]
		public bool useGroup = false;


		// key
		[EditorSeparator]
		[EditorHelp("Target Key", "The target key that will be used.")]
		public StringValue<BattleAIObjectSelection> targetKey = new StringValue<BattleAIObjectSelection>();


		// status
		[EditorHelp("Remove Not Matching", "Remove combatants from the stored targets that don't match the status conditions.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Status Conditions")]
		public bool removeNotMatching = false;

		public StatusConditionSettings conditions = new StatusConditionSettings();

		public HasStoredTargetsNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			if(this.useGroup ?
				call.user.Group.SelectedTargets.HasStoredTargets(
					this.targetKey.GetValue(call), this.conditions, this.removeNotMatching) :
				call.user.SelectedTargets.HasStoredTargets(
					this.targetKey.GetValue(call), this.conditions, this.removeNotMatching))
			{
				currentNode = this.next;
			}
			else
			{
				currentNode = this.nextFail;
			}
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.useGroup ? "Group: " : "User: ") + this.targetKey.ToString() +
				(this.removeNotMatching ? ", remove not matching" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameNodeColor; }
		}
	}

	[EditorHelp("Change Selected Target", "Changes the group/individual target of the user using the currently found targets.", "")]
	[NodeInfo("Target")]
	public class ChangeSelectedTargetNode : BaseAINode
	{
		[EditorHelp("Index",
			"The index of the group/individual target that will be changed.",
			"No target will be changed if this exceeds the defined group/individual target settings.")]
		public FloatValue<BattleAIObjectSelection> index = new FloatValue<BattleAIObjectSelection>();

		[EditorHelp("Group/Individual Target", "If enabled, the combatant's group target will be changed.\n" +
			"If disabled, the combatant's individual target will be changed.", "")]
		[EditorSeparator]
		public bool changeGroupTarget = true;

		[EditorHelp("Use Conditions", "Use the target conditions of the group/individual target settings.", "")]
		public bool useConditions = true;

		[EditorHelp("Remove Target", "Removes the currently set target combatant.\n" +
			"There'll be no target currently set on this target index.", "")]
		public bool remove = false;

		public ChangeSelectedTargetNode()
		{

		}

		public override BaseAction Execute(ref int currentNode, BattleAICall call)
		{
			int targetIndex = (int)this.index.GetValue(call);
			TargetSelection[] settings = this.changeGroupTarget ?
				ORK.TargetSettings.groupTargetSelection :
				ORK.TargetSettings.individualTargetSelection;

			if(targetIndex >= 0 &&
				targetIndex < settings.Length)
			{
				for(int i = 0; i < call.foundTargets.Count; i++)
				{
					if(call.foundTargets[i] != null &&
						(!this.useConditions ||
							settings[targetIndex].CheckTargetConditions(call.foundTargets[i])))
					{
						if(this.changeGroupTarget)
						{
							call.user.Group.SelectedTargets[targetIndex] = call.foundTargets[i];
						}
						else
						{
							call.user.SelectedTargets[targetIndex] = call.foundTargets[i];
						}
						break;
					}
				}
			}

			currentNode = this.next;
			return null;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.changeGroupTarget ? "Group " : "Individual ") +
				this.index.ToString() + (this.remove ? ": Remove" : "");
		}

		public override Color EditorColor
		{
			get { return Maki.EditorSettings.gameNodeColor; }
		}
	}
}
