﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Status Value", "The selected status value will be compared to a defined value.")]
	public class StatusValueStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Status Value", "Select the status value that will be used.", "")]
		public AssetSelection<StatusValueAsset> statusValue = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.", "")]
		public StatusValueGetValue getValue = StatusValueGetValue.CurrentValue;


		// compare with other
		[EditorHelp("Compare With Other", "Compares the selected status value with the current value of another status value.\n" +
			"If disabled, the status value is compared with a defined value.", "")]
		[EditorSeparator]
		public bool compareWithOther = false;

		[EditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than the defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[EditorCondition("compareWithOther", true)]
		public ValueCheckType otherCheckType = ValueCheckType.IsEqual;

		// other status
		[EditorHelp("Other Status Value", "Select the status value that will be used for the comparison.", "")]
		[EditorSeparator]
		public AssetSelection<StatusValueAsset> otherStatusValue = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Other Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Min Value: The preview minimum value, displaying changes when an equipment would be equipped.", "")]
		public StatusValueGetValue otherGetValue = StatusValueGetValue.CurrentValue;

		// other status 2
		[EditorHelp("Other Status Value 2", "Select the status value that will be used for the comparison (upper limit).", "")]
		[EditorSeparator]
		[EditorCondition("otherCheckType", ValueCheckType.RangeInclusive)]
		[EditorCondition("otherCheckType", ValueCheckType.RangeExclusive)]
		public AssetSelection<StatusValueAsset> otherStatusValue2 = new AssetSelection<StatusValueAsset>();

		[EditorHelp("Other Used Value 2", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Min Value: The preview minimum value, displaying changes when an equipment would be equipped.", "")]
		[EditorEndCondition]
		public StatusValueGetValue otherGetValue2 = StatusValueGetValue.CurrentValue;


		// check value
		[EditorHelp("Check In", "The value is either in percent of the maximum status value or an absolute value.", "")]
		[EditorElseCondition]
		public ValueSetter setter = ValueSetter.Value;

		[EditorEndCondition]
		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		public StatusValueStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.statusValue.ToString() + " " + this.getValue + " " +
				(this.compareWithOther ?
					this.otherCheckType + " " + this.otherStatusValue.ToString() :
					this.check.ToString() + (ValueSetter.Percent == this.setter ? " %" : ""));
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.statusValue.StoredAsset != null)
			{
				float value = combatant.Status.Get(this.statusValue.StoredAsset.Settings).GetCompareValue(this.getValue, this.setter);
				if(this.compareWithOther &&
					this.otherStatusValue.StoredAsset != null)
				{
					return ValueHelper.CheckValue(value,
						combatant.Status.Get(this.otherStatusValue.StoredAsset.Settings).GetTypeValue(this.otherGetValue),
						this.otherStatusValue2.StoredAsset != null &&
							(ValueCheckType.RangeInclusive == this.otherCheckType ||
								ValueCheckType.RangeExclusive == this.otherCheckType) ?
							combatant.Status.Get(this.otherStatusValue2.StoredAsset.Settings).GetTypeValue(this.otherGetValue2) : 0,
						this.otherCheckType);
				}
				else
				{
					return this.check.Check(value, combatant.Call);
				}
			}
			return false;
		}

		public override bool CheckPreview(Combatant combatant)
		{
			if(this.statusValue.StoredAsset != null)
			{
				float value = combatant.Status.Get(this.statusValue.StoredAsset.Settings).GetCompareValuePreview(this.setter);
				if(this.compareWithOther)
				{
					return ValueHelper.CheckValue(value,
						combatant.Status.Get(this.otherStatusValue.StoredAsset.Settings).GetPreviewValue(false),
						this.otherStatusValue2.StoredAsset != null &&
							(ValueCheckType.RangeInclusive == this.otherCheckType ||
								ValueCheckType.RangeExclusive == this.otherCheckType) ?
							combatant.Status.Get(this.otherStatusValue2.StoredAsset.Settings).GetPreviewValue(false) : 0,
						this.otherCheckType);
				}
				else
				{
					return this.check.Check(value, combatant.Call);
				}
			}
			return false;
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete || combatant.Bestiary.status.statusValues))
			{
				return this.Check(combatant);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			if(this.statusValue.StoredAsset != null)
			{
				StatusValue sv = combatant.Status.Get(this.statusValue.StoredAsset.Settings);
				sv.ValueChanged += notify.NotifyStatusChanged;
				if(sv.IsConsumable() &&
					sv.Setting.maxStatus.StoredAsset != null)
				{
					combatant.Status.Get(sv.Setting.maxStatus.StoredAsset.Settings).ValueChanged += notify.NotifyStatusChanged;
				}
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			if(this.statusValue.StoredAsset != null)
			{
				StatusValue sv = combatant.Status.Get(this.statusValue.StoredAsset.Settings);
				sv.ValueChanged -= notify.NotifyStatusChanged;
				if(sv.IsConsumable() &&
					sv.Setting.maxStatus.StoredAsset != null)
				{
					combatant.Status.Get(sv.Setting.maxStatus.StoredAsset.Settings).ValueChanged -= notify.NotifyStatusChanged;
				}
			}
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			if(this.statusValue.StoredAsset != null)
			{
				StatusValue sv = combatant.Status.Get(this.statusValue.StoredAsset.Settings);
				sv.SimpleChanged += notify;
				if(sv.IsConsumable() &&
					sv.Setting.maxStatus.StoredAsset != null)
				{
					combatant.Status.Get(sv.Setting.maxStatus.StoredAsset.Settings).SimpleChanged += notify;
				}
			}
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			if(this.statusValue.StoredAsset != null)
			{
				StatusValue sv = combatant.Status.Get(this.statusValue.StoredAsset.Settings);
				sv.SimpleChanged -= notify;
				if(sv.IsConsumable() &&
					sv.Setting.maxStatus.StoredAsset != null)
				{
					combatant.Status.Get(sv.Setting.maxStatus.StoredAsset.Settings).SimpleChanged -= notify;
				}
			}
		}
	}
}
