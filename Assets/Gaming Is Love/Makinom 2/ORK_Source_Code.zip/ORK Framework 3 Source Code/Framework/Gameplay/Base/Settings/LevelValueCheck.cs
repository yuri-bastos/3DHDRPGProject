﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class LevelValueCheck : BaseValueCheck
	{
		[EditorHelp("Check Type", "Select the used level check:\n" +
			"- Is Equal: The level is equal to the defined check value (==).\n" +
			"- Not Equal: The level is not equal to the defined check value (!=).\n" +
			"- Is Less: The level is less (smaller) than the defined check value (<).\n" +
			"- Is Less Equal: The level is equal or less (smaller) than the defined check value (<=).\n" +
			"- Is Greater: The level is greater (bigger) than the defined check value (>).\n" +
			"- Is Greater Equal: The level is equal or greater (bigger) than the defined check value (>=).\n" +
			"- Range Inclusive: The level is between the two defined check values, including the values (>= v1, <= v2).\n" +
			"- Range Exclusive: The level is between the two defined check values, excluding the values (> v1, < v2).\n" +
			"- Range Inclusive Lower: The level is between the two defined check values, including value 1, excluding value 2 (>= v1, < v2).\n" +
			"- Range Inclusive Upper: The level is between the two defined check values, excluding value 1, including value 2 (> v1, <= v2).\n" +
			"- Approximately: The level is approximately equal to the defined check value, best used for float value equality checks (==).\n" +
			"- Not Approximately: The level is not approximately equal to the defined check value, best used for float value inequality checks (!=).", "")]
		[EditorHide]
		public ValueCheckType type = ValueCheckType.IsEqual;

		[EditorHelp("Check Value", "The value used for the check.\n" +
			"In range inclusive/exclusive checks, this is the lower limit.", "")]
		[EditorLimit(1, false)]
		public int value = 0;

		[EditorHelp("Check Value 2", "The value used for the check (upper limit).", "")]
		[EditorLimit("value", false)]
		[EditorCondition("type", ValueCheckType.RangeInclusive)]
		[EditorCondition("type", ValueCheckType.RangeExclusive)]
		[EditorCondition("type", ValueCheckType.RangeInclusiveLower)]
		[EditorCondition("type", ValueCheckType.RangeInclusiveUpper)]
		[EditorEndCondition]
		[EditorAutoInit]
		public int value2 = 1;

		public LevelValueCheck()
		{

		}

		public LevelValueCheck(int value)
		{
			this.value = value;
		}

		public LevelValueCheck(ValueCheckType type, int value, int value2)
		{
			this.type = type;
			this.value = value;
			this.value2 = value2;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public override ValueCheckType CheckType
		{
			get { return this.type; }
			set { this.type = value; }
		}

		public virtual int GetLevel(int max)
		{
			int level = 1;
			if(ValueCheckType.IsEqual == this.type ||
				ValueCheckType.Approximately == this.type)
			{
				level = this.value;
			}
			else if(ValueCheckType.IsLess == this.type)
			{
				level = Random.Range(1, this.value);
			}
			else if(ValueCheckType.IsLessEqual == this.type)
			{
				level = Random.Range(1, this.value + 1);
			}
			else if(ValueCheckType.IsGreater == this.type)
			{
				level = Random.Range(this.value + 1, max + 1);
			}
			else if(ValueCheckType.IsGreaterEqual == this.type)
			{
				level = Random.Range(this.value, max + 1);
			}
			else if(ValueCheckType.NotEqual == this.type ||
				ValueCheckType.NotApproximately == this.type)
			{
				level = Random.Range(1, max + 1);
				if(level == this.value)
				{
					if(level <= 1 &&
						max > 1)
					{
						return level + 1;
					}
					else if(level > max &&
						level > 1)
					{
						return level - 1;
					}
				}
			}
			else if(ValueCheckType.RangeInclusive == this.type)
			{
				level = Random.Range(this.value, this.value2 + 1);
			}
			else if(ValueCheckType.RangeExclusive == this.type)
			{
				level = Random.Range(this.value + 1, this.value2);
			}
			else if(ValueCheckType.RangeInclusiveLower == this.type)
			{
				level = Random.Range(this.value, this.value2);
			}
			else if(ValueCheckType.RangeInclusiveUpper == this.type)
			{
				level = Random.Range(this.value + 1, this.value2 + 1);
			}
			return Mathf.Min(level, max);
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public virtual bool Check(int checkValue)
		{
			return ValueHelper.CheckValue(checkValue, this.value, this.value2, this.type);
		}

		public virtual bool Check(int checkValue, int offset, IDataCall call)
		{
			return ValueHelper.CheckValue(checkValue, this.value + offset, this.value2 + offset, this.type);
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override string ToString()
		{
			return this.type.ToString() + " " + this.value.ToString() +
				(ValueCheckType.RangeInclusive == this.type || ValueCheckType.RangeExclusive == this.type ?
					" ~ " + this.value2.ToString() : "");
		}
	}
}
