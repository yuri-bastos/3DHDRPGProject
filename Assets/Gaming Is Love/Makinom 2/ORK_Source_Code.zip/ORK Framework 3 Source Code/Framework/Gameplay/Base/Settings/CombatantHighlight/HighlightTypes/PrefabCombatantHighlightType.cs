﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Prefab", "Use a prefab to highlight the combatant.")]
	public class PrefabCombatantHighlightType : BaseCombatantHighlightType
	{
		[EditorHelp("Prefab", "Select the prefab that will be used.\n" +
			"Components implementing the 'ICombatantHighlightCursorPrefab' interface attached to the prefab (and it's child objects) " +
			"will get notified about the selected combatant. " +
			"Can be used to adjust the cursor prefab based on the combatant, e.g. scaling based on the combatant's radius.\n" +
			"Additinally, when used for target selections, components implementing the 'ITargetSelectionCursorPrefab' interface attached to the prefab (and it's child objects) " +
			"will get notified about the target selection's user, the targeted combatant and the used action. " +
			"Can be used to adjust the cursor prefab based on the action, e.g. scaling based on the affect range.", "")]
		public AssetSource<GameObject> cursorPrefab = new AssetSource<GameObject>();

		public MountSettings cursorMount = new MountSettings();

		public PrefabCombatantHighlightType()
		{

		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public override void Highlight(Combatant combatant)
		{
			if(this.cursorPrefab.StoredAsset != null)
			{
				GameObject instance = combatant.Object.GetHighlightInstance(this);
				if(instance == null)
				{
					instance = UnityWrapper.Instantiate(this.cursorPrefab.StoredAsset);
				}
				if(instance != null)
				{
					instance.SetActive(true);
					this.cursorMount.MountTo(combatant.GameObject.transform, instance.transform);
					combatant.Object.SetHighlightInstance(this, instance);

					ICombatantHighlightCursorPrefab[] component = instance.GetComponentsInChildren<ICombatantHighlightCursorPrefab>();
					if(component != null)
					{
						for(int i = 0; i < component.Length; i++)
						{
							component[i].StartSelection(combatant);
						}
					}
				}
			}
		}

		public override void Highlight(Combatant user, Combatant target, IShortcut shortcut)
		{
			if(this.cursorPrefab.StoredAsset != null)
			{
				GameObject instance = target.Object.GetHighlightInstance(this);
				if(instance == null)
				{
					instance = UnityWrapper.Instantiate(this.cursorPrefab.StoredAsset);
				}
				if(instance != null)
				{
					instance.SetActive(true);
					this.cursorMount.MountTo(target.GameObject.transform, instance.transform);
					target.Object.SetHighlightInstance(this, instance);

					ICombatantHighlightCursorPrefab[] component = instance.GetComponentsInChildren<ICombatantHighlightCursorPrefab>();
					if(component != null)
					{
						for(int i = 0; i < component.Length; i++)
						{
							component[i].StartSelection(target);
						}
					}

					ITargetSelectionCursorPrefab[] targetComp = instance.GetComponentsInChildren<ITargetSelectionCursorPrefab>();
					if(targetComp != null)
					{
						for(int i = 0; i < targetComp.Length; i++)
						{
							targetComp[i].StartSelection(user, target, shortcut);
						}
					}
				}
			}
		}

		public override void StopHighlight(Combatant combatant)
		{
			if(this.cursorPrefab.StoredAsset != null)
			{
				GameObject instance = combatant.Object.GetHighlightInstance(this);
				if(instance != null)
				{
					ICombatantHighlightCursorPrefab[] component = instance.GetComponentsInChildren<ICombatantHighlightCursorPrefab>();
					if(component != null)
					{
						for(int i = 0; i < component.Length; i++)
						{
							component[i].StopSelection();
						}
					}

					ITargetSelectionCursorPrefab[] targetComp = instance.GetComponentsInChildren<ITargetSelectionCursorPrefab>();
					if(targetComp != null)
					{
						for(int i = 0; i < targetComp.Length; i++)
						{
							targetComp[i].StopSelection();
						}
					}

					instance.SetActive(false);
				}
			}
		}
	}
}
