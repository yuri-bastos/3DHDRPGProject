﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Reflection;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Animations
{
	public class CustomAnimationBase : BaseData
	{
		// play
		[EditorFoldout("Play Function", "Define the function that will be called when the animation is played.", "")]
		[EditorEndFoldout]
		public CallFunction<GameObjectSelection> playMethod = new CallFunction<GameObjectSelection>();


		// stop
		[EditorFoldout("Stop Function", "Define the function that will be called when the animation is stopped.", "")]
		[EditorEndFoldout]
		public CallFunction<GameObjectSelection> stopMethod = new CallFunction<GameObjectSelection>();

		public CustomAnimationBase()
		{

		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public virtual void Play(Combatant combatant, Component behaviour)
		{
			this.playMethod.Call(behaviour, combatant.Call, false);
		}

		public virtual void Stop(Combatant combatant, Component behaviour)
		{
			this.stopMethod.Call(behaviour, combatant.Call, false);
		}
	}
}
