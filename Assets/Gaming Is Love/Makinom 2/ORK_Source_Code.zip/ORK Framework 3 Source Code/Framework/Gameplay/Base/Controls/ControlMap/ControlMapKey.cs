
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Schematics;

namespace GamingIsLove.ORKFramework
{
	public enum ControlMapKeyType { Action, AutoAttack, GlobalMachine, Schematic };

	public class ControlMapKey : BaseData
	{
		// input settings
		// key
		[EditorHelp("Input Key", "Select the input key used for this control map key.", "")]
		[EditorFoldout("Input Settings", "Define the input key and use conditions.", "")]
		public AssetSelection<InputKeyAsset> key = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Is Axis", "The key name will be used as an axis instead of a button.\n" +
			"Use this setting e.g. for analog sticks.", "")]
		public bool isAxis = false;

		[EditorHelp("Trigger At", "The value of the axis on which to trigger the input.\n" +
			"Note that an axis has positive and negative values, so you can have one input at " +
			"e.g. 0.2, another at -0.2, which means you can have input in both directions (using 2 control keys).", "")]
		[EditorCondition("isAxis", true)]
		public float triggerAt = 0;

		[EditorHelp("Axis Timeout (s)", "The timeout in seconds between recognizing a key as an axis instead of a button.\n" +
			"E.g. when using an analog stick of a joystick the input will be recognized permanently, " +
			"so you can set a timeout to recognize it as a single input.", "")]
		[EditorEndCondition]
		[EditorLimit(0.0f, false)]
		public float axisTimeout = 0.5f;

		// conditions
		[EditorHelp("Use Air/Ground", "Recognize if the combatant's game object is in the air or on the ground to enable this key.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Conditions")]
		public bool useAG = false;

		[EditorHelp("In Air", "The input will only be recognized when the combatant is in the air (i.e. not on ground).\n" +
			"For this to work your combatant needs to have a CharacterController component attached.\n" +
			"If disabled, the combatant needs to be on the ground.", "")]
		[EditorCondition("useAG", true)]
		[EditorEndCondition]
		public bool inAir = false;

		[EditorHelp("Use Speed", "Recognize the combatant's current movement speed to enable this key.", "")]
		public bool useSpeed = false;

		[EditorHelp("Minimum Speed", "The minimum movement speed of the combatant to recognize the input.\n" +
			"Use this setting for e.g. sprint attacks, etc.", "")]
		[EditorEndFoldout]
		[EditorCondition("useSpeed", true)]
		[EditorEndCondition]
		[EditorLimit(0.0f, false)]
		public float minSpeed = 0;


		// action settings
		[EditorHelp("Type", "Select the what this control map key will perform:\n" +
			"- Action: An action is performed (e.g. an attack, ability or shortcut slot).\n" +
			"- Auto Attack: Enable/disable the auto attack.\n" +
			"- Global Machine: Calls a global machine using the combatant as the 'Starting Object'.\n" +
			"- Schematic: Starts a schematic using the combatant as 'Machine Object' and 'Starting Object'.", "")]
		[EditorFoldout("Action Settings", "Define the action that will be used upon key input.", "")]
		public ControlMapKeyType type = ControlMapKeyType.Action;

		// action
		[EditorCondition("type", ControlMapKeyType.Action)]
		[EditorAutoInit]
		public ActionSelection actionSettings;

		[EditorHelp("Block Battle Camera", "Block battle camera changes for this action.\n" +
			"The battle camera settings can be found in 'Battle System > Battle Settings'.", "")]
		[EditorCondition("showTooltip", false)]
		[EditorEndCondition(2)]
		public bool blockBattleCamera = false;


		// global machine
		[EditorHelp("Global Machine", "Select the global machine that will be called.\n" +
			"The combatant is used as the 'Machine Object' and 'Starting Object'.", "")]
		[EditorCondition("type", ControlMapKeyType.GlobalMachine)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSelection<GlobalMachineAsset> globalMachine;


		// schematic
		[EditorHelp("Schematic Asset", "Select a schematic asset that will be started.", "")]
		[EditorCondition("type", ControlMapKeyType.Schematic)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<MakinomSchematicAsset> schematic;


		// show tooltip
		[EditorHelp("Show Tooltip", "Show the action/shortcut as a tooltip.\n" +
			"A 'Tooltip' HUD can display the information.\n" +
			"When using 'Action', this is only used for ability and item actions.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Tooltip Settings")]
		[EditorCondition("type", ControlMapKeyType.Action)]
		[EditorDefaultValue(false)]
		public bool showTooltip = false;

		[EditorHelp("2nd Call Closes", "Calling the tooltip for the same action/shortcut a 2nd time will close the tooltip.\n" +
			"This only happens if the used ability/item is the same.", "")]
		[EditorCondition("showTooltip", true)]
		public bool closeOn2nd = true;

		[EditorHelp("Prioritize Tooltip", "The tooltip will be prioritized, i.e. other tooltips happening will not overrule it.")]
		public bool tooltipPrioritize = false;

		[EditorHelp("Auto Close", "Auto close the tooltip after a defined amount of time.\n" +
			"If disabled, the tooltip will stay opened until the control key is used a 2nd time.", "")]
		public bool autoCloseTooltip = false;

		[EditorHelp("Close After (s)", "The time in seconds until the tooltip will be closed.", "")]
		[EditorCondition("autoCloseTooltip", true)]
		[EditorEndCondition]
		public float autoCloseTime = 3;

		// cancel target selection
		[EditorHelp("2nd Call Cancels Targeting", "Calling the action/shortcut a 2nd time will cancel it's target selection.\n" +
			"This only happens if the used ability/item is the same.", "")]
		[EditorElseCondition]
		public bool targetingCancelOn2nd = false;


		// target settings
		[EditorSeparator]
		[EditorTitleLabel("Target Settings")]
		[EditorEndCondition(2)]
		public ControlMapTargeting targeting = new ControlMapTargeting();


		// auto attack
		[EditorHelp("Enable Auto Attack", "If enabled, the combatant's auto attack will be enabled.\n" +
			"If disabled, the combatant's auto attack will be disabled.", "")]
		[EditorEndFoldout]
		[EditorCondition("type", ControlMapKeyType.AutoAttack)]
		[EditorEndCondition]
		public bool enableAutoAttack = false;


		// conditions
		[EditorHelp("During Target Selection", "This control map key can be used during target selection.", "")]
		[EditorFoldout("Conditions", "Using this control map key can depend on combatant status and variable conditions.", "")]
		public bool duringTargetSelection = true;

		[EditorSeparator]
		[EditorEndFoldout]
		public CombatantGeneralConditionSettings conditions = new CombatantGeneralConditionSettings();


		// audio settings
		[EditorHelp("Own Success Clip", "This control map key uses a custom success clip when successfully using the key.", "")]
		[EditorFoldout("Audio Settings", "A control map key can optionally override the control map's success clip.", "")]
		public bool ownSuccessClip = false;

		[EditorHelp("Success Clip", "Select the audio clip that will be played when successfully using a control map key.", "")]
		[EditorCondition("ownSuccessClip", true)]
		[EditorAutoInit]
		public AssetSource<AudioClip> successClip;

		[EditorHelp("Volume (Success)", "The volume used to play the success clip (between 0 and 1).", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		[EditorLimit(0.0f, 1.0f)]
		public float successVolume = 1;


		// ingame
		private float timeout = 0;

		public ControlMapKey()
		{

		}


		/*
		============================================================================
		Key functions
		============================================================================
		*/
		public bool KeyValid(Combatant combatant)
		{
			return this.timeout <= Time.realtimeSinceStartup &&
				(!this.useAG || combatant.Object.Component.InAir == this.inAir) &&
				(!this.useSpeed || combatant.Object.Component.HorizontalSpeed >= this.minSpeed) &&
				this.ControlAccepted(combatant) &&
				(this.duringTargetSelection || !ORK.Battle.IsTargetSelectionActive) &&
				this.conditions.Check(combatant);
		}

		private bool ControlAccepted(Combatant combatant)
		{
			bool accept = false;
			if(this.isAxis)
			{
				float a = InputKey.GetAxis(this.key, combatant.InputID);
				if((this.triggerAt < 0 && a < this.triggerAt) ||
					(this.triggerAt > 0 && a > this.triggerAt))
				{
					accept = true;
					this.timeout = Time.realtimeSinceStartup + this.axisTimeout;
				}
			}
			else if(InputKey.GetButton(this.key.StoredAsset, combatant.InputID))
			{
				accept = true;
			}
			return accept;
		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public bool PerformAction(Combatant combatant)
		{
			BaseAction action = null;

			// action
			if(ControlMapKeyType.Action == this.type)
			{
				if(this.showTooltip)
				{
					if(this.actionSettings.ShowTooltip(combatant,
						this.autoCloseTooltip ? this.autoCloseTime : -1, this.closeOn2nd, this.tooltipPrioritize))
					{
						return true;
					}
				}
				else if(this.actionSettings.GetAction(out action, combatant, true, true, true,
					 this.targeting, this.blockBattleCamera, this.targetingCancelOn2nd))
				{
					if(action != null)
					{
						combatant.Actions.AddAccess(action, !combatant.Actions.IsChoosing);
					}
					return true;
				}
			}
			// auto attack
			else if(ControlMapKeyType.AutoAttack == this.type)
			{
				combatant.Battle.EnableAutoAttack = this.enableAutoAttack;
				return true;
			}
			// global machine
			else if(ControlMapKeyType.GlobalMachine == this.type)
			{
				GlobalMachineAsset asset = this.globalMachine.StoredAsset;
				if(asset != null)
				{
					asset.Settings.Call(combatant, combatant, null);
				}
				return true;
			}
			// schematic
			else if(ControlMapKeyType.Schematic == this.type)
			{
				MakinomSchematicAsset tmpAsset = this.schematic.StoredAsset;
				if(tmpAsset != null)
				{
					Schematic.Play(tmpAsset, this, null, combatant, combatant);
					return true;
				}
			}

			if(action != null)
			{
				combatant.Actions.AddAccess(action, !combatant.Actions.IsChoosing);
				return true;
			}
			return false;
		}
	}
}
