﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Equipment Slot Equipped", "A defined equipment slot must or mustn't have something equipped.")]
	public class EquipmentSlotEquippedStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Equipment Slot", "Select the equipment slot that will be check.", "")]
		public AssetSelection<EquipmentSlotAsset> equipmentSlot = new AssetSelection<EquipmentSlotAsset>();

		[EditorHelp("Is Equipped", "The equipment slot must be have an equipment equipped.\n" +
			"If disabled, the equipment slot must be empty.", "")]
		public bool isEquipped = true;

		public EquipmentSlotEquippedStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.equipmentSlot.ToString() + (this.isEquipped ? " is equipped" : " not equipped");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.equipmentSlot.StoredAsset != null &&
				combatant.Equipment.GetSlot(this.equipmentSlot.StoredAsset.Settings).Equipped == this.isEquipped;
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete ||
				combatant.Bestiary.status.equipment))
			{
				return this.Check(combatant);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.EquipmentChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.EquipmentChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.EquipmentChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.EquipmentChangedSimple -= notify;
		}
	}
}
