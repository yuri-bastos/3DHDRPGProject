﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;
using GamingIsLove.ORKFramework.AI;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("AI Type", "A defined AI type must or mustn't be equipped on an AI behaviour slot or AI ruleset slot.")]
	public class AITypeStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("AI Type", "Select the AI type that will be used.", "")]
		public AssetSelection<AITypeAsset> aiType = new AssetSelection<AITypeAsset>();

		[EditorHelp("Use Sub-Types", "The sub-types of the defined AI type will also be checked.", "")]
		[EditorIndent]
		public bool useSubTypes = false;

		[EditorHelp("Is Equipped", "The AI type must be equipped in one of the combatant's AI slots.\n" +
			"If disabled, the AI type mustn't be equipped.", "")]
		public bool isEquipped = true;

		public AITypeStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.aiType.ToString() + (this.isEquipped ? " is equipped" : " not equipped");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.aiType.StoredAsset != null &&
				(combatant.AI.IsAITypeEquipped(this.aiType.StoredAsset.Settings, this.useSubTypes) == this.isEquipped);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.AIChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.AIChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.AIChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.AIChangedSimple -= notify;
		}
	}
}
