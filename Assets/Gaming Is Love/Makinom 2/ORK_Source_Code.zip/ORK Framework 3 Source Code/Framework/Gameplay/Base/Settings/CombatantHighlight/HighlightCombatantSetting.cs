﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class HighlightCombatantSetting : BaseData
	{
		[EditorArray("Add Highlight", "Adds a highlight.", "",
			"Remove", "Remove this highlight.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Highlight", "Define the highlight that will be used.", ""
			})]
		public CombatantHighlightType[] highlight = new CombatantHighlightType[0];

		public HighlightCombatantSetting()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("useCursor"))
			{
				List<CombatantHighlightType> highlights = new List<CombatantHighlightType>();
				// prefab
				bool tmp = false;
				data.Get("useCursor", ref tmp);
				if(tmp)
				{
					CombatantHighlightType tmpType = new CombatantHighlightType();
					tmpType.settings = new PrefabCombatantHighlightType();
					tmpType.settings.SetData(data);
					tmpType.type = tmpType.settings.GetType().ToString();
					highlights.Add(tmpType);
				}
				// fade color
				FadeType tmp2 = FadeType.None;
				data.GetEnum<FadeType>("gameObjectFadeType", ref tmp2);
				if(FadeType.None != tmp2)
				{
					CombatantHighlightType tmpType = new CombatantHighlightType();
					tmpType.settings = new FadeColorCombatantHighlightType();
					tmpType.settings.SetData(data);
					tmpType.type = tmpType.settings.GetType().ToString();
					highlights.Add(tmpType);
				}
				// fade HUD color
				tmp2 = FadeType.None;
				data.GetEnum<FadeType>("hudFadeType", ref tmp2);
				if(FadeType.None != tmp2)
				{
					CombatantHighlightType tmpType = new CombatantHighlightType();
					tmpType.settings = new FadeHUDColorCombatantHighlightType();
					tmpType.settings.SetData(data);
					tmpType.type = tmpType.settings.GetType().ToString();
					highlights.Add(tmpType);
				}

				this.highlight = highlights.ToArray();
			}
		}

		public virtual void Highlight(Combatant combatant)
		{
			if(combatant != null)
			{
				for(int i = 0; i < this.highlight.Length; i++)
				{
					this.highlight[i].settings.Highlight(combatant);
				}
			}
		}

		public virtual void Highlight(Combatant user, Combatant target, IShortcut shortcut)
		{
			if(target != null)
			{
				for(int i = 0; i < this.highlight.Length; i++)
				{
					this.highlight[i].settings.Highlight(user, target, shortcut);
				}
			}
		}

		public virtual void StopHighlight(Combatant combatant)
		{
			if(combatant != null)
			{
				for(int i = this.highlight.Length - 1; i >= 0; i--)
				{
					this.highlight[i].settings.StopHighlight(combatant);
				}
			}
		}
	}
}
