﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Is Choosing", "The combatant must or mustn't be choosing an action (e.g. displaying the battle menu).")]
	public class IsChoosingStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is Choosing", "The combatant must be choosing an action (e.g. when the battle menu is displayed).\n" +
			"If disabled, the combatant mustn't be choosing an action.", "")]
		public bool isChoosing = true;

		public IsChoosingStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isChoosing ? "is choosing actions" : "not choosing actions";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.Actions.IsChoosing == this.isChoosing;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ChoosingStateChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.ChoosingStateChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.ChoosingStateChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.ChoosingStateChangedSimple -= notify;
		}
	}
}
