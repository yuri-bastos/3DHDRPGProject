﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.Animations
{
	public class AnimationsFieldBattle : BaseData
	{
		[EditorHelp("Animations", "Select the animation settings used to animate the combatant.", "")]
		[EditorArray("Add Animations", "Add animation settings that'll be used to animate the combatant.", "",
			"Remove", "Remove this animation.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
					"Animation", "Select the animation setting that will be used.", ""
				})]
		public AssetSelection<AnimationAsset>[] animation = new AssetSelection<AnimationAsset>[0];

		[EditorHelp("Animations (Battle)", "Select the animation settings used to animate the combatant in battle.\n" +
			"Can be used to override field animations, e.g. using a different idle or run animation in battle.", "")]
		[EditorArray("Add Animations (Battle)", "Add animation settings that'll be used to animate the combatant in battle.\n" +
			"Can be used to override field animations, e.g. using a different idle or run animation in battle.", "",
			"Remove", "Remove this animation.", "",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
					"Animation (Battle)", "Select the animation setting that will be used in battle.", ""
				})]
		public AssetSelection<AnimationAsset>[] animationBattle = new AssetSelection<AnimationAsset>[0];

		public AnimationsFieldBattle()
		{

		}

		public virtual bool HasAnimations(Combatant combatant)
		{
			return this.animation.Length > 0 || 
				(combatant.Battle.InBattle && this.animationBattle.Length > 0);
		}

		public virtual void GetAnimations(Combatant combatant, ref List<AnimationSetting> list)
		{
			if(combatant.Battle.InBattle)
			{
				for(int i = 0; i < this.animationBattle.Length; i++)
				{
					if(this.animationBattle[i].StoredAsset != null)
					{
						list.Add(this.animationBattle[i].StoredAsset.Settings);
					}
				}
			}
			for(int i = 0; i < this.animation.Length; i++)
			{
				if(this.animation[i].StoredAsset != null)
				{
					list.Add(this.animation[i].StoredAsset.Settings);
				}
			}
		}
	}
}
