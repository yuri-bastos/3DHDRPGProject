﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class EquipmentPrefabSettings : BaseData
	{
		// prefab
		public EquipmentPrefab prefab = new EquipmentPrefab();


		// conditional prefabs
		[EditorSeparator]
		[EditorArray("Add Conditional Prefab", "Adds a conditional prefab.\n" +
			"A conditional prefab can replace the item's prefab based on variable conditions.\n" +
			"The first conditional prefab with valid conditions will be used. " +
			"If none is valid, the base prefab will be used.", "",
			"Remove", "Removes this conditional prefab.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Conditional Prefab", "A conditional prefab can replace the item's " +
				"prefab based on variable conditions.\n" +
				"The first conditional prefab with valid conditions will be used. " +
				"If none is valid, the base prefab will be used.", ""
		})]
		public EquipmentConditionalPrefab[] conditionalPrefab = new EquipmentConditionalPrefab[0];

		public EquipmentPrefabSettings()
		{

		}

		public virtual bool HasConditions
		{
			get
			{
				for(int i = 0; i < this.conditionalPrefab.Length; i++)
				{
					if(this.conditionalPrefab[i].condition.Has)
					{
						return true;
					}
				}
				return false;
			}
		}

		public virtual int GetPrefabIndex(IVariableSource variableSource)
		{
			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					return i;
				}
			}
			return -1;
		}

		public virtual EquipmentPrefab Get(int index)
		{
			if(index >= 0 &&
				index < this.conditionalPrefab.Length)
			{
				return this.conditionalPrefab[index].prefab;
			}
			return this.prefab;
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public virtual GameObject GetPrefab(IVariableSource variableSource)
		{
			GameObject prefab = null;
			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					prefab = this.conditionalPrefab[i].prefab.itemPrefab.prefab.StoredAsset;
					return prefab != null ? prefab : ORK.InventorySettings.prefabSettings.GetPrefab(variableSource);
				}
			}

			// base prefab
			prefab = this.prefab.itemPrefab.prefab.StoredAsset;
			return prefab != null ? prefab : ORK.InventorySettings.prefabSettings.GetPrefab(variableSource);
		}

		public virtual GameObject GetPrefab(IVariableSource variableSource, ref int prefabIndex, ref Vector3 offset)
		{
			GameObject prefab = null;
			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					prefab = this.conditionalPrefab[i].prefab.itemPrefab.prefab.StoredAsset;
					if(prefab != null)
					{
						offset = this.conditionalPrefab[i].prefab.itemPrefab.spawnOffset;
					}
					else
					{
						prefab = ORK.InventorySettings.prefabSettings.GetPrefab(variableSource, ref prefabIndex, ref offset);
					}
					prefabIndex = i;
					return prefab;
				}
			}

			// base prefab
			prefab = this.prefab.itemPrefab.prefab.StoredAsset;
			if(prefab != null)
			{
				offset = this.prefab.itemPrefab.spawnOffset;
			}
			else
			{
				prefab = ORK.InventorySettings.prefabSettings.GetPrefab(variableSource, ref prefabIndex, ref offset);
			}
			prefabIndex = -1;
			return prefab;
		}


		/*
		============================================================================
		Equipment viewer functions
		============================================================================
		*/
		public virtual GameObject CreateViewerPrefab(Transform parent, IVariableSource variableSource, bool isPrefabView)
		{
			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					return this.conditionalPrefab[i].prefab.CreateViewerPrefab(parent, isPrefabView);
				}
			}

			// base prefab
			return this.prefab.CreateViewerPrefab(parent, isPrefabView);
		}


		/*
		============================================================================
		Portrait functions
		============================================================================
		*/
		public virtual GameObject GetPortraitPrefab(IVariableSource variableSource)
		{
			GameObject prefab = null;

			// conditional prefab
			for(int i = 0; i < this.conditionalPrefab.Length; i++)
			{
				if(this.conditionalPrefab[i].Check(variableSource))
				{
					if(prefab == null)
					{
						prefab = this.conditionalPrefab[i].prefab.prefabViewViewerPrefab.StoredAsset;
					}
					if(prefab == null)
					{
						prefab = this.conditionalPrefab[i].prefab.viewerPrefab.StoredAsset;
					}
					if(prefab == null)
					{
						prefab = this.conditionalPrefab[i].prefab.prefabViewPrefab.StoredAsset;
					}
					if(prefab == null)
					{
						prefab = this.conditionalPrefab[i].prefab.itemPrefab.prefab.StoredAsset;
					}
					return prefab;
				}
			}

			// base prefab
			if(prefab == null)
			{
				prefab = this.prefab.prefabViewViewerPrefab.StoredAsset;
			}
			if(prefab == null)
			{
				prefab = this.prefab.viewerPrefab.StoredAsset;
			}
			if(prefab == null)
			{
				prefab = this.prefab.prefabViewPrefab.StoredAsset;
			}
			if(prefab == null)
			{
				prefab = this.prefab.itemPrefab.prefab.StoredAsset;
			}
			if(prefab == null)
			{
				prefab = ORK.InventorySettings.prefabSettings.GetPrefab(variableSource);
			}
			return prefab;
		}

		public virtual void SetPortraitPrefab(TypePrefabViewPortrait portrait, IVariableSource variableSource)
		{
			if(portrait != null &&
				portrait.CanSetPrefab)
			{
				portrait.SetPrefab(this.GetPortraitPrefab(variableSource));
				if(this.HasConditions &&
					portrait.PrefabView.clearCall == null)
				{
					// check
					Notify check = delegate ()
					{
						portrait.SetPrefab(this.GetPortraitPrefab(variableSource));
					};

					// register
					Maki.Game.Variables.Changed += check;
					if(variableSource != null &&
						variableSource.HasVariables)
					{
						variableSource.Variables.Changed += check;
					}

					// remove
					portrait.PrefabView.clearCall = delegate ()
					{
						Maki.Game.Variables.Changed -= check;
						if(variableSource != null &&
							variableSource.HasVariables)
						{
							variableSource.Variables.Changed -= check;
						}
					};

				}
			}
		}
	}
}
