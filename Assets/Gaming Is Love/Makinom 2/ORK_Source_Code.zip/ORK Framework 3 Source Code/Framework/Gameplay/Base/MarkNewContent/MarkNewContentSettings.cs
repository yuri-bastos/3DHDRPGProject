﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class MarkNewContentSettings : BaseData
	{
		[EditorFoldout("Default Settings", "The default settings for marking new content.\n" +
			"This can be optionally overridden for different contents.", "")]
		[EditorEndFoldout]
		public MarkNewContent markNewContent = new MarkNewContent();


		// abilities
		[EditorHelp("Override Settings", "Ability content uses custom settings.", "")]
		[EditorFoldout("Ability Settings", "Optionally override the default settings for ability content.\n" +
			"For ability content, 'Each Add' refers to each time learning an ability (after removing it), " +
			"'Each Change' refers to increasing an ability's level.", "")]
		public bool ownAbility = false;

		[EditorEndFoldout]
		[EditorCondition("ownAbility", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent ability;


		// classes
		[EditorHelp("Override Settings", "Class content uses custom settings.", "")]
		[EditorFoldout("Class Settings", "Optionally override the default settings for class content.\n" +
			"For class content, 'First Add' and 'Each Add' refers to each time adding a class, " +
			"'Each Change' refers to increasing a class's level.", "")]
		public bool ownClass = false;

		[EditorEndFoldout]
		[EditorCondition("ownClass", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent classContent;


		// AI behaviours
		[EditorHelp("Override Settings", "AI behaviour content uses custom settings.", "")]
		[EditorFoldout("AI Behaviour Settings", "Optionally override the default settings for AI behaviour content.\n" +
			"For AI behaviour content, 'Each Add' refers to each time adding a new AI behaviour, " +
			"'Each Change' refers to increasing an AI behaviour's quantity.", "")]
		public bool ownAIBehaviour = false;

		[EditorEndFoldout]
		[EditorCondition("ownAIBehaviour", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent aiBehaviour;


		// AI rulesets
		[EditorHelp("Override Settings", "AI ruleset content uses custom settings.", "")]
		[EditorFoldout("AI Ruleset Settings", "Optionally override the default settings for AI ruleset content.\n" +
			"For AI ruleset content, 'Each Add' refers to each time adding a new AI ruleset, " +
			"'Each Change' refers to increasing an AI ruleset's quantity.", "")]
		public bool ownAIRuleset = false;

		[EditorEndFoldout]
		[EditorCondition("ownAIRuleset", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent aiRuleset;


		// bestiary
		[EditorHelp("Override Settings", "Bestiary content uses custom settings.", "")]
		[EditorFoldout("Bestiary Settings", "Optionally override the default settings for bestiary content.\n" +
			"For bestiary content, 'Each Add' refers to each time adding a new area to a bestiary entry, " +
			"'Each Change' refers to new area and status information.", "")]
		public bool ownBestiary = false;

		[EditorEndFoldout]
		[EditorCondition("ownBestiary", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent bestiary;


		// crafting recipes
		[EditorHelp("Override Settings", "Crafting recipe content uses custom settings.", "")]
		[EditorFoldout("Crafting Recipe Settings", "Optionally override the default settings for crafting recipe content.\n" +
			"For crafting recipe content, 'Each Add' refers to each time adding a new crafting recipe, " +
			"'Each Change' refers to increasing a crafting recipe's quantity.", "")]
		public bool ownCraftingRecipe = false;

		[EditorEndFoldout]
		[EditorCondition("ownCraftingRecipe", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent craftingRecipe;


		// equipment
		[EditorHelp("Override Settings", "Equipment content uses custom settings.", "")]
		[EditorFoldout("Equipment Settings", "Optionally override the default settings for equipment content.\n" +
			"For equipment content, 'Each Add' refers to each time adding an equipment (as a separate item), " +
			"'Each Change' refers to increasing an added equipment's quantity.", "")]
		public bool ownEquipment = false;

		[EditorEndFoldout]
		[EditorCondition("ownEquipment", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent equipment;


		// items
		[EditorHelp("Override Settings", "Item content uses custom settings.", "")]
		[EditorFoldout("Item Settings", "Optionally override the default settings for item content.\n" +
			"For item content, 'Each Add' refers to each time adding an item (as a separate item), " +
			"'Each Change' refers to increasing an added item's quantity.", "")]
		public bool ownItem = false;

		[EditorEndFoldout]
		[EditorCondition("ownItem", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent item;


		// logs
		[EditorHelp("Override Settings", "Log content uses custom settings.", "")]
		[EditorFoldout("Log Settings", "Optionally override the default settings for log content.\n" +
			"For log content, 'Each Add' refers to each time adding a log (e.g. after removing it), " +
			"'Each Change' refers to new log texts added to the log.", "")]
		public bool ownLog = false;

		[EditorEndFoldout]
		[EditorCondition("ownLog", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent log;


		// quests
		[EditorHelp("Override Settings", "Quest content uses custom settings.", "")]
		[EditorFoldout("Quest Settings", "Optionally override the default settings for quest content.\n" +
			"For quest content, 'Each Add' refers to each time adding a quest (e.g. after removing it), " +
			"'Each Change' refers to changing a quest/task status.", "")]
		public bool ownQuest = false;

		[EditorEndFoldout]
		[EditorCondition("ownQuest", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent quest;


		// research
		[EditorHelp("Override Settings", "Research tree content uses custom settings.", "")]
		[EditorFoldout("Research Tree Settings", "Optionally override the default settings for research tree content.\n" +
			"For research tree content, 'Each Add' refers to each time adding a research tree, " +
			"'Each Change' refers to changes in the state of research tree items.", "")]
		public bool ownResearchTree = false;

		[EditorEndFoldout]
		[EditorCondition("ownResearchTree", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent researchTree;


		// shops
		[EditorHelp("Override Settings", "Shop content uses custom settings.", "")]
		[EditorFoldout("Shop Settings", "Optionally override the default settings for shop content.\n" +
			"For shop content, 'Each Add' refers to each time adding an item to the shop (as a separate item), " +
			"'Each Change' refers to increasing an added shop item's quantity.", "")]
		public bool ownShop = false;

		[EditorEndFoldout]
		[EditorCondition("ownShop", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public MarkNewContent shop;

		public MarkNewContentSettings()
		{

		}
	}
}
