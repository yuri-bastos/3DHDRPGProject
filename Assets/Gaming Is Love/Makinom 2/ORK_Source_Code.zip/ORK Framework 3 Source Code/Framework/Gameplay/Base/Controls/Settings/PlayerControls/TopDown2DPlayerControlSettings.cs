﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class TopDown2DPlayerControlSettings : BaseData
	{
		[EditorHelp("Vertical Axis", "The key used for vertical control.", "")]
		public AssetSelection<InputKeyAsset> verticalAxis = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Horizontal Axis", "The key used for horizontal control.", "")]
		public AssetSelection<InputKeyAsset> horizontalAxis = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Rotate Z Axis", "Rotate the Z-axis of the player into the movement direction.")]
		[EditorSeparator]
		public bool rotateZAxis = false;


		// flipping
		[EditorHelp("Vertical Flip", "Vertically flip the player (i.e. negating the Y-axis scale).", "")]
		[EditorSeparator]
		public bool verticalFlip = false;

		[EditorHelp("Negate Flip", "Negate the flip direction, i.e. down will flip positive, up will flip negative.", "")]
		[EditorIndent]
		[EditorCondition("verticalFlip", true)]
		[EditorEndCondition]
		public bool verticalFlipNegate = false;

		[EditorHelp("Horizontal Flip", "Horizontally flip the player (i.e. negating the X-axis scale).", "")]
		public bool horizontalFlip = false;

		[EditorHelp("Negate Flip", "Negate the flip direction, i.e. left will flip positive, right will flip negative.", "")]
		[EditorIndent]
		[EditorCondition("horizontalFlip", true)]
		[EditorEndCondition]
		public bool horizontalFlipNegate = false;

		[EditorHelp("Flip Input Ignore", "Don't flip if the input axis is below this value.", "")]
		[EditorLimit(0.0f, false)]
		public float flipInputIgnore = 0.1f;


		// sprint
		[EditorHelp("Use Sprint", "The player can sprint.", "")]
		[EditorFoldout("Sprint Settings", "Optionally allow the player to sprint.", "")]
		public bool useSprint = false;

		[EditorHelp("Sprint Key", "The key used to sprint.\n" +
			"The key must be held down to sprint - select handling type Hold in the settings of the key.", "")]
		[EditorCondition("useSprint", true)]
		public AssetSelection<InputKeyAsset> sprintKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Sprint Factor", "The players move speed will be multiplied with this number when sprinting.\n" +
			"E.g. 2 will double the move speed.", "")]
		public float sprintFactor = 2.0f;

		[EditorHelp("Use Energy", "Sprinting will consume energy.", "")]
		public bool useEnergy = false;

		[EditorHelp("Maximum Energy", "The maximum sprint energy.")]
		[EditorCondition("useEnergy", true)]
		public FloatValue<GameObjectSelection> maxEnergy = new FloatValue<GameObjectSelection>();

		[EditorHelp("Energy Consume", "The energy consumed per second when sprinting.")]
		public FloatValue<GameObjectSelection> energyConsume = new FloatValue<GameObjectSelection>();

		[EditorHelp("Energy Regeneration", "The energy regenerated per second.")]
		[EditorEndFoldout]
		[EditorEndCondition(2)]
		public FloatValue<GameObjectSelection> energyRegeneration = new FloatValue<GameObjectSelection>();

		public TopDown2DPlayerControlSettings()
		{

		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public void AddPlayerControl(GameObject player)
		{
			TopDown2DPlayerController comp = player.GetComponent<TopDown2DPlayerController>();
			if(comp == null)
			{
				comp = player.AddComponent<TopDown2DPlayerController>();
			}
			comp.settings.SetData(this.GetData());

			Maki.Control.AddPlayerControl(comp);
		}

		public void RemovePlayerControl(GameObject player)
		{
			TopDown2DPlayerController comp = player.GetComponent<TopDown2DPlayerController>();
			if(comp != null)
			{
				Maki.Control.RemovePlayerControl(comp);
				GameObject.Destroy(comp);
			}
		}
	}
}
