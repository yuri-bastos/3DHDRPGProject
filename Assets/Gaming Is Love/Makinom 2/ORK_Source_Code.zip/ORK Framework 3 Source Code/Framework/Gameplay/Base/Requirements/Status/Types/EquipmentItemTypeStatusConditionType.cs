﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Equipment Item Type", "An equipment of the selected item type must or mustn't be equipped.")]
	public class EquipmentItemTypeStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Item Type", "Select the item type that will be used.", "")]
		public AssetSelection<ItemTypeAsset> itemType = new AssetSelection<ItemTypeAsset>();

		[EditorHelp("Use Sub-Types", "The sub-types of the defined item type will also be checked.", "")]
		[EditorIndent]
		public bool useSubTypes = false;

		[EditorHelp("Is Equipped", "An equipment of the defined item type must be equipped on the combatant.\n" +
			"If disabled, an equipment of the defined item type mustn't be equipped.", "")]
		public bool isEquipped = true;

		[EditorHelp("Check Equipment Slot", "Check if an equipment of the defined item type is equipped on a defined equipment slot.\n" +
			"If disabled, checks if an equipment of the defined item type is equipped on any slot.", "")]
		public bool checkEquipmentSlot = false;

		[EditorHelp("Equipment Slot", "Select the equipment slot you want to check.", "")]
		[EditorCondition("checkEquipmentSlot", true)]
		[EditorEndCondition]
		public AssetSelection<EquipmentSlotAsset> equipmentSlot = new AssetSelection<EquipmentSlotAsset>();

		public EquipmentItemTypeStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.itemType.ToString() + (this.isEquipped ? " is equipped" : " not equipped") +
				(this.checkEquipmentSlot ? " on " + this.equipmentSlot.ToString() : "");
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.itemType.StoredAsset != null &&
				combatant.Equipment.IsTypeEquipped(this.useSubTypes, this.itemType.StoredAsset.Settings,
					this.checkEquipmentSlot && this.equipmentSlot.StoredAsset != null ?
						this.equipmentSlot.StoredAsset.Settings : null) == this.isEquipped;
		}

		public override bool CheckBestiary(Combatant combatant)
		{
			if(combatant.Bestiary != null &&
				(combatant.Bestiary.IsComplete ||
				combatant.Bestiary.status.equipment))
			{
				return this.Check(combatant);
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.EquipmentChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.EquipmentChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.EquipmentChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.EquipmentChangedSimple -= notify;
		}
	}
}
