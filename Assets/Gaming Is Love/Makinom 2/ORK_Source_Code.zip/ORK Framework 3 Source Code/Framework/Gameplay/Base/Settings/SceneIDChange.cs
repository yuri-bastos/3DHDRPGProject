﻿
using UnityEngine;
using GamingIsLove.ORKFramework;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class SceneIDChange<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Scene ID Type", "Select the type of the scene ID that will be changed:\n" +
			"- Item: The scene ID of an item collector.\n" +
			"- Battle: The scene ID of a battle or combatant spawner.", "")]
		public SceneIDChangeType type = SceneIDChangeType.Item;

		[EditorHelp("Remove", "The scene ID will be removed, making the scene content available again.", "")]
		public bool remove = false;

		[EditorSeparator]
		[EditorTitleLabel("Scene ID")]
		public FloatValue<T> sceneID = new FloatValue<T>();

		public SceneIDChange()
		{

		}

		public void Change(string sceneName, IDataCall call)
		{
			if(SceneIDChangeType.Item == this.type)
			{
				ORK.Game.Scene.ItemCollected(sceneName,
					(int)this.sceneID.GetValue(call), !this.remove);
			}
			else if(SceneIDChangeType.Battle == this.type)
			{
				ORK.Game.Scene.BattleFinished(sceneName,
					(int)this.sceneID.GetValue(call), !this.remove);
			}
		}
	}
}
