﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Grid Move Range", "The combatant's grid move range will be compared to a defined value.")]
	public class GridMoveRangeStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Max Grid Move Range", "Check the combatant's maximum grid move range.\n" +
			"If disabled, the current grid move range will be checked.", "")]
		public bool maxGridMoveRange = false;

		public ValueCheck<GameObjectSelection> check = new ValueCheck<GameObjectSelection>();

		public GridMoveRangeStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.maxGridMoveRange ? "Max Grid Move Range " : "Grid Move Range ") + this.check.ToString();
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.check.Check(
				this.maxGridMoveRange ? combatant.Battle.GridMoveRangeMax : combatant.Battle.GridMoveRange,
				combatant.Call);
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.GridMoveRangeChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.GridMoveRangeChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.GridMoveRangeChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.GridMoveRangeChangedSimple -= notify;
		}
	}
}
