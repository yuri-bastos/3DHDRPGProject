﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Group Member Index", "The combatant must or mustn't be the member at a defined index of it's group or battle group.")]
	public class GroupMemberIndexStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Member Index", "The member index that will be checked for.", "")]
		[EditorLimit(0, false)]
		public int index = 0;

		[EditorHelp("Is Index", "The combatant must be the member at the defined index.\n" +
			"If disabled, the combatant mustn't be the member at the defined index.", "")]
		public bool isIndex = true;

		[EditorHelp("Check Battle Group", "Check the battle group member index.\n" +
			"If disabled, the whole group member index will be checked.", "")]
		public bool battleGroup = true;

		public GroupMemberIndexStatusConditionType()
		{

		}

		public override string ToString()
		{
			return (this.battleGroup ? 
					(this.isIndex ? "is battle member index " : "not battle member index ") : 
					(this.isIndex ? "is member index " : "not member index "))+ this.index;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.battleGroup ?
				(combatant.Group.GetBattleMemberIndex(combatant) == this.index) == this.isIndex :
				(combatant.Group.GetMemberIndex(combatant) == this.index) == this.isIndex;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.GroupChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.GroupChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.GroupChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.GroupChangedSimple -= notify;
		}
	}
}
