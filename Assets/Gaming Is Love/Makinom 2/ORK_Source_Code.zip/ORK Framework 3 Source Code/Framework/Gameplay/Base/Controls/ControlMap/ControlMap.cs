
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class ControlMapAsset : MakinomGenericAsset<ControlMap>
	{
		public ControlMapAsset()
		{

		}

		public override string DataName
		{
			get { return "Control Map"; }
		}
	}

	public class ControlMap : BaseIndexData
	{
		[EditorHelp("Name", "The name of the control map.", "")]
		[EditorFoldout("Control Map Settings", "Define the name, battle system availability, control keys and actions of this control map.", "")]
		[EditorWidth(true)]
		public string name = "";


		// audio settings
		[EditorHelp("Sound Channel", "Define the sound channel that will be used.\n" +
			"The default channel is 0.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Audio Settings")]
		[EditorLimit(0, false)]
		public int channel = 0;

		[EditorHelp("Success Clip", "Select the audio clip that will be played when successfully using a control map key.", "")]
		public AssetSource<AudioClip> successClip = new AssetSource<AudioClip>();

		[EditorHelp("Volume (Success)", "The volume used to play the success clip (between 0 and 1).", "")]
		[EditorIndent]
		[EditorLimit(0.0f, 1.0f)]
		public float successVolume = 1;

		[EditorHelp("Fail Clip", "Select the audio clip that will be played when failing to use any control map key.", "")]
		public AssetSource<AudioClip> failClip = new AssetSource<AudioClip>();

		[EditorHelp("Volume (Fail)", "The volume used to play the fail clip (between 0 and 1).", "")]
		[EditorIndent]
		[EditorLimit(0.0f, 1.0f)]
		public float failVolume = 1;


		// system types
		[EditorHelp("Field", "Available in the field (i.e. outside of battles).", "")]
		[EditorSeparator]
		[EditorTitleLabel("Useable In")]
		public bool field = false;

		public BattleSystemCheck battleSystemCheck = new BattleSystemCheck();

		[EditorHelp("While Choosing", "The control map will be available while the combatant's battle menu is active.\n" +
			"If disabled, the control map will only be available if no battle menu is active.", "")]
		[EditorSeparator]
		public bool whileChoosing = false;

		[EditorHelp("While Auto Attacking", "The control map will be available while the combatant is using an auto attack.", "")]
		[EditorEndFoldout]
		public bool whileAutoAttacking = false;


		// requirements
		[EditorFoldout("Conditions", "Using this control map can depend on valid conditions, e.g. combatant status or variable conditions.", "")]
		[EditorEndFoldout]
		public CombatantGeneralConditionSettings conditions = new CombatantGeneralConditionSettings();


		// keys
		[EditorSeparator]
		[EditorArray("Add Control Key", "Add a control key to this control map.", "",
			"Remove", "Remove this control key", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {"Control Key", "A control key can trigger a battle action.\n" +
			"Define the key and action in this settings.\n" +
			"You can have multiple controls on the same key, the first action that can be performed will be performed.\n" +
			"E.g. have multiple refreshing items on the same key, the first item which is in the inventory will be used.", ""})]
		public ControlMapKey[] controlKey = new ControlMapKey[0];


		// ingame
		private bool blocked = false;

		public ControlMap()
		{

		}

		public ControlMap(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}


		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public bool Tick(Combatant combatant)
		{
			if(!this.blocked &&
				this.controlKey.Length > 0 &&
				(combatant.Actions.ActionState == CombatantActionState.Available ||
					(this.whileAutoAttacking && combatant.Actions.AutoAttacking)) &&
				// requirements
				this.conditions.Check(combatant) &&
				// in field
				((!combatant.Battle.InBattle && this.field &&
					(!Maki.Control.Blocked || (this.whileChoosing && combatant.Actions.IsChoosing))) ||
				// in battle
				(combatant.Battle.InBattle && ORK.Control.InBattle &&
					ORK.Battle.IsBattleRunning() && this.battleSystemCheck.Check() &&
					// combatant can perform actions
					(this.whileAutoAttacking || !combatant.Actions.AutoAttacking) &&
					((this.whileChoosing && combatant.Actions.IsChoosing) ||
						combatant.Actions.CanChoose))))
			{
				bool any = false;
				for(int i = 0; i < this.controlKey.Length; i++)
				{
					if(this.controlKey[i].KeyValid(combatant))
					{
						any = true;
						if(this.controlKey[i].PerformAction(combatant))
						{
							if(this.controlKey[i].ownSuccessClip)
							{
								if(this.controlKey[i].successClip != null)
								{
									Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.controlKey[i].successClip, this.controlKey[i].successVolume);
								}
							}
							else
							{
								Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.successClip, this.successVolume);
							}
							return true;
						}
					}
				}
				if(any)
				{
					Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.failClip, this.failVolume);
				}
			}
			return false;
		}

		public bool Blocked
		{
			get { return this.blocked; }
			set { this.blocked = value; }
		}
	}
}
