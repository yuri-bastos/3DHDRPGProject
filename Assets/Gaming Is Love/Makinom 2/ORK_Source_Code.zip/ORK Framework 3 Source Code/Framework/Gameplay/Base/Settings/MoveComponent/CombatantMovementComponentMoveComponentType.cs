﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Combatant Movement Component", "A combatant's 'Movement Component' setup will be used. " +
		"Requires the moving game object to be a combatant's game object.")]
	public class CombatantMovementComponentMoveComponentType : BaseMoveComponentType
	{
		public CombatantMovementComponentMoveComponentType()
		{

		}

		public override string ToString()
		{
			return "Combatant Movement Component";
		}

		public override void InitMover(MoveComponentSettings.Instance mover)
		{
			Combatant combatant = ORKComponentHelper.GetCombatant(mover.gameObject);
			if(combatant != null)
			{
				mover.custom = combatant;
			}
		}

		public override void ChangePosition(MoveComponentSettings.Instance mover, Vector3 positionChange)
		{
			if(mover.custom is Combatant)
			{
				Combatant combatant = (Combatant)mover.custom;
				if(combatant.Object.MovementComponent != null)
				{
					combatant.Object.MovementComponent.Move(positionChange);
				}
			}
		}

		public override void SetPosition(MoveComponentSettings.Instance mover, Vector3 position)
		{
			if(mover.custom is Combatant)
			{
				Combatant combatant = (Combatant)mover.custom;
				if(combatant.Object.MovementComponent != null)
				{
					combatant.Object.MovementComponent.SetPosition(position);
				}
			}
		}
	}
}
