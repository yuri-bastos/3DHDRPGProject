﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	[EditorSettingInfo("Performing Action Start", "When a battle action starts performing (previously no active action).")]
	public class PerformingActionStartGameStateChangeType : BaseGameStateChangeType
	{
		public PerformingActionStartGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			ORK.Battle.Actions.ActiveStart += notify;
		}
	}
}
