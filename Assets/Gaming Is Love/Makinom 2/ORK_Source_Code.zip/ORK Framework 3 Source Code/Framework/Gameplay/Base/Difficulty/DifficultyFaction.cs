
using System;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class DifficultyFaction : BaseData
	{
		[EditorHelp("Faction", "Select the faction that will be used.", "")]
		public AssetSelection<FactionAsset> faction = new AssetSelection<FactionAsset>();


		// status values
		[EditorFoldout("Status Value Multipliers", "Optionally multiply the initial status values of faction members by a defined factor.")]
		[EditorEndFoldout]
		[EditorLabel("Any not added status values will be used as they are defined (i.e. multiplier of 1).")]
		[EditorArray("Add Status Value Multiplier", "Adds a status value multiplier.", "",
			"Remove", "Removes this status value multiplier", "",
			isCopy=true, isMove=true, removeCheckField="status",
			foldout=true, foldoutText=new string[] {
				"Status Value Multiplier", "Define the status value and multiplier that will be used.\n" +
				"The initial values of the status values of all members of this faction will be multiplied by these numbers.\n"+
				"Only 'Normal' and 'Experience' type status values can be used.", ""
			})]
		public StatusValueMultiplier[] statusMultiplier = new StatusValueMultiplier[0];


		// attack modifiers
		[EditorFoldout("Attack Modifier Multipliers", "Optionally multiply the initial attack modifiers of faction members by a defined factor.")]
		[EditorEndFoldout]
		[EditorLabel("Any not added attack modifier be used as they are defined (i.e. multiplier of 1).")]
		[EditorArray("Add Attack Modifier Multiplier", "Adds an attack modifier multiplier.", "",
			"Remove", "Removes this attack modifier multiplier", "",
			isCopy=true, isMove=true, removeCheckField="modifier",
			foldout=true, foldoutText=new string[] {
				"Attack Modifier Multiplier", "Define the attack modifier and multiplier that will be used.\n" +
				"The initial attack modifiers of all members of this faction will be multiplied by this numbers.", ""
			})]
		public AttackModifierMultiplier[] attackModifierMultiplier = new AttackModifierMultiplier[0];


		// defence modifiers
		[EditorFoldout("Defence Modifier Multipliers", "Optionally multiply the initial defence modifiers of faction members by a defined factor.")]
		[EditorEndFoldout]
		[EditorLabel("Any not added defence modifier be used as they are defined (i.e. multiplier of 1).")]
		[EditorArray("Add Defence Modifier Multiplier", "Adds an defence modifier multiplier.", "",
			"Remove", "Removes this defence modifier multiplier.", "",
			isCopy=true, isMove=true, removeCheckField="modifier",
			foldout=true, foldoutText=new string[] {
				"Defence Modifier Multiplier", "Define the defence modifier and multiplier that will be used.\n" +
				"The initial defence modifiers of all members of this faction will be multiplied by this numbers.", ""
			})]
		public DefenceModifierMultiplier[] defenceModifierMultiplier = new DefenceModifierMultiplier[0];

		public DifficultyFaction()
		{

		}

		public float GetStatusMultiplier(StatusValueSetting statusValue)
		{
			for(int i = 0; i < this.statusMultiplier.Length; i++)
			{
				if(this.statusMultiplier[i].status.Is(statusValue))
				{
					return this.statusMultiplier[i].multiplier;
				}
			}
			return 1;
		}

		public float GetAttackModifierMultiplier(AttackModifierSetting modifier)
		{
			for(int i = 0; i < this.attackModifierMultiplier.Length; i++)
			{
				if(this.attackModifierMultiplier[i].modifier.Is(modifier))
				{
					return this.attackModifierMultiplier[i].multiplier;
				}
			}
			return 1;
		}

		public float GetDefenceModifierMultiplier(DefenceModifierSetting modifier)
		{
			for(int i = 0; i < this.defenceModifierMultiplier.Length; i++)
			{
				if(this.defenceModifierMultiplier[i].modifier.Is(modifier))
				{
					return this.defenceModifierMultiplier[i].multiplier;
				}
			}
			return 1;
		}
	}
}
