
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public class StatusConditionTemplateAsset : MakinomGenericAsset<StatusConditionTemplate>
	{
		public StatusConditionTemplateAsset()
		{

		}

		public override string DataName
		{
			get { return "Status Condition Template"; }
		}
	}

	public class StatusConditionTemplate : BaseIndexData
	{
		[EditorHelp("Name", "The name of the status condition template.", "")]
		[EditorFoldout("Template Settings", "Define the name of this status condition template.", "")]
		[EditorEndFoldout]
		[EditorWidth(true)]
		public string name = "";


		// conditions
		[EditorFoldout("Status Conditions", "Define the status conditions of this template.\n" +
			"You can use this template in other status conditions, e.g. in interactions.", "")]
		[EditorEndFoldout]
		public StatusConditionSettings conditions = new StatusConditionSettings();

		public StatusConditionTemplate()
		{

		}

		public StatusConditionTemplate(string name) : base(name)
		{
			this.name = name;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}
	}
}
