﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Is Passive", "The combatant must or mustn't be passive.")]
	public class IsPassiveStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is Passive", "The combatant must be passive.\n" +
			"If disabled, the combatant must be active.", "")]
		public bool isPassive = true;

		public IsPassiveStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isPassive ? "is passive" : "is active";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return combatant.IsPassive == this.isPassive;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.PassiveStateChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.PassiveStateChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.PassiveStateChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.PassiveStateChangedSimple -= notify;
		}
	}
}
