﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Group Leader", "The combatant must or mustn't be the leader of it's group.")]
	public class GroupLeaderStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Is Leader", "The combatant must be the leader of his group.\n" +
			"If disabled, the combatant mustn't be the leader of his group.", "")]
		public bool isLeader = true;

		public GroupLeaderStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.isLeader ? "is leader" : "not leader";
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			return this.isLeader == combatant.IsLeader;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.GroupChanged += notify.NotifyStatusChanged;
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			combatant.Events.GroupChanged -= notify.NotifyStatusChanged;
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			combatant.Events.GroupChangedSimple += notify;
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			combatant.Events.GroupChangedSimple -= notify;
		}
	}
}
