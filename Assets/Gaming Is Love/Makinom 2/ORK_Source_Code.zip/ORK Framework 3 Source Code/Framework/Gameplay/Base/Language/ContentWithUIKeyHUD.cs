﻿
using UnityEngine;
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.UI;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework.UI
{
	public class ContentWithUIKeyHUD : BaseData
	{
		[EditorLanguageExport("MainContent")]
		public TextImageContentWithUIKeyHUD mainContent = new TextImageContentWithUIKeyHUD();

		[EditorArray("Add Additional Content", "Adds an additional content, identified by a content ID.\n" +
			"Additional content is displayed by UI boxes in content components with matching IDs.", "",
			"Remove", "Removes this additional content.", "", isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[] {
				"Additional Content", "Additional content is displayed by UI boxes in content components with matching IDs.", ""
			})]
		public ContentID<TextImageContentWithUIKeyHUD>[] additionalContent = new ContentID<TextImageContentWithUIKeyHUD>[0];

		public ContentWithUIKeyHUD()
		{

		}

		public ContentWithUIKeyHUD(string text)
		{
			this.mainContent.content.data = new TextImageContent(text);
		}

		public ContentWithUIKeyHUD(string contentID, string contentText)
		{
			this.additionalContent = new ContentID<TextImageContentWithUIKeyHUD>[]
			{
				new ContentID<TextImageContentWithUIKeyHUD>(contentID,
					new TextImageContentWithUIKeyHUD(contentText))
			};
		}

		public ContentWithUIKeyHUD(string[] contentID, string[] contentText)
		{
			this.additionalContent = new ContentID<TextImageContentWithUIKeyHUD>[contentID.Length];
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				this.additionalContent[i] = new ContentID<TextImageContentWithUIKeyHUD>(contentID[i],
					new TextImageContentWithUIKeyHUD(i < contentText.Length ? contentText[i] : ""));
			}
		}

		public virtual void UpgradeFromContent(DataObject data)
		{
			if(data != null)
			{
				DataObject mainData = data.GetFile("mainContent");
				if(mainData != null)
				{
					this.mainContent.content.SetData(mainData);
				}

				DataObject[] additionalData = data.GetFileArray("additionalContent");
				if(additionalData != null)
				{
					this.additionalContent = new ContentID<TextImageContentWithUIKeyHUD>[additionalData.Length];
					for(int i = 0; i < this.additionalContent.Length; i++)
					{
						this.additionalContent[i] = new ContentID<TextImageContentWithUIKeyHUD>();
						additionalData[i].Get("contentID", ref this.additionalContent[i].contentID);
						this.additionalContent[i].content.content.SetData(additionalData[i].GetFile("content"));
					}
				}
			}
		}

		public override string ToString()
		{
			return this.mainContent.content.Current.text.text;
		}

		public UIContent GetContent(object hudUser, object uiKeyContent)
		{
			return this.GetContent<UIContent>(hudUser, uiKeyContent);
		}

		public UIContent GetContent(object hudUser, object uiKeyContent, Schematic schematic, int actorID, VariableHandler handler)
		{
			return this.GetContent<UIContent>(hudUser, uiKeyContent, schematic, actorID, handler);
		}

		public T GetContent<T>(object hudUser, object uiKeyContent) where T : UIContent, new()
		{
			T content = new T();
			content.mainContent = this.mainContent.GetContent(hudUser, uiKeyContent);
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				content.AddAdditionalContent(
					this.additionalContent[i].contentID,
					this.additionalContent[i].content.GetContent(hudUser, uiKeyContent));
			}
			return content;
		}

		public T GetContent<T>(object hudUser, object uiKeyContent, Schematic schematic, int actorID, VariableHandler handler) where T : UIContent, new()
		{
			T content = new T();
			content.mainContent = this.mainContent.GetContent(hudUser, uiKeyContent, schematic, actorID, handler);
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				content.AddAdditionalContent(
					this.additionalContent[i].contentID,
					new UIText(this.additionalContent[i].content.GetContent(
						hudUser, uiKeyContent, schematic, actorID, handler)));
			}
			return content;
		}
	}
}
