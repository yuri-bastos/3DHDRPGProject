﻿
using UnityEngine;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework.Conditions
{
	[EditorSettingInfo("Combatant", "The combatant must or mustn't be a selected combatant.")]
	public class CombatantStatusConditionType : BaseStatusConditionType
	{
		[EditorHelp("Combatant", "Select the combatant that will be used.", "")]
		public AssetSelection<CombatantAsset> combatant = new AssetSelection<CombatantAsset>();

		[EditorHelp("Is Combatant", "The combatant must be the selected combatant.\n" +
			"If disabled, the combatant mustn't be the selected combatant.", "")]
		public bool isCombatant = true;

		[EditorHelp("Combatant Scope", "Select the scope that will be checked:\n" +
			"- Current: The combatant that is checked.\n" +
			"- Battle: The members of the checked combatant's battle group.\n" +
			"- Group: All members of the checked combatant's group (in the order they joined).\n" +
			"- Non Battle: The members not in the checked combatant's battle group.\n" +
			"- Battle Reserve: The members in the checked combatant group's battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Non Battle Reserve: The members not in the checked combatant's battle group or battle reserve (same as 'Non Battle' for non-player groups).\n" +
			"- Group Battle Sorted: All members of the checked combatant's group, but first listing battle members, " +
			"followed by battle reserve and finally the rest of the members.\n\n" +
			"When checking the group or battle group, " +
			"'Is Combatant' is valid if at least one member is the selected combatant, " +
			"not 'Is Combatant' is valid if no member is the selected combatant.", "")]
		public MenuCombatantScope combatantScope = MenuCombatantScope.Current;

		public CombatantStatusConditionType()
		{

		}

		public override string ToString()
		{
			return this.combatant.ToString() + (this.isCombatant ? " is " : " not ") + this.combatantScope;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool Check(Combatant combatant)
		{
			if(this.combatant.StoredAsset != null)
			{
				if(MenuCombatantScope.Current == this.combatantScope)
				{
					return (this.combatant.Is(combatant.Setting)) == this.isCombatant;
				}
				else if(MenuCombatantScope.Battle == this.combatantScope)
				{
					return combatant.Group.IsBattleMember(this.combatant.StoredAsset.Settings) == this.isCombatant;
				}
				else if(MenuCombatantScope.Group == this.combatantScope ||
					MenuCombatantScope.GroupBattleSorted == this.combatantScope)
				{
					return combatant.Group.IsMember(this.combatant.StoredAsset.Settings) == this.isCombatant;
				}
				else if(MenuCombatantScope.NonBattle == this.combatantScope)
				{
					return combatant.Group.IsNonBattleMember(this.combatant.StoredAsset.Settings) == this.isCombatant;
				}
				else if(MenuCombatantScope.BattleReserve == this.combatantScope)
				{
					return combatant.Group.IsBattleReserveMember(this.combatant.StoredAsset.Settings) == this.isCombatant;
				}
				else if(MenuCombatantScope.NonBattleReserve == this.combatantScope)
				{
					return !combatant.Group.IsNonBattleReserveMember(this.combatant.StoredAsset.Settings) == this.isCombatant;
				}
			}
			return false;
		}


		/*
		============================================================================
		Status change register functions
		============================================================================
		*/
		public override void Register(Combatant combatant, IStatusChanged notify)
		{
			if(MenuCombatantScope.Current != this.combatantScope)
			{
				combatant.Events.GroupChanged += notify.NotifyStatusChanged;
			}
		}

		public override void Unregister(Combatant combatant, IStatusChanged notify)
		{
			if(MenuCombatantScope.Current != this.combatantScope)
			{
				combatant.Events.GroupChanged -= notify.NotifyStatusChanged;
			}
		}

		public override void Register(Combatant combatant, Notify notify)
		{
			if(MenuCombatantScope.Current != this.combatantScope)
			{
				combatant.Events.GroupChangedSimple += notify;
			}
		}

		public override void Unregister(Combatant combatant, Notify notify)
		{
			if(MenuCombatantScope.Current != this.combatantScope)
			{
				combatant.Events.GroupChangedSimple -= notify;
			}
		}
	}
}
