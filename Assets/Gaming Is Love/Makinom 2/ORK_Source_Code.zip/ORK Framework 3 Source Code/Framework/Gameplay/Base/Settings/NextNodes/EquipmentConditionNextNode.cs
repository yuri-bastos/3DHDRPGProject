﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.ORKFramework
{
	public class EquipmentConditionNextNode<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHide]
		public int next = -1;

		// selected data
		[EditorHelp("Use Selected Data", "Check for an equipment stored in selected data.", "")]
		public bool useSelectedData = false;

		[EditorCondition("useSelectedData", true)]
		[EditorAutoInit]
		public SelectedData<T> selectedData;


		// equipment
		[EditorHelp("Is Unequipped", "The equipment slot has to be unequipped.", "")]
		[EditorElseCondition]
		public bool isUnequipped = false;

		[EditorHelp("Check Item Type", "Check for an item type being equipped instead of a defined equipment.")]
		[EditorCondition("isUnequipped", false)]
		public bool checkItemType = false;

		[EditorHelp("Item Type", "Select the item type that will be checked for.", "")]
		[EditorCondition("checkItemType", true)]
		[EditorAutoInit]
		public AssetSelection<ItemTypeAsset> itemType;

		[EditorHelp("Use Sub-Types", "The sub-types of the defined item type will also be checked.", "")]
		[EditorIndent]
		public bool useSubTypes = false;

		[EditorHelp("Equipment", "Select the equipment that will be checked for.", "")]
		[EditorElseCondition]
		[EditorEndCondition(2)]
		public AssetSelection<EquipmentAsset> equipment = new AssetSelection<EquipmentAsset>();

		public EquipmentConditionNextNode()
		{

		}

		public override string ToString()
		{
			if(this.useSelectedData)
			{
				return this.selectedData.ToString();
			}
			else if(this.isUnequipped)
			{
				return "Unequipped";
			}
			else if(this.checkItemType)
			{
				return this.itemType.ToString();
			}
			else
			{
				return this.equipment.ToString();
			}
		}
	}
}
