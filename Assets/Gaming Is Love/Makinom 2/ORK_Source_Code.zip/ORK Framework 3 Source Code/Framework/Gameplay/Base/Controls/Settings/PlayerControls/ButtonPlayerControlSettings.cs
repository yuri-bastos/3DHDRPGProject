﻿
using UnityEngine;
using GamingIsLove.ORKFramework.Animations;
using GamingIsLove.ORKFramework.Components;
using System.Collections.Generic;
using GamingIsLove.Makinom;

namespace GamingIsLove.ORKFramework
{
	public enum ButtonControlMoveType { CharacterController, NavMeshAgent, CombatantMovementComponent, AnimatorRootMotion }

	public class ButtonPlayerControlSettings : BaseData
	{
		[EditorHelp("Move Type", "Select how the player will be moved:\n" +
			"- Character Controller: Moves using a 'CharacterController' component.\n" +
			"- NavMesh Agent: Moves using a 'NavMeshAgent' component.\n" +
			"- Combatant Movement Component: Moves using the 'Movement Component' setup of the combatant.\n" +
			"- Animator Root Motion: Sets parameters of an animator controller for root motion control.", "")]
		public ButtonControlMoveType moveType = ButtonControlMoveType.CharacterController;

		// root motion
		[EditorHelp("Set Controller Gravity", "Use a 'Character Controller' component to add gravity to the combatant.")]
		[EditorCondition("moveType", ButtonControlMoveType.AnimatorRootMotion)]
		public bool rootMotionSetControllerGravity = false;

		[EditorHelp("Forward Speed Parameter", "The name of the float parameter used to set the forward movement speed of the combatant.")]
		[EditorSeparator]
		[EditorWidth(true)]
		public string forwardSpeedParameter = "speed";

		[EditorIndent]
		[EditorCondition("forwardSpeedParameter", "")]
		[EditorElseCondition]
		[EditorEndCondition]
		public MecanimFloatParameterDamping dampForwardSpeedParameter = new MecanimFloatParameterDamping();

		[EditorHelp("Vertical Speed Parameter", "The name of the float parameter used to set the vertical movement speed of the combatant.")]
		[EditorSeparator]
		[EditorWidth(true)]
		public string verticalSpeedParameter = "verticalSpeed";

		[EditorIndent]
		[EditorCondition("verticalSpeedParameter", "")]
		[EditorElseCondition]
		[EditorEndCondition]
		public MecanimFloatParameterDamping dampVerticalSpeedParameter = new MecanimFloatParameterDamping();

		[EditorHelp("Grounded Parameter", "The name of the bool parameter used to set if the combatant is grounded or not.")]
		[EditorSeparator]
		[EditorWidth(true)]
		[EditorEndCondition]
		public string groundedParameter = "grounded";

		// 2-way speed
		[EditorHelp("2-Way Speed", "Use the player combatant's walk speed when the input is below a defined value (e.g. 0.5).\n" +
			"When above the defined value, uses the run speed.\n" +
			"If disabled, scales run speed based on the input value.")]
		[EditorSeparator]
		public bool use2WaySpeed = false;

		[EditorHelp("Input Value", "Define the input value that will be used.\n" +
			"Input below the defined value will use walk speed, otherwise run speed.")]
		[EditorLimit(0.1f, false)]
		[EditorIndent]
		[EditorCondition("use2WaySpeed", true)]
		[EditorEndCondition]
		public float inputValue2WaySpeed = 0.5f;

		// settings
		[EditorHelp("Rotation Speed", "The speed used when rotating the character.", "")]
		[EditorSeparator]
		public float rotateSpeed = 500.0f;

		[EditorHelp("First Person/Strafing", "The axis keys will be used for first person control or strafing, " +
			"i.e. vertical axis will move forward/backward, vertical axis will move sidewards (strafe left/right).\n" +
			"For 3rd person view, also enable 'Use Camera Direction' to allow turning via the camera direction.", "")]
		[EditorSeparator]
		public bool firstPerson = false;

		[EditorHelp("Use Camera Direction", "The axis keys will move the player based on the camera view.\n" +
			"If disabled, the vertical axis key moves the player forward/backward, the horizontal axis key turns the player.", "")]
		public bool useCamDirection = true;

		[EditorHelp("Camera Direction Offset", "Define the angle in degrees that will be added to the camera direction.\n" +
			"E.g. use 45 to shift the movement 45 degrees to the camera view.", "")]
		[EditorCondition("useCamDirection", true)]
		[EditorEndCondition]
		public float camDirectionOffset = 0;

		[EditorHelp("Vertical Axis", "The key used for vertical control.", "")]
		[EditorSeparator]
		public AssetSelection<InputKeyAsset> verticalAxis = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Horizontal Axis", "The key used for horizontal control.", "")]
		public AssetSelection<InputKeyAsset> horizontalAxis = new AssetSelection<InputKeyAsset>();

		// fall/land
		[EditorHelp("Play Fall Animation", "Play the 'Fall' animation when falling.", "")]
		[EditorSeparator]
		public bool playFallAnimation = false;

		[EditorHelp("Play Land Animation", "Play the 'Land' animation after falling.", "")]
		public bool playLandAnimation = false;

		[EditorHelp("Min Fall Time (s)", "The minimum time in seconds to fall in order to play the 'Land' animation.", "")]
		[EditorLimit(0.0f, false)]
		[EditorCondition("playLandAnimation", true)]
		[EditorEndCondition]
		public float minFallTime = 0.1f;


		// jump
		[EditorHelp("Use Jump", "The player can jump.", "")]
		[EditorFoldout("Jump Settings", "Optionally allow the player to jump.", "")]
		public bool useJump = false;

		[EditorHelp("Jump Key", "The key used to jump.", "")]
		[EditorCondition("useJump", true)]
		public AssetSelection<InputKeyAsset> jumpKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Jump Speed", "The vertical speed in world units used when jumping.\n" +
			"Use positive numbers.", "")]
		[EditorLimit(0, false)]
		public float jumpSpeed = 10;

		[EditorHelp("Jump Deceleration", "The speed at which jumping decelerates when not holding the jump button.\n" +
			"Use positive numbers.", "")]
		[EditorLimit(0, false)]
		public float jumpDeceleration = 10;

		[EditorHelp("Jump Gravity", "The gravity used while jumping.\n" +
			"Use positive numbers.", "")]
		[EditorLimit(0, false)]
		public float jumpGravity = 20;

		[EditorHelp("In Air Modifier", "This setting effects the move speed while in the air.\n" +
			"A value below 1 will decrease the speed, above will increase.", "")]
		public float inAirModifier = 0.5f;

		[EditorHelp("Maximum Ground Angle", "The maximum angle of the ground to allow jumping.\n" +
			"Use this setting to prevent jumping from steep slopes.", "")]
		[EditorEndFoldout]
		[EditorEndCondition]
		public float jumpMaxGroundAngle = 45;


		// sprint
		[EditorHelp("Use Sprint", "The player can sprint.", "")]
		[EditorFoldout("Sprint Settings", "Optionally allow the player to sprint.", "")]
		public bool useSprint = false;

		[EditorHelp("Sprint Key", "The key used to sprint.\n" +
			"The key must be held down to sprint - select handling type Hold in the settings of the key.", "")]
		[EditorCondition("useSprint", true)]
		public AssetSelection<InputKeyAsset> sprintKey = new AssetSelection<InputKeyAsset>();

		[EditorHelp("Sprint Factor", "The players move speed will be multiplied with this number when sprinting.\n" +
			"E.g. 2 will double the move speed.", "")]
		public float sprintFactor = 2.0f;

		[EditorHelp("Use Energy", "Sprinting will consume energy.", "")]
		public bool useEnergy = false;

		[EditorHelp("Energy Consume", "The energy consumed per second when sprinting.")]
		[EditorCondition("useEnergy", true)]
		public FloatValue<GameObjectSelection> energyConsume = new FloatValue<GameObjectSelection>();

		[EditorHelp("Use Status Value", "Use a 'Consumable' type status value as energy.")]
		public bool energyUseStatusValue = false;

		[EditorHelp("Status Value (Consumable)", "Select the 'Consumable' type status value that will be used.")]
		[EditorCondition("energyUseStatusValue", true)]
		[EditorAutoInit]
		[EditorAssetSelectionCondition("type", StatusValueType.Consumable, true)]
		public AssetSelection<StatusValueAsset> energyStatusValue;

		[EditorHelp("Maximum Energy", "The maximum sprint energy.")]
		[EditorElseCondition]
		public FloatValue<GameObjectSelection> maxEnergy = new FloatValue<GameObjectSelection>();

		[EditorHelp("Energy Regeneration", "The energy regenerated per second.")]
		[EditorEndFoldout]
		[EditorEndCondition(3)]
		public FloatValue<GameObjectSelection> energyRegeneration = new FloatValue<GameObjectSelection>();

		public ButtonPlayerControlSettings()
		{

		}


		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public void AddPlayerControl(GameObject player)
		{
			ButtonPlayerController comp = player.GetComponent<ButtonPlayerController>();
			if(comp == null)
			{
				comp = player.AddComponent<ButtonPlayerController>();
			}
			comp.settings.SetData(this.GetData());

			Maki.Control.AddPlayerControl(comp);
		}

		public void RemovePlayerControl(GameObject player)
		{
			ButtonPlayerController comp = player.GetComponent<ButtonPlayerController>();
			if(comp != null)
			{
				Maki.Control.RemovePlayerControl(comp);
				GameObject.Destroy(comp);
			}
		}
	}
}
