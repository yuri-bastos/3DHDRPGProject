
Makinom 2 Source Code
https://makinom.com


-------------------------------------------------------------------------------------------------------------------------------------------------------
Content
-------------------------------------------------------------------------------------------------------------------------------------------------------

- General information
- API



-------------------------------------------------------------------------------------------------------------------------------------------------------
General Information
-------------------------------------------------------------------------------------------------------------------------------------------------------

The C# source code is provided as a Visual Studio solution (using VS Community 2017) and should be compatible with any similar IDE supporting the SLN format.
The solution contains individual projects for Makinom (gameplay), the editor as well as 2 projects for each UI module (1 gameplay and 1 editor project each).
Currently there's only the Unity UI module available.

The projects are already set up ready for use and contain the needed Unity DLL files and references.
Building the projects will output them to the 'bin' folder, depending on the used configuration (for different Unity versions) it'll be put in the corresponding sub-folder.
E.g. building with 'Unity_2019' configuration (which currently supports Unity 2019, Unity 2020 and Unity 2021) will output to 'bin/Unity_2019'.
The created DLL files need to be copied into your Unity project, replacing the current DLL files in 'Assets/Gaming Is Love/Makinom 2/' and it's sub-folders.

You can find more general information about scripting with Makinom in the documentation:
https://makinom.com/guide/documentation/scripting/scripting-overview/



-------------------------------------------------------------------------------------------------------------------------------------------------------
API
-------------------------------------------------------------------------------------------------------------------------------------------------------

You can find the API here:
https://makinom.com/api/

You'll also find numerous comments all over the source code.
