
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MakinomProjectAsset : ScriptableObject
	{
		[HideInInspector]
		[SerializeField]
		private string time = "";

		[HideInInspector]
		[SerializeField]
		private string version = "";

		[HideInInspector]
		[SerializeField]
		private List<string> keys = new List<string>();

		// kept for compatibility with older versions
		[HideInInspector]
		[SerializeField]
		private List<DataFile> data = new List<DataFile>();

		[HideInInspector]
		[SerializeField]
		private List<MakinomSettingsAsset> settings = new List<MakinomSettingsAsset>();

		public MakinomProjectAsset()
		{

		}

		public string Version
		{
			get { return this.version; }
			set { this.version = value; }
		}

		public string SaveTime
		{
			get { return this.time; }
			set { this.time = value; }
		}

		public bool IsEmpty
		{
			get { return this.keys.Count == 0; }
		}


		/*
		============================================================================
		Data handling functions
		============================================================================
		*/
		public void ClearData()
		{
			this.keys = new List<string>();
			this.data = new List<DataFile>();
			this.settings = new List<MakinomSettingsAsset>();
		}

		public void AddData(string key, MakinomSettingsAsset asset)
		{
			if(this.keys.Contains(key))
			{
				int index = this.keys.IndexOf(key);
				if(index >= 0 &&
					index < this.settings.Count)
				{
					this.settings[index] = asset;
				}
			}
			else
			{
				this.keys.Add(key);
				this.settings.Add(asset);
			}
		}

		public bool Contains(string key)
		{
			return this.keys.Contains(key);
		}

		public DataFile GetData(string key)
		{
			if(this.keys.Contains(key))
			{
				int index = this.keys.IndexOf(key);
				if(index >= 0)
				{
					if(index < this.settings.Count &&
						this.settings[index] != null)
					{
						return this.settings[index].Data;
					}
					else if(index < this.data.Count)
					{
						return this.data[index];
					}
				}
			}
			return new DataFile("", false);
		}
	}
}
