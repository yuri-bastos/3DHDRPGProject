﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Quintic/Quintic In", "Quintic easing in, accelerating from zero velocity.",
		sortIndex=4)]
	public class QuinticInInterpolation : BaseInterpolation
	{
		public QuinticInInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 1.0f : elapsedTime / duration;
			return distance * elapsedTime * elapsedTime * elapsedTime * elapsedTime * elapsedTime + start;
		}
	}

	[EditorSettingInfo("Quintic/Quintic Out", "Quintic easing out, decelerating to zero velocity.",
		sortIndex=4)]
	public class QuinticOutInterpolation : BaseInterpolation
	{
		public QuinticOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 1.0f : elapsedTime / duration;
			elapsedTime--;
			return distance * (elapsedTime * elapsedTime * elapsedTime * elapsedTime * elapsedTime + 1) + start;
		}
	}

	[EditorSettingInfo("Quintic/Quintic In + Out", "Quintic easing in/out, acceleration until halfway, then deceleration.",
		sortIndex=4)]
	public class QuinticInOutInterpolation : BaseInterpolation
	{
		public QuinticInOutInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			elapsedTime = (elapsedTime > duration) ? 2.0f : elapsedTime / (duration / 2);
			if(elapsedTime < 1)
			{
				return distance / 2 * elapsedTime * elapsedTime * elapsedTime * elapsedTime * elapsedTime + start;
			}
			elapsedTime -= 2;
			return distance / 2 * (elapsedTime * elapsedTime * elapsedTime * elapsedTime * elapsedTime + 2) + start;
		}
	}
}
