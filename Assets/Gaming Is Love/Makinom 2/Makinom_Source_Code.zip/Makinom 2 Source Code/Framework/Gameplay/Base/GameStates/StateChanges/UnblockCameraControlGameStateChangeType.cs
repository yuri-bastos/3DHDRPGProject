﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Unblock Camera Control", "When the camera control is unblocked.")]
	public class UnblockCameraControlGameStateChangeType : BaseGameStateChangeType
	{
		public UnblockCameraControlGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Control.UnblockCameraControlCalled += notify;
		}
	}
}
