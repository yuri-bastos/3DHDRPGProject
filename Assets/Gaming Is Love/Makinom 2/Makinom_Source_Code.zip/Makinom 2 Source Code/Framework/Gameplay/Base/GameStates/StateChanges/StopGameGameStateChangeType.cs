﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Stop Game", "When the game is stopped ('Stop Game' node).")]
	public class StopGameGameStateChangeType : BaseGameStateChangeType
	{
		public StopGameGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Game.StopGameCalled += notify;
		}
	}
}
