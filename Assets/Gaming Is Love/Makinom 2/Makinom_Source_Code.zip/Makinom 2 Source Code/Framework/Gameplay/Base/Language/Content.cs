﻿
using UnityEngine;
using GamingIsLove.Makinom.Schematics;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.UI
{
	public class Content : BaseData
	{
		[EditorLanguageExport("MainContent")]
		public LanguageData<TextImageContent> mainContent = new LanguageData<TextImageContent>();

		[EditorArray("Add Additional Content", "Adds an additional content, identified by a content ID.\n" +
			"Additional content is displayed by UI boxes in content components with matching IDs.", "",
			"Remove", "Removes this additional content.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Additional Content", "Additional content is displayed by UI boxes in content components with matching IDs.", ""
			})]
		public ContentID<LanguageData<TextImageContent>>[] additionalContent = new ContentID<LanguageData<TextImageContent>>[0];

		public Content()
		{

		}

		public Content(string text)
		{
			this.mainContent.data = new TextImageContent(text);
		}

		public Content(string contentID, string contentText)
		{
			this.additionalContent = new ContentID<LanguageData<TextImageContent>>[]
			{
				new ContentID<LanguageData<TextImageContent>>(contentID,
					new LanguageData<TextImageContent>(new TextImageContent(contentText)))
			};
		}

		public Content(string text, string contentID, string contentText)
		{
			this.mainContent.data = new TextImageContent(text);

			this.additionalContent = new ContentID<LanguageData<TextImageContent>>[]
			{
				new ContentID<LanguageData<TextImageContent>>(contentID,
					new LanguageData<TextImageContent>(new TextImageContent(contentText)))
			};
		}

		public Content(string[] contentID, string[] contentText)
		{
			this.additionalContent = new ContentID<LanguageData<TextImageContent>>[contentID.Length];
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				this.additionalContent[i] = new ContentID<LanguageData<TextImageContent>>(contentID[i],
					new LanguageData<TextImageContent>(new TextImageContent(i < contentText.Length ? contentText[i] : "")));
			}
		}

		public override string ToString()
		{
			return this.mainContent.Current.text.text;
		}

		public UIContent GetContent()
		{
			return this.GetContent<UIContent>();
		}

		public UIContent GetContent(Schematic schematic, int actorID, VariableHandler handler)
		{
			return this.GetContent<UIContent>(schematic, actorID, handler);
		}

		public T GetContent<T>() where T : UIContent, new()
		{
			T content = new T();
			content.mainContent = this.mainContent.Current;
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				content.AddAdditionalContent(
					this.additionalContent[i].contentID,
					this.additionalContent[i].content.Current);
			}
			return content;
		}

		public T GetContent<T>(Schematic schematic, int actorID, VariableHandler handler) where T : UIContent, new()
		{
			T content = new T();
			content.mainContent = new UIText(this.mainContent.Current, schematic, actorID,
				handler != null ? handler : Maki.Game.Variables);
			for(int i = 0; i < this.additionalContent.Length; i++)
			{
				content.AddAdditionalContent(
					this.additionalContent[i].contentID,
					new UIText(this.additionalContent[i].content.Current, schematic, actorID,
						handler != null ? handler : Maki.Game.Variables));
			}
			return content;
		}
	}
}
