﻿
using UnityEngine;
using GamingIsLove.Makinom.Components;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class RaycastLineOfSightSetting : BaseData
	{
		[EditorHelp("Use Raycast", "Use a raycast to check if any other objects are between user and target.", "")]
		public bool useRaycast = false;

		[EditorHelp("Layer Mask", "The layer mask used for the raycast.", "")]
		[EditorCondition("useRaycast", true)]
		public LayerMask layerMask = -1;


		// user
		[EditorHelp("Use Child (User)", "The position of the defined child of the user's game object will be used for the raycast.\n" +
			"If the child can't be found, the user's game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[EditorSeparator]
		[EditorWidth(true)]
		public string childNameUser = "";

		[EditorHelp("Offset (User)", "The offset added to the user game object's position.", "")]
		public Vector3 userOffset = Vector3.zero;


		// target
		[EditorHelp("Use Child (Target)", "The position of the defined child of the target's game object will be used for the raycast.\n" +
			"If the child can't be found, the target's game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[EditorSeparator]
		[EditorWidth(true)]
		public string childNameTarget = "";

		[EditorHelp("Offset (Target)", "The offset added to the target game object's position.", "")]
		[EditorEndCondition]
		public Vector3 targetOffset = Vector3.zero;

		public RaycastLineOfSightSetting()
		{

		}

		public bool Check(GameObject user, GameObject target)
		{
			if(this.useRaycast)
			{
				if(user == null ||
					target == null)
				{
					return false;
				}

				Vector3 origin = TransformHelper.GetChild(this.childNameUser, user.transform).position + this.userOffset;
				Vector3 destination = TransformHelper.GetChild(this.childNameTarget, target.transform).position + this.targetOffset;

				List<RaycastOutput> hit = RaycastHelper.RaycastAll(origin,
					VectorHelper.GetDirection(origin, destination),
					Vector3.Distance(origin, destination), this.layerMask);

				for(int i = 0; i < hit.Count; i++)
				{
					if(hit[i].transform.root != user.transform.root &&
						hit[i].transform.root != target.transform.root)
					{
						return false;
					}
				}
			}
			return true;
		}
	}
}
