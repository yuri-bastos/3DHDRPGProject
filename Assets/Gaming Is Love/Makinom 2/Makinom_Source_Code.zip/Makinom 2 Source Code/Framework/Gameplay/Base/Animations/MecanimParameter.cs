
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class MecanimParameter : BaseData
	{
		[EditorHelp("Parameter Name", "The name of the parameter.", "")]
		[EditorWidth(true)]
		public string name = "";

		[EditorHelp("Use Hash ID", "Generates a hash ID for the parameter name.\n" +
			"Accessing parameters via hash IDs is faster - disable this setting in case " +
			"you get a warning like 'Parameter Hash 123456789 does not exist.'.", "")]
		public bool useHashID = true;

		[EditorHelp("Parameter Type", "Select the type of the value that will be set.", "")]
		public MecanimParameterType type = MecanimParameterType.Bool;


		// bool
		[EditorHelp("Toggle", "Toggle the current bool value.\n" +
			"If disabled, the bool value will be set to the defined value.", "")]
		[EditorCondition("type", MecanimParameterType.Bool)]
		public bool bToggle = false;

		[EditorHelp("Bool Value", "The bool value that will be set.", "")]
		[EditorCondition("bToggle", false)]
		[EditorEndCondition(2)]
		public bool bVal = false;


		// other values
		[EditorHelp("Add", "Add the value to the current value.", "")]
		[EditorCondition("type", MecanimParameterType.Int)]
		[EditorCondition("type", MecanimParameterType.Float)]
		[EditorEndCondition]
		public bool add = false;

		[EditorHelp("Int Value", "The int value that will be set.", "")]
		[EditorCondition("type", MecanimParameterType.Int)]
		[EditorEndCondition]
		public int iVal = 0;

		[EditorHelp("Float Value", "The float value that will be set.", "")]
		[EditorCondition("type", MecanimParameterType.Float)]
		[EditorEndCondition]
		public float fVal = 0;


		// trigger
		[EditorHelp("Reset Trigger", "Reset the trigger to false.", "")]
		[EditorCondition("type", MecanimParameterType.Trigger)]
		[EditorEndCondition]
		public bool resetTrigger = false;


		// ingame
		private int parameterID = 0;

		public MecanimParameter()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(this.useHashID)
			{
				this.parameterID = Animator.StringToHash(this.name);
			}
		}

		public override string ToString()
		{
			if(MecanimParameterType.Bool == this.type)
			{
				if(this.bToggle)
				{
					return this.name + " Toggle";
				}
				else
				{
					return this.name + " = " + this.bVal;
				}
			}
			// set int
			else if(MecanimParameterType.Int == this.type)
			{
				if(this.add)
				{
					return this.name + " += " + this.iVal;
				}
				else
				{
					return this.name + " = " + this.iVal;
				}
			}
			// set float
			else if(MecanimParameterType.Float == this.type)
			{
				if(this.add)
				{
					return this.name + " += " + this.fVal;
				}
				else
				{
					return this.name + " = " + this.fVal;
				}
			}
			// set trigger
			else if(MecanimParameterType.Trigger == this.type)
			{
				return this.name + (this.resetTrigger ? " reset" : "");
			}
			return "";
		}


		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public void Set(Animator animator)
		{
			if(this.useHashID)
			{
				// set bool
				if(MecanimParameterType.Bool == this.type)
				{
					if(this.bToggle)
					{
						animator.SetBool(this.parameterID, !animator.GetBool(this.parameterID));
					}
					else
					{
						animator.SetBool(this.parameterID, this.bVal);
					}
				}
				// set int
				else if(MecanimParameterType.Int == this.type)
				{
					if(this.add)
					{
						animator.SetInteger(this.parameterID, animator.GetInteger(this.parameterID) + this.iVal);
					}
					else
					{
						animator.SetInteger(this.parameterID, this.iVal);
					}
				}
				// set float
				else if(MecanimParameterType.Float == this.type)
				{
					if(this.add)
					{
						animator.SetFloat(this.parameterID, animator.GetFloat(this.parameterID) + this.fVal);
					}
					else
					{
						animator.SetFloat(this.parameterID, this.fVal);
					}
				}
				// set trigger
				else if(MecanimParameterType.Trigger == this.type)
				{
					if(this.resetTrigger)
					{
						animator.ResetTrigger(this.parameterID);
					}
					else
					{
						animator.SetTrigger(this.parameterID);
					}
				}
			}
			else
			{
				// set bool
				if(MecanimParameterType.Bool == this.type)
				{
					if(this.bToggle)
					{
						animator.SetBool(this.name, !animator.GetBool(this.parameterID));
					}
					else
					{
						animator.SetBool(this.name, this.bVal);
					}
				}
				// set int
				else if(MecanimParameterType.Int == this.type)
				{
					if(this.add)
					{
						animator.SetInteger(this.name, animator.GetInteger(this.parameterID) + this.iVal);
					}
					else
					{
						animator.SetInteger(this.name, this.iVal);
					}
				}
				// set float
				else if(MecanimParameterType.Float == this.type)
				{
					if(this.add)
					{
						animator.SetFloat(this.name, animator.GetFloat(this.parameterID) + this.fVal);
					}
					else
					{
						animator.SetFloat(this.name, this.fVal);
					}
				}
				// set trigger
				else if(MecanimParameterType.Trigger == this.type)
				{
					if(this.resetTrigger)
					{
						animator.ResetTrigger(this.name);
					}
					else
					{
						animator.SetTrigger(this.name);
					}
				}
			}
		}
	}
}
