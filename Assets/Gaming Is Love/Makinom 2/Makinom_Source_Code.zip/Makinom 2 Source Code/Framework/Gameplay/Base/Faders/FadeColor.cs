﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public delegate void GetColorFade(ref float time, ref bool reverting);

	public class FadeColor
	{
		protected FadeType fadeType = FadeType.Fade;

		protected bool alpha = true;

		protected bool red = false;

		protected bool green = false;

		protected bool blue = false;


		// interpolate
		protected bool reverting = false;

		protected Interpolation.ColorInstance interpolation;


		// value
		protected Color currentValue = Color.white;

		protected Color initialColor = Color.white;


		// delegates
		protected SetColor setValue;

		protected GetFloat deltaTime;

		protected GetColorFade linkedTime;

		protected bool inPause = false;

		public FadeColor(FadeType fadeType, float time, Color currentValue, Color startValue, Color endValue,
			bool alpha, bool red, bool green, bool blue,
			Interpolation interpolation, SetColor setValue, GetFloat deltaTime, bool inPause)
		{
			this.fadeType = fadeType;
			this.currentValue = currentValue;
			this.initialColor = currentValue;

			if(this.alpha)
			{
				this.currentValue.a = startValue.a;
			}
			if(this.red)
			{
				this.currentValue.r = startValue.r;
			}
			if(this.green)
			{
				this.currentValue.g = startValue.g;
			}
			if(this.blue)
			{
				this.currentValue.b = startValue.b;
			}

			this.alpha = alpha;
			this.red = red;
			this.green = green;
			this.blue = blue;

			this.interpolation = interpolation.CreateColor(startValue, endValue,
				FadeType.Flash == this.fadeType ? time / 2 : time);

			this.setValue = setValue;
			this.deltaTime = deltaTime;
			this.inPause = inPause;

			this.setValue(this.currentValue);
		}

		public FadeColor(FadeType fadeType, float time, Color currentValue, Color startValue, Color endValue,
			bool alpha, bool red, bool green, bool blue,
			Interpolation interpolation, SetColor setValue, GetColorFade linkedTime, bool inPause)
		{
			this.fadeType = fadeType;
			this.currentValue = currentValue;
			this.initialColor = currentValue;

			if(this.alpha)
			{
				this.currentValue.a = startValue.a;
			}
			if(this.red)
			{
				this.currentValue.r = startValue.r;
			}
			if(this.green)
			{
				this.currentValue.g = startValue.g;
			}
			if(this.blue)
			{
				this.currentValue.b = startValue.b;
			}

			this.alpha = alpha;
			this.red = red;
			this.green = green;
			this.blue = blue;

			this.interpolation = interpolation.CreateColor(startValue, endValue,
				FadeType.Flash == this.fadeType ? time / 2 : time);

			this.setValue = setValue;
			this.linkedTime = linkedTime;
			this.inPause = inPause;

			this.setValue(this.currentValue);
		}

		public virtual bool InPause
		{
			get { return this.inPause; }
			set { this.inPause = value; }
		}


		/*
		============================================================================
		Fade functions
		============================================================================
		*/
		public virtual void Reset()
		{
			this.setValue(this.initialColor);
		}

		public virtual bool Tick()
		{
			return this.Tick(this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime());
		}

		public virtual bool Tick(float deltaTime)
		{
			if(this.interpolation.Duration > 0)
			{
				if(this.linkedTime != null)
				{
					float tmp = 0;
					bool tmpReverting = false;
					this.linkedTime(ref tmp, ref tmpReverting);
					if(this.reverting != tmpReverting)
					{
						this.reverting = tmpReverting;
						this.interpolation.Revert();
					}
					this.interpolation.ElapsedTime = tmp;
					deltaTime = 0;
				}
				this.interpolation.Tick(ref this.currentValue, deltaTime,
					this.red, this.green, this.blue, this.alpha);
			}
			else
			{
				if(this.alpha)
				{
					this.currentValue.a = this.interpolation.Target.a;
				}
				if(this.red)
				{
					this.currentValue.r = this.interpolation.Target.r;
				}
				if(this.green)
				{
					this.currentValue.g = this.interpolation.Target.g;
				}
				if(this.blue)
				{
					this.currentValue.b = this.interpolation.Target.b;
				}
			}

			this.setValue(this.currentValue);

			if(this.interpolation.Finished)
			{
				if(FadeType.Fade == this.fadeType)
				{
					return true;
				}
				else if(FadeType.Blink == this.fadeType)
				{
					if(this.linkedTime == null)
					{
						this.reverting = !this.reverting;
						this.interpolation.ElapsedTime = 0;
						this.interpolation.Revert();
					}
				}
				else if(FadeType.Flash == this.fadeType)
				{
					if(this.reverting)
					{
						return true;
					}
					else if(this.linkedTime == null)
					{
						this.reverting = true;
						this.interpolation.ElapsedTime = 0;
						this.interpolation.Revert();
					}
				}
			}
			return false;
		}
	}
}
