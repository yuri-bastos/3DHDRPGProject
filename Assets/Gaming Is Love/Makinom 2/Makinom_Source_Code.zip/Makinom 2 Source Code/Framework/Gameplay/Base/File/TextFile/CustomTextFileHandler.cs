﻿
using UnityEngine;
using GamingIsLove.Makinom.IO;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Custom", "Uses a custom file saving using static functions to save, load and delete the file.")]
	public class CustomTextFileHandler : BaseTextFileHandler
	{
		[EditorHelp("Class Name", "The name of the class that contains the static functions.", "")]
		[EditorWidth(true)]
		public string className = "";

		[EditorHelp("Save Function Name", "The name of the static save function that will be called.\n" +
			"The function must have an int parameter for the file index and a string parameter for the save data, e.g.:\n" +
			"public static void Save(string fileName, string data)", "")]
		[EditorWidth(true)]
		public string saveFunctionName = "";

		[EditorHelp("Load Function Name", "The name of the static load function that will be called.\n" +
			"The function must have an int parameter for the file index and return a string containing the save data, e.g.:\n" +
			"public static string Load(string fileName)", "")]
		[EditorWidth(true)]
		public string loadFunctionName = "";

		[EditorHelp("Exists Function Name", "The name of the static exists function that will be called.\n" +
			"The function must have an int parameter for the file index and return a bool indicating if the file exists (true) or not (false), e.g.:\n" +
			"public static bool Exists(string fileName)", "")]
		[EditorWidth(true)]
		public string existsFunctionName = "";

		[EditorHelp("Delete Function Name", "The name of the static delete function that will be called.\n" +
			"The function must have an int parameter for the file index, e.g.:\n" +
			"public static void Delete(string fileName)", "")]
		[EditorWidth(true)]
		public string deleteFunctionName = "";


		// in-game
		private MethodInfo customSave;

		private MethodInfo customLoad;

		private MethodInfo customExists;

		private MethodInfo customDelete;

		public CustomTextFileHandler()
		{

		}

		public override string ToString()
		{
			return "Custom";
		}

		private void LoadCustomFunctions()
		{
			Type type = Maki.ReflectionHandler.GetType(this.className);
			if(type != null)
			{
				object instance = null;
				Type instanceType = type;

				this.customSave = Maki.ReflectionHandler.GetMethod(
					this.saveFunctionName,
					new Type[] { typeof(string), typeof(string) },
					ref instance, ref instanceType);

				instanceType = type;
				this.customLoad = Maki.ReflectionHandler.GetMethod(
					this.loadFunctionName,
					new Type[] { typeof(string) },
					ref instance, ref instanceType);

				instanceType = type;
				this.customDelete = Maki.ReflectionHandler.GetMethod(
					this.deleteFunctionName,
					new Type[] { typeof(string) },
					ref instance, ref instanceType);

				instanceType = type;
				this.customExists = Maki.ReflectionHandler.GetMethod(
					this.existsFunctionName,
					new Type[] { typeof(string) },
					ref instance, ref instanceType);
			}
		}

		public override void SaveFile(string fileName, string data)
		{
			try
			{
				if(this.customSave == null)
				{
					this.LoadCustomFunctions();
				}
				if(this.customSave != null)
				{
					this.customSave.Invoke(null, new object[] { fileName, data });
				}
			}
			catch(Exception ex)
			{
				Debug.LogWarning("Error occured calling custom save function: " + ex.Message);
			}
		}

		public override string LoadFile(string fileName)
		{
			try
			{
				if(this.customLoad == null)
				{
					this.LoadCustomFunctions();
				}
				if(this.customLoad != null)
				{
					object tmp = this.customLoad.Invoke(null, new object[] { fileName });
					if(tmp is string)
					{
						return (string)tmp;
					}
				}
			}
			catch(Exception ex)
			{
				Debug.LogWarning("Error occured while calling custom load function: " + ex.Message);
			}
			return "";
		}

		public override void DeleteFile(string fileName)
		{
			try
			{
				if(this.customDelete == null)
				{
					this.LoadCustomFunctions();
				}
				if(this.customDelete != null)
				{
					this.customDelete.Invoke(null, new object[] { fileName });
				}
			}
			catch(Exception ex)
			{
				Debug.LogWarning("Error occured while calling custom delete function: " + ex.Message);
			}
		}

		public override bool FileExists(string fileName)
		{
			try
			{
				if(this.customExists == null)
				{
					this.LoadCustomFunctions();
				}
				if(this.customExists != null)
				{
					object tmp = this.customExists.Invoke(null, new object[] { fileName });
					if(tmp is bool)
					{
						return (bool)tmp;
					}
				}
			}
			catch(Exception ex)
			{
				Debug.LogWarning("Error occured while calling custom file exists function: " + ex.Message);
			}
			return false;
		}
	}
}
