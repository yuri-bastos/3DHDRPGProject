﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Input Key", "Other input keys are used.")]
	public class InputKeyInputIDKeySetting : BaseInputIDKeySetting
	{
		// input key
		[EditorHelp("Needed", "Either all or only one input key must receive input to trigger this input key.", "")]
		public Needed needed = Needed.One;

		[EditorHelp("Input Key", "Select the input key that will be used as input for this input key.", "")]
		[EditorSeparator]
		[EditorArray("Add Input Key", "Adds an input key that will be used as input.", "",
			"Remove", "Removes this input key.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Input Key", "Define the used input key.", ""
		})]
		public NegateInputKey[] input = new NegateInputKey[0];

		public InputKeyInputIDKeySetting()
		{

		}

		public override bool IsCollection
		{
			get { return true; }
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override void TickCollection(InputIDKey idKey, int inputKeyID)
		{
			idKey.InputReceived = false;
			idKey.SetUpdateAxisUnmanipulated(0);

			int count = 0;
			for(int i = 0; i < this.input.Length; i++)
			{
				if(this.input[i].CheckInput(idKey.inputID))
				{
					if(Needed.One == this.needed)
					{
						idKey.InputReceived = true;
						return;
					}
					count++;
				}
				else if(Needed.All == this.needed)
				{
					break;
				}
			}
			if(Needed.All == this.needed &&
				count == this.input.Length)
			{
				idKey.InputReceived = true;
				return;
			}

			// HUD or code
			if(idKey.HUDAxis != 0 ||
				idKey.CodeAxis != 0 ||
				idKey.SchematicAxis != 0)
			{
				idKey.InputReceived = true;
			}
		}

		public override float GetAxis(InputIDKey inputKey, int inputKeyID)
		{
			if(inputKey.InputReceived)
			{
				for(int i = 0; i < this.input.Length; i++)
				{
					float tmpAxis = this.input[i].GetAxis(inputKey.inputID);
					if(tmpAxis != 0)
					{
						return inputKey.ManipulateAxisValue(tmpAxis);
					}
				}
			}
			return inputKey.UpdateAxis;
		}
	}
}
