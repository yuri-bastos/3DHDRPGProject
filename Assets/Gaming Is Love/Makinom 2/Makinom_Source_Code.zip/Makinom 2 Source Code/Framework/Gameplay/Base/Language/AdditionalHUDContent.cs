﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.UI
{
	public class AdditionalHUDContent : BaseData
	{
		[EditorHelp("Content HUD", "HUD added to the additional content.")]
		public AssetSelection<HUDAsset> hud = new AssetSelection<HUDAsset>();

		public AdditionalHUDContent()
		{

		}
	}
}
