﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Circle 2D", "Casts a circle into the scene (uses 'Collider2D').")]
	public class Circle2DShapecastType<T> : BaseShapecastType<T> where T : IObjectSelection, new()
	{
		[EditorTitleLabel("Origin")]
		[EditorLabel("The point in 2D space where the shape originates.\n" +
			"Ignores the Z-axis.")]
		public Vector3Value<T> origin = new Vector3Value<T>();

		[EditorHelp("Radius", "The radius of the shape.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Radius")]
		public FloatValue<T> radius = new FloatValue<T>();


		// depth
		[EditorHelp("Minimum Depth", "Only include objects with a Z coordinate (depth) greater than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Minimum Depth")]
		public FloatValue<T> minDepth = new FloatValue<T>(typeof(FloatValue_NegativeInfinityType<T>));

		[EditorHelp("Maximum Depth", "Only include objects with a Z coordinate (depth) less than this value.", "")]
		[EditorSeparator]
		[EditorTitleLabel("Maximum Depth")]
		public FloatValue<T> maxDepth = new FloatValue<T>(typeof(FloatValue_InfinityType<T>));

		public Circle2DShapecastType()
		{

		}

		public override string ToString()
		{
			return "Circle 2D";
		}

		public override bool CastSingle(out RaycastOutput hit, IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords)
		{
			RaycastHit2D tmpHit = Physics2D.CircleCast(
				this.origin.GetValue(call), this.radius.GetValue(call),
				direction, maxDistance, layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call));

			if(tmpHit.collider != null)
			{
				hit = new RaycastOutput(tmpHit);
				return true;
			}
			else
			{
				hit = null;
				return false;
			}
		}

		public override RaycastOutput[] CastAll(IDataCall call, Vector3 direction, float maxDistance, int layerMask, bool storeCoords)
		{
			RaycastHit2D[] tmpHit = Physics2D.CircleCastAll(
				this.origin.GetValue(call), this.radius.GetValue(call),
				direction, maxDistance, layerMask,
				this.minDepth.GetValue(call), this.maxDepth.GetValue(call));

			if(tmpHit != null)
			{
				RaycastOutput[] hit = new RaycastOutput[tmpHit.Length];
				for(int i = 0; i < tmpHit.Length; i++)
				{
					hit[i] = new RaycastOutput(tmpHit[i]);
				}
				return hit;
			}
			return null;
		}
	}
}
