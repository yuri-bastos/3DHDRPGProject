﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Key Combo", "A key combo sequence is used.")]
	public class KeyComboInputIDKeySetting : BaseInputIDKeySetting
	{
		// combo key
		[EditorArray("Add Combo Key", "Adds a combo key.", "",
			"Remove", "Removes this combo key.", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Combo Key", "Define the used input key and time until the next combo key has to be pressed.", ""
		})]
		public ComboInputKey[] comboInput = new ComboInputKey[] { new ComboInputKey() };


		// in-game
		private int comboIndex = 0;

		private float comboTimeout = 0;

		public KeyComboInputIDKeySetting()
		{

		}

		public override void Clear()
		{
			this.comboIndex = 0;
			this.comboTimeout = 0;
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			if(this.comboIndex >= 0 &&
				this.comboIndex < this.comboInput.Length)
			{
				// reset if time is up
				if(this.comboIndex > 0 &&
					(this.comboTimeout + this.comboInput[this.comboIndex - 1].timeout < Time.realtimeSinceStartup ||
					this.comboInput[this.comboIndex].OtherButton(inputKey.inputID, inputKeyID)))
				{
					this.comboIndex = 0;
					this.comboTimeout = 0;
				}
				if(this.comboInput[this.comboIndex].GetButton(inputKey.inputID))
				{
					this.comboTimeout = Time.realtimeSinceStartup;
					this.comboIndex++;
				}
			}

			if(this.comboIndex == this.comboInput.Length)
			{
				if(this.comboInput[this.comboIndex - 1].GetButton(inputKey.inputID))
				{
					inputKey.InputReceived = true;
				}
				else
				{
					this.comboIndex = 0;
					this.comboTimeout = 0;
				}
			}
		}
	}
}
