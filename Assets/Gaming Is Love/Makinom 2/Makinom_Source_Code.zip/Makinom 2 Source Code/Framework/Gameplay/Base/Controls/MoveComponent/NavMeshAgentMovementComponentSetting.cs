﻿
using UnityEngine;
using UnityEngine.AI;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Nav Mesh Agent", "Unity's built in NavMesh is used.")]
	public class NavMeshAgentMovementComponentSetting : BaseMovementComponentSetting
	{
		[EditorHelp("Add Component", "A 'Nav Mesh Agent' component will be added to the game object, if it isn't added already.\n" +
			"If disabled, the component must already be attached to the game object.", "")]
		public bool compAdd = false;

		[EditorHelp("Sample Distance", "Define the distance in which the nearest position on the NavMesh will be searched.", "")]
		public float sampleDistance = 5;

		[EditorHelp("Area Mask", "A mask specifying which NavMesh areas are allowed when finding the nearest point.\n" +
			"Defaults to all areas (-1).", "")]
		public int sampleAreaMask = NavMesh.AllAreas;

		[EditorHelp("Stop Immediately", "Stops the agent immediately when stop is called.\n" +
			"Sets the agent's velocity to 0.")]
		public bool stopImmediately = false;

		public NavMeshAgentMovementComponentSetting()
		{

		}

		public override IMovementComponent Init(GameObject gameObject)
		{
			return new MoveComponent(gameObject, this);
		}

		public class MoveComponent : IMovementComponent
		{
			private NavMeshAgentMovementComponentSetting setting;

			private NavMeshAgent navMeshAgent;

			public MoveComponent(GameObject gameObject, NavMeshAgentMovementComponentSetting setting)
			{
				this.setting = setting;

				this.navMeshAgent = gameObject.GetComponentInChildren<NavMeshAgent>();
				if(this.navMeshAgent == null)
				{
					this.navMeshAgent = gameObject.GetComponentInParent<NavMeshAgent>();
				}
				if(this.navMeshAgent == null &&
					this.setting.compAdd)
				{
					this.navMeshAgent = gameObject.AddComponent<NavMeshAgent>();
				}

				if(this.navMeshAgent != null)
				{
					if(!this.navMeshAgent.isOnNavMesh)
					{
						this.navMeshAgent.enabled = false;
						this.navMeshAgent.enabled = true;
					}
				}
			}

			public virtual void Move(Vector3 change)
			{
				if(this.navMeshAgent != null &&
					this.navMeshAgent.isOnNavMesh)
				{
					this.navMeshAgent.Move(change);
				}
			}

			public virtual bool MoveTo(ref Vector3 position, float speed)
			{
				if(this.navMeshAgent != null &&
					this.navMeshAgent.isOnNavMesh)
				{
					// get nearest NavMesh position
					NavMeshHit hit;
					if(NavMesh.SamplePosition(position, out hit,
						this.setting.sampleDistance,
						this.setting.sampleAreaMask))
					{
						position = hit.position;
					}
					this.navMeshAgent.speed = speed;

					NavMeshPath path = new NavMeshPath();
					this.navMeshAgent.CalculatePath(position, path);
					this.navMeshAgent.path = path;
					position = this.navMeshAgent.pathEndPosition;

					//this.navMeshAgent.SetDestination(position);
					this.navMeshAgent.isStopped = false;
					return true;
				}
				return false;
			}

			public virtual void SetPosition(Vector3 position)
			{
				if(this.navMeshAgent != null &&
					this.navMeshAgent.isOnNavMesh)
				{
					this.navMeshAgent.Warp(position);
				}
			}

			public virtual void Stop()
			{
				if(this.navMeshAgent != null &&
					this.navMeshAgent.isOnNavMesh)
				{
					if(this.setting.stopImmediately)
					{
						this.navMeshAgent.velocity = Vector3.zero;
					}
					this.navMeshAgent.isStopped = true;
				}
			}
		}
	}
}
