﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class TextFileSettings : BaseData
	{
		[EditorHelp("File Type", "Select how the file is stored:", "")]
		[EditorInfo(settingBaseType=typeof(BaseTextFileHandler), settingAutoSetup="fileSettings")]
		public string type = typeof(PersistentDataPathTextFileHandler).ToString();

		public BaseTextFileHandler fileSettings = new PersistentDataPathTextFileHandler();

		public TextFileSettings()
		{

		}

		public override void EditorAutoSetup(string fieldName)
		{
			if("fileSettings" == fieldName)
			{
				if(!this.fileSettings.IsType(this.type))
				{
					DataObject data = this.fileSettings.GetData();
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						this.type, typeof(BaseTextFileHandler));
					if(tmpSettings is BaseTextFileHandler)
					{
						this.fileSettings = (BaseTextFileHandler)tmpSettings;
						this.fileSettings.SetData(data);
					}
					else
					{
						this.fileSettings = new PersistentDataPathTextFileHandler();
						this.fileSettings.SetData(data);
						this.type = this.fileSettings.GetType().ToString();
					}
				}
			}
		}

		public override string ToString()
		{
			return this.fileSettings.ToString();
		}
	}
}
