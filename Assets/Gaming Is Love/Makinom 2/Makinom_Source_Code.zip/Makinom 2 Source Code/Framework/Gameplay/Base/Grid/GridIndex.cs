﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GridIndex<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Grid Key", "The key used to store the grid.\n" +
			"You can store multiple grids by using different keys.", "")]
		public StringValue<T> gridKey = new StringValue<T>();

		[EditorHelp("Grid Cells", "Select which cells of the grid that will be used:\n" +
			"- Whole Grid: The whole grid.\n" +
			"- Single Index: A single index/cell of the grid.\n" +
			"- Limited Area: A defined area of the grid.\n" +
			"- Excluded Area: The whole grid exlcuding a defined area.", "")]
		public GridIndexType indexType = GridIndexType.WholeGrid;


		// single index
		[EditorSeparator]
		[EditorTitleLabel("Cell Index")]
		[EditorLabel("The index in the grid, each axis (X, Y, Z) defines an index of the equivalent grid axis.\n" +
			"The indexes starts at 0, use -1 to use the maximum index. The values will be converted to integer numbers.")]
		[EditorCondition("indexType", GridIndexType.SingleIndex)]
		[EditorAutoInit]
		public Vector3Value<T> index;


		// areas
		[EditorHelp("Cell Sequence", "Select the sequence the grid's indexes will be used.", "")]
		[EditorElseCondition]
		[EditorEndCondition]
		public AxisSortType sequence = AxisSortType.XYZ;

		[EditorSeparator]
		[EditorTitleLabel("From Cell Index")]
		[EditorLabel("The start index of the area, each axis (X, Y, Z) defines an index of the equivalent grid axis.\n" +
			"The indexes starts at 0, use -1 to use the maximum index. The values will be converted to integer numbers.")]
		[EditorCondition("indexType", GridIndexType.LimitedArea)]
		[EditorCondition("indexType", GridIndexType.ExcludedArea)]
		[EditorAutoInit]
		public Vector3Value<T> from;

		[EditorSeparator]
		[EditorTitleLabel("To Cell Index")]
		[EditorLabel("The end index of the area, each axis (X, Y, Z) defines an index of the equivalent grid axis.\n" +
			"The indexes starts at 0, use -1 to use the maximum index. The values will be converted to integer numbers.")]
		[EditorEndCondition]
		[EditorAutoInit]
		public Vector3Value<T> to;

		public GridIndex()
		{

		}

		public override bool Equals(object obj)
		{
			GridIndex<T> check = obj as GridIndex<T>;
			if(check != null &&
				this.gridKey == check.gridKey &&
				this.indexType == check.indexType)
			{
				if(GridIndexType.SingleIndex == this.indexType)
				{
					return true;
				}
				else
				{
					return this.sequence == check.sequence;
				}
			}
			return false;
		}

		public GameObjectGrid GetGrid(IDataCall call)
		{
			return Maki.Game.GetGrid(this.gridKey.GetValue(call));
		}


		/*
		============================================================================
		Single cell functions
		============================================================================
		*/
		public GridCell GetFirstCell(GameObjectGrid grid, IDataCall call)
		{
			if(grid != null)
			{
				if(GridIndexType.SingleIndex == this.indexType)
				{
					Vector3 tmpIndex = this.index.GetValue(call);
					return grid.Get((int)tmpIndex.x, (int)tmpIndex.y, (int)tmpIndex.z);
				}
				else
				{
					int[] tierStart = new int[3];
					int[] tierEnd = new int[3];

					int xStart = 0;
					int yStart = 0;
					int zStart = 0;
					int xEnd = -1;
					int yEnd = -1;
					int zEnd = -1;

					if(GridIndexType.WholeGrid != this.indexType)
					{
						Vector3 tmpFrom = this.from.GetValue(call);
						Vector3 tmpTo = this.to.GetValue(call);

						xStart = (int)tmpFrom.x;
						yStart = (int)tmpFrom.y;
						zStart = (int)tmpFrom.z;

						xEnd = (int)tmpTo.x;
						yEnd = (int)tmpTo.y;
						zEnd = (int)tmpTo.z;
					}

					grid.GetIndexes(ref xStart, ref yStart, ref zStart);
					grid.GetIndexes(ref xEnd, ref yEnd, ref zEnd);

					CheckGridIndex checkIndex = null;

					if(GridIndexType.ExcludedArea == this.indexType)
					{
						GridHelper.GetSequence(this.sequence, ref tierStart, ref tierEnd,
							0, grid.LengthX, 0, grid.LengthY, 0, grid.LengthZ);

						if(xStart > xEnd)
						{
							int tmp = xStart;
							xStart = xEnd;
							xEnd = tmp;
						}
						if(yStart > yEnd)
						{
							int tmp = yStart;
							yStart = yEnd;
							yEnd = tmp;
						}
						if(zStart > zEnd)
						{
							int tmp = zStart;
							zStart = zEnd;
							zEnd = tmp;
						}

						checkIndex = delegate (int x, int y, int z)
						{
							return x < xStart || x > xEnd ||
								y < yStart || y > yEnd ||
								z < zStart || z > zEnd;
						};
					}
					else
					{
						GridHelper.GetSequence(this.sequence, ref tierStart, ref tierEnd,
							xStart, xEnd, yStart, yEnd, zStart, zEnd);

						checkIndex = delegate (int x, int y, int z)
						{
							return true;
						};
					}

					return GridHelper.GetFirstCell(this.sequence, grid, checkIndex, tierStart, tierEnd);
				}
			}
			return null;
		}


		/*
		============================================================================
		Single cell object functions
		============================================================================
		*/
		public GameObject GetFirstCellObject(IDataCall call)
		{
			return this.GetFirstCellObject(Maki.Game.GetGrid(this.gridKey.GetValue(call)), call);
		}

		public GameObject GetFirstCellObject(GameObjectGrid grid, IDataCall call)
		{
			if(grid != null)
			{
				if(GridIndexType.SingleIndex == this.indexType)
				{
					Vector3 tmpIndex = this.index.GetValue(call);
					GridCell cell = grid.Get((int)tmpIndex.x, (int)tmpIndex.y, (int)tmpIndex.z);
					if(cell != null && cell.GameObject != null)
					{
						return cell.GameObject;
					}
				}
				else
				{
					int[] tierStart = new int[3];
					int[] tierEnd = new int[3];

					int xStart = 0;
					int yStart = 0;
					int zStart = 0;
					int xEnd = -1;
					int yEnd = -1;
					int zEnd = -1;

					if(GridIndexType.WholeGrid != this.indexType)
					{
						Vector3 tmpFrom = this.from.GetValue(call);
						Vector3 tmpTo = this.to.GetValue(call);

						xStart = (int)tmpFrom.x;
						yStart = (int)tmpFrom.y;
						zStart = (int)tmpFrom.z;

						xEnd = (int)tmpTo.x;
						yEnd = (int)tmpTo.y;
						zEnd = (int)tmpTo.z;
					}

					grid.GetIndexes(ref xStart, ref yStart, ref zStart);
					grid.GetIndexes(ref xEnd, ref yEnd, ref zEnd);

					CheckGridIndex checkIndex = null;

					if(GridIndexType.ExcludedArea == this.indexType)
					{
						GridHelper.GetSequence(this.sequence, ref tierStart, ref tierEnd,
							0, grid.LengthX, 0, grid.LengthY, 0, grid.LengthZ);

						if(xStart > xEnd)
						{
							int tmp = xStart;
							xStart = xEnd;
							xEnd = tmp;
						}
						if(yStart > yEnd)
						{
							int tmp = yStart;
							yStart = yEnd;
							yEnd = tmp;
						}
						if(zStart > zEnd)
						{
							int tmp = zStart;
							zStart = zEnd;
							zEnd = tmp;
						}

						checkIndex = delegate (int x, int y, int z)
						{
							return x < xStart || x > xEnd ||
								y < yStart || y > yEnd ||
								z < zStart || z > zEnd;
						};
					}
					else
					{
						GridHelper.GetSequence(this.sequence, ref tierStart, ref tierEnd,
							xStart, xEnd, yStart, yEnd, zStart, zEnd);

						checkIndex = delegate (int x, int y, int z)
						{
							return true;
						};
					}

					return GridHelper.GetFirstCellObject(this.sequence, grid, checkIndex, tierStart, tierEnd);
				}
			}
			return null;
		}


		/*
		============================================================================
		Cell list functions
		============================================================================
		*/
		public List<GridCell> GetCells(IDataCall call)
		{
			return this.GetCells(Maki.Game.GetGrid(this.gridKey.GetValue(call)), call);
		}

		public List<GridCell> GetCells(GameObjectGrid grid, IDataCall call)
		{
			List<GridCell> list = new List<GridCell>();

			if(grid != null)
			{
				if(GridIndexType.SingleIndex == this.indexType)
				{
					Vector3 tmpIndex = this.index.GetValue(call);
					GridCell cell = grid.Get((int)tmpIndex.x, (int)tmpIndex.y, (int)tmpIndex.z);
					if(cell != null)
					{
						list.Add(cell);
					}
				}
				else
				{
					int[] tierStart = new int[3];
					int[] tierEnd = new int[3];

					int xStart = 0;
					int yStart = 0;
					int zStart = 0;
					int xEnd = -1;
					int yEnd = -1;
					int zEnd = -1;

					if(GridIndexType.WholeGrid != this.indexType)
					{
						Vector3 tmpFrom = this.from.GetValue(call);
						Vector3 tmpTo = this.to.GetValue(call);

						xStart = (int)tmpFrom.x;
						yStart = (int)tmpFrom.y;
						zStart = (int)tmpFrom.z;

						xEnd = (int)tmpTo.x;
						yEnd = (int)tmpTo.y;
						zEnd = (int)tmpTo.z;
					}

					grid.GetIndexes(ref xStart, ref yStart, ref zStart);
					grid.GetIndexes(ref xEnd, ref yEnd, ref zEnd);

					CheckGridIndex checkIndex = null;

					if(GridIndexType.ExcludedArea == this.indexType)
					{
						GridHelper.GetSequence(this.sequence, ref tierStart, ref tierEnd,
							0, grid.LengthX, 0, grid.LengthY, 0, grid.LengthZ);

						if(xStart > xEnd)
						{
							int tmp = xStart;
							xStart = xEnd;
							xEnd = tmp;
						}
						if(yStart > yEnd)
						{
							int tmp = yStart;
							yStart = yEnd;
							yEnd = tmp;
						}
						if(zStart > zEnd)
						{
							int tmp = zStart;
							zStart = zEnd;
							zEnd = tmp;
						}

						checkIndex = delegate (int x, int y, int z)
						{
							return x < xStart || x > xEnd ||
								y < yStart || y > yEnd ||
								z < zStart || z > zEnd;
						};
					}
					else
					{
						GridHelper.GetSequence(this.sequence, ref tierStart, ref tierEnd,
							xStart, xEnd, yStart, yEnd, zStart, zEnd);

						checkIndex = delegate (int x, int y, int z)
						{
							return true;
						};
					}

					GridHelper.GetCells(this.sequence, grid, ref list, checkIndex, tierStart, tierEnd);
				}
			}

			return list;
		}


		/*
		============================================================================
		Cell object functions
		============================================================================
		*/
		public void GetCellObjects(ref List<GameObject> list, IDataCall call)
		{
			this.GetCellObjects(ref list, Maki.Game.GetGrid(this.gridKey.GetValue(call)), call);
		}

		public void GetCellObjects(ref List<GameObject> list, GameObjectGrid grid, IDataCall call)
		{
			if(grid != null)
			{
				if(GridIndexType.SingleIndex == this.indexType)
				{
					Vector3 tmpIndex = this.index.GetValue(call);
					GridCell cell = grid.Get((int)tmpIndex.x, (int)tmpIndex.y, (int)tmpIndex.z);
					if(cell != null && cell.GameObject != null)
					{
						list.Add(cell.GameObject);
					}
				}
				else
				{
					int[] tierStart = new int[3];
					int[] tierEnd = new int[3];

					int xStart = 0;
					int yStart = 0;
					int zStart = 0;
					int xEnd = -1;
					int yEnd = -1;
					int zEnd = -1;

					if(GridIndexType.WholeGrid != this.indexType)
					{
						Vector3 tmpFrom = this.from.GetValue(call);
						Vector3 tmpTo = this.to.GetValue(call);

						xStart = (int)tmpFrom.x;
						yStart = (int)tmpFrom.y;
						zStart = (int)tmpFrom.z;

						xEnd = (int)tmpTo.x;
						yEnd = (int)tmpTo.y;
						zEnd = (int)tmpTo.z;
					}

					grid.GetIndexes(ref xStart, ref yStart, ref zStart);
					grid.GetIndexes(ref xEnd, ref yEnd, ref zEnd);

					CheckGridIndex checkIndex = null;

					if(GridIndexType.ExcludedArea == this.indexType)
					{
						GridHelper.GetSequence(this.sequence, ref tierStart, ref tierEnd,
							0, grid.LengthX, 0, grid.LengthY, 0, grid.LengthZ);

						if(xStart > xEnd)
						{
							int tmp = xStart;
							xStart = xEnd;
							xEnd = tmp;
						}
						if(yStart > yEnd)
						{
							int tmp = yStart;
							yStart = yEnd;
							yEnd = tmp;
						}
						if(zStart > zEnd)
						{
							int tmp = zStart;
							zStart = zEnd;
							zEnd = tmp;
						}

						checkIndex = delegate (int x, int y, int z)
						{
							return x < xStart || x > xEnd ||
								y < yStart || y > yEnd ||
								z < zStart || z > zEnd;
						};
					}
					else
					{
						GridHelper.GetSequence(this.sequence, ref tierStart, ref tierEnd,
							xStart, xEnd, yStart, yEnd, zStart, zEnd);

						checkIndex = delegate (int x, int y, int z)
						{
							return true;
						};
					}

					GridHelper.GetCellObjects(this.sequence, grid, ref list, checkIndex, tierStart, tierEnd);
				}
			}
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public override string ToString()
		{
			return this.gridKey.ToString() +
				"(" + this.indexType.ToString() + ")";
		}
	}
}
