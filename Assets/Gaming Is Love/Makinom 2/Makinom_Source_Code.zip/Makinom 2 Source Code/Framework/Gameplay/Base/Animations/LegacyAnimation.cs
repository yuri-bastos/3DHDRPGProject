
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class LegacyAnimation : BaseData
	{
		[EditorHelp("Animation Name", "Set the name of the animation clip.", "")]
		[EditorWidth(true)]
		public string name = "";

		[EditorHelp("Set Layer", "Set the layer of the animation.", "")]
		[EditorSeparator]
		public bool setLayer = false;

		[EditorHelp("Animation Layer", "Set the animation layer for this animation clip.", "")]
		[EditorCondition("setLayer", true)]
		[EditorEndCondition]
		public int layer = 0;

		[EditorHelp("Set Speed", "Set the playback speed of the animation based on a formula, e.g.:\n" +
			"- 1 results in the normal playback speed.\n" +
			"- 2 results in double playback speed, i.e. the animations will be twice as fast.\n" +
			"- 0.5 results in halve playback speed, i.e. the animation will be halve as slow.\n" +
			"Everything below 0 results in playing animations backwards.", "")]
		public bool setSpeed = false;

		[EditorHelp("Speed Value", "Define the playback speed.\n" +
			"1 is the normal playback speed, above 1 will play faster, below 1 will play slower.", "")]
		[EditorCondition("setSpeed", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<GameObjectSelection> speedValue;


		// play settings
		[EditorHelp("Play Type", "Select how the animation will be played:\n" +
		 	"- Play: Plays animation without any blending.\n" +
		 	"- Cross Fade: Fades the animation in over a period of time and fades other animations out.\n" +
		 	"- Blend: Blends the animation towards a target weight over time.\n" +
		 	"- Play Queued: Plays an animation after previous animations finished playing.\n" +
		 	"- Cross Fade Queued: Cross fades an animation after previous animations finished playing.\n" +
		 	"- Stop: Stops the animation (or all animations).\n" +
		 	"- Sample: Samples the animation at the current state.", "")]
		[EditorTitleLabel("Play Settings")]
		[EditorSeparator]
		public LegacyAnimationPlayMode playType = LegacyAnimationPlayMode.CrossFade;

		[EditorHelp("Play Mode", "Select how other animations will be handled, either StopSameLayer or StopAll.", "")]
		[EditorCondition("playType", LegacyAnimationPlayMode.Blend)]
		[EditorCondition("playType", LegacyAnimationPlayMode.Stop)]
		[EditorCondition("playType", LegacyAnimationPlayMode.Sample)]
		[EditorElseCondition]
		[EditorEndCondition]
		public PlayMode playMode = PlayMode.StopSameLayer;

		[EditorHelp("Fade Length", "The time in seconds used to fade from the previous animation to the new one.", "")]
		[EditorCondition("playType", LegacyAnimationPlayMode.CrossFade)]
		[EditorCondition("playType", LegacyAnimationPlayMode.CrossFadeQueued)]
		[EditorCondition("playType", LegacyAnimationPlayMode.Blend)]
		[EditorEndCondition]
		[EditorLimit(0.0f, false)]
		public float fade = 0.1f;

		[EditorHelp("Target Weight", "The target weight to blend to.", "")]
		[EditorCondition("playType", LegacyAnimationPlayMode.Blend)]
		[EditorEndCondition]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		public float weight = 1;

		[EditorHelp("Queue Mode", "Select how other animations will be handled, either CompleteOthers or PlayNow.", "")]
		[EditorCondition("playType", LegacyAnimationPlayMode.PlayQueued)]
		[EditorCondition("playType", LegacyAnimationPlayMode.CrossFadeQueued)]
		[EditorEndCondition]
		public QueueMode queueMode = QueueMode.CompleteOthers;

		// stop
		[EditorHelp("Stop All", "Stop all animations.\n" +
			"If disabled, only the defined animation will be stopped.", "")]
		[EditorCondition("playType", LegacyAnimationPlayMode.Stop)]
		[EditorEndCondition]
		public bool stopAll = false;

		public LegacyAnimation()
		{

		}

		public override string ToString()
		{
			if(LegacyAnimationPlayMode.Stop == this.playType)
			{
				return this.playType.ToString() + " " + (this.stopAll ? "All" : this.name);
			}
			else
			{
				return this.playType.ToString() + " " + this.name;
			}
		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public void Init(DataCall call, Animation animation)
		{
			if(this.name != "" && animation[this.name] != null)
			{
				if(this.setLayer)
				{
					animation[this.name].layer = layer;
				}
				if(this.setSpeed)
				{
					animation[this.name].speed = this.speedValue.GetValue(call);
				}
			}
		}

		public AnimInfo Play(Animation animation)
		{
			if(LegacyAnimationPlayMode.Stop == this.playType)
			{
				if(this.stopAll)
				{
					animation.Stop();
				}
				else
				{
					animation.Stop(this.name);
				}
				return new AnimInfo(AnimationSystem.Legacy, this.name, -1);
			}
			else if(animation[this.name] != null)
			{
				if(LegacyAnimationPlayMode.Play == this.playType)
				{
					animation.Play(this.name, this.playMode);
				}
				else if(LegacyAnimationPlayMode.PlayQueued == this.playType)
				{
					animation.PlayQueued(this.name, this.queueMode, this.playMode);
				}
				else if(LegacyAnimationPlayMode.CrossFade == this.playType)
				{
					animation.CrossFade(this.name, this.fade, this.playMode);
				}
				else if(LegacyAnimationPlayMode.CrossFadeQueued == this.playType)
				{
					animation.CrossFadeQueued(this.name, this.fade, this.queueMode, this.playMode);
				}
				else if(LegacyAnimationPlayMode.Blend == this.playType)
				{
					animation.Blend(this.name, this.weight, this.fade);
				}
				else if(LegacyAnimationPlayMode.Sample == this.playType)
				{
					animation.Sample();
				}
				return new AnimInfo(AnimationSystem.Legacy, this.name, AnimationHelper.GetLength(animation, this.name));
			}
			return AnimInfo.None;
		}

		public void Stop(Animation animation)
		{
			if(this.stopAll)
			{
				animation.Stop();
			}
			else
			{
				animation.Stop(this.name);
			}
		}
	}
}
