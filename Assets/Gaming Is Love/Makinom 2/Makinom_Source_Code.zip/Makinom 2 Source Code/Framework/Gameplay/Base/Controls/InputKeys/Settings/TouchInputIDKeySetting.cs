﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Touch", "A touch is used (uses touch position change as axis).")]
	public class TouchInputIDKeySetting : BaseInputIDKeySetting
	{
		// touch
		[EditorHelp("Touch Count", "Define the number of touches that will trigger the input, e.g.:\n" +
			"1 = one finger\n" +
			"2 = two fingers", "")]
		[EditorLimit(1, false)]
		public int touchCount = 1;

		[EditorHelp("Consume Fingers", "Consume the fingers used for the touch input.\n" +
			"The touch won't be available for other touch interactions (e.g. 'Control' type HUDs).", "")]
		public bool consumeFingers = true;

		[EditorHelp("Tab Count", "The amount of tabs used to trigger the input, e.g.:\n" +
			"1 = single tab" +
			"2 = double tab", "")]
		[EditorLimit(1, false)]
		public int tabCount = 1;

		[EditorHelp("Tab Timeout (s)", "The time in seconds to recognize multi-tabs.\n" +
			"If another tab happens within the timeout, it will be recognized " +
			"as a multi-tab (e.g. double tab).", "")]
		public float tabTimeout = 0.2f;

		[EditorHelp("Touch Axis", "Select which axis of the touch position change will be used for the input's axis.", "")]
		public Axis2Type touchAxis = Axis2Type.X;

		[EditorHelp("Min Axis Range", "The minimum touch position change (distance) that " +
			"will trigger the axis.", "")]
		[EditorLimit(1.0f, false)]
		public float touchAxisMinRange = 1;

		[EditorHelp("Max Axis Range", "The maximum touch position change (dinstance) that " +
			"will be used as full axis value (i.e. 1).", "")]
		[EditorLimit(1.0f, false)]
		public float touchAxisMaxRange = 1;


		// input handling
		[EditorHelp("Input Handling", "Select when the input will be recognized:\n" +
			"- Down: When the key is pressed down.\n" +
			"- Hold: While the key is held down.\n" +
			"- Up: When the key is released.\n" +
			"- Any: When the key is pressed down, held down or released.", "")]
		[EditorSeparator]
		public InputHandling handling = InputHandling.Down;

		[EditorHelp("Timeout (s)", "The time in seconds between recognizing two inputs.\n" +
			"Set to 0 to recognize the input every frame.", "")]
		[EditorLimit(0.0f, false)]
		public float inputTimeout = 0;

		[EditorHelp("Hold Time (s)", "The time in seconds the input has to be held to recognizing the input.\n" +
			"Set to 0 to recognize the input immediately.", "")]
		[EditorLimit(0.0f, false)]
		[EditorCondition("handling", InputHandling.Down)]
		[EditorElseCondition]
		[EditorEndCondition]
		[EditorDefaultValue(0.0f)]
		public float inputHoldTime = 0;


		// in-game
		private float releaseTime = 0;

		private int count = 0;

		private List<int> fingerIDs = new List<int>();

		public TouchInputIDKeySetting()
		{

		}

		public override void Clear()
		{
			this.releaseTime = 0;
			this.count = 0;
			this.fingerIDs.Clear();
		}


		/*
		============================================================================
		Input functions
		============================================================================
		*/
		public override float InputTimeout
		{
			get { return this.inputTimeout; }
		}

		public override float InputHoldTime
		{
			get { return this.inputHoldTime; }
		}

		public override InputHandling Handling
		{
			get { return this.handling; }
		}

		public override void TickBlocked(InputIDKey inputKey, int inputKeyID)
		{
			if(this.inputHoldTime > 0)
			{
				if(Maki.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
				{
					inputKey.HoldTimeout = -this.inputHoldTime;
					this.count = 0;
				}
				else if(Maki.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Hold))
				{
					this.releaseTime = Time.time + this.tabTimeout;
				}
			}
		}

		public override void Tick(InputIDKey inputKey, int inputKeyID)
		{
			bool started = false;

			// tab count
			if(Maki.Control.Touch.CanStart(this.touchCount))
			{
				if(this.releaseTime <= Time.time)
				{
					this.count = 0;
				}
				Maki.Control.Touch.GetStarted(this.consumeFingers, ref this.fingerIDs);
				started = true;
				this.count++;
				this.releaseTime = Time.time + this.tabTimeout;
			}

			if(this.tabCount == this.count)
			{
				// set input down time
				if(this.inputHoldTime > 0)
				{
					if(started)
					{
						inputKey.HoldTimeout = Time.realtimeSinceStartup + this.inputHoldTime;
						return;
					}
					else if(Maki.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
					{
						inputKey.HoldTimeout = -this.inputHoldTime;
						this.count = 0;
						if(InputHandling.Hold == this.handling)
						{
							return;
						}
					}
				}

				if((InputHandling.Down == this.handling && started) ||
					Maki.Control.Touch.IsPhase(this.fingerIDs, this.handling))
				{
					inputKey.Timeout = Time.realtimeSinceStartup + this.inputTimeout;
					inputKey.InputReceived = true;

					float tmpAxis = VectorHelper.GetAxis2Value(Maki.Control.Touch.GetDelta(this.fingerIDs), this.touchAxis);
					if(Mathf.Abs(tmpAxis) >= this.touchAxisMinRange)
					{
						tmpAxis /= this.touchAxisMaxRange;
						inputKey.UpdateAxis = tmpAxis;
					}
					else
					{
						inputKey.UpdateAxis = 0;
					}

					if(InputHandling.Up == this.handling)
					{
						this.count = 0;
					}
				}
				else if(Maki.Control.Touch.IsPhase(this.fingerIDs, InputHandling.Up))
				{
					this.count = 0;
				}
			}
		}
	}
}
