﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("Linear", "Simple linear interpolation.",
		sortIndex=0)]
	public class LinearInterpolation : BaseInterpolation
	{
		public LinearInterpolation()
		{

		}

		public override float UpdateFloat(float start, float distance, float elapsedTime, float duration)
		{
			if(elapsedTime > duration)
			{
				elapsedTime = duration;
			}
			return distance * (elapsedTime / duration) + start;
		}
	}
}
