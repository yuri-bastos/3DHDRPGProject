﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class CustomContentInformation : BaseData
	{
		[EditorHelp("Content Key", "Define the content key that identifies this custom content.\n" +
			"Use the content key in text codes to display the custom content.")]
		[EditorWidth(true)]
		public string contentKey = "";

		[EditorHelp("Content", "The content of the custom content.")]
		[EditorSeparator]
		[EditorCallback("textcodes:customcontent", EditorCallbackType.Before)]
		public LanguageData<TextContent> content = new LanguageData<TextContent>();

		public CustomContentInformation()
		{

		}
	}
}
