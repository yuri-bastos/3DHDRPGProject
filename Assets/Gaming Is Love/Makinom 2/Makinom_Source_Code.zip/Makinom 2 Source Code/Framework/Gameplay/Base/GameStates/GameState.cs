
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class GameStateAsset : MakinomGenericAsset<GameState>
	{
		public GameStateAsset()
		{

		}

		public override string DataName
		{
			get { return "Game State"; }
		}
	}

	public class GameState : BaseIndexData
	{
		// base settings
		[EditorHelp("Name", "The name of this game state.", "")]
		[EditorFoldout("Base Settings", "Set the base settings of this game state.", "")]
		[EditorWidth(true)]
		public string name = "";

		[EditorHelp("Initial State", "If enabled, this state will be active when Makinom is initialized.\n" +
			"If disabled, this state will be inactive when Makinom is initialized.\n" +
			"The initial state won't trigger other state changes (active/inactive state changes).", "")]
		public bool initialState = false;

		[EditorHelp("Reset New Game", "Reset to the initial state when starting a new game.")]
		[EditorIndent]
		[EditorEndFoldout]
		public bool resetInitialState = true;

		// auto enable settings
		[EditorFoldout("Auto Activate", "Automatically activates this game state upon defined state change events.", "")]
		[EditorEndFoldout]
		[EditorArray("Add State Change Event", "Adds a state change event that will enable this state.", "",
			"Remove", "Removes this state change event.", "", isHorizontal = true)]
		public GameStateChangeType[] autoActivate = new GameStateChangeType[0];


		// auto disable settings
		[EditorFoldout("Auto Inactivate", "Automatically inactivates this game state upon defined state change events.", "")]
		[EditorEndFoldout]
		[EditorArray("Add State Change Event", "Adds a state change event that will disable this state.", "",
			"Remove", "Removes this state change event.", "", isHorizontal = true)]
		public GameStateChangeType[] autoInactivate = new GameStateChangeType[0];


		// active state changes
		[EditorFoldout("Active State Changes", "This game state will change other game states when it becomes active.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Game State", "Adds a game state that will be changed.", "",
			"Remove", "Removes this game state.", "", removeCheckField = "state",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[]
			{
				"Game State Change", "Define the game state and state change that will be used.", ""
			})]
		public GameStateChange[] activeChange = new GameStateChange[0];


		// inactive state changes
		[EditorFoldout("Inactive State Changes", "This game state will change other game states when it becomes inactive.", "")]
		[EditorEndFoldout]
		[EditorArray("Add Game State", "Adds a game state that will be changed.", "",
			"Remove", "Removes this game state.", "", removeCheckField = "state",
			isCopy = true, isMove = true,
			foldout = true, foldoutText = new string[]
			{
				"Game State Change", "Define the game state and state change that will be used.", ""
			})]
		public GameStateChange[] inactiveChange = new GameStateChange[0];


		// in-game
		private bool isActive = false;

		public GameState()
		{

		}

		public GameState(string name) : base(name)
		{
			this.name = name;
		}

		public GameState(string name, bool initialState,
			GameStateChangeType[] autoActivate, GameStateChangeType[] autoInactivate) : base(name)
		{
			this.name = name;
			this.initialState = initialState;
			this.autoActivate = autoActivate;
			this.autoInactivate = autoInactivate;
		}

		public override string EditorName
		{
			get { return this.name; }
			set { this.name = value; }
		}


		/*
		============================================================================
		State functions
		============================================================================
		*/
		public bool IsActive
		{
			get { return this.isActive; }
			set
			{
				if(this.isActive != value)
				{
					this.isActive = value;

					if(this.isActive)
					{
						for(int i = 0; i < this.activeChange.Length; i++)
						{
							this.activeChange[i].Change();
						}
					}
					else
					{
						for(int i = 0; i < this.inactiveChange.Length; i++)
						{
							this.inactiveChange[i].Change();
						}
					}

					Maki.GameStates.FireChanged();
				}
			}
		}

		public void SetStateNoNotify(bool value)
		{
			if(this.isActive != value)
			{
				this.isActive = value;

				if(this.isActive)
				{
					for(int i = 0; i < this.activeChange.Length; i++)
					{
						this.activeChange[i].Change();
					}
				}
				else
				{
					for(int i = 0; i < this.inactiveChange.Length; i++)
					{
						this.inactiveChange[i].Change();
					}
				}
			}
		}

		public void SetInitialState()
		{
			this.isActive = this.initialState;
		}

		public void ResetInitialState()
		{
			if(this.resetInitialState)
			{
				this.isActive = this.initialState;
			}
		}

		public void RegisterAutoChanges()
		{
			// auto enable
			for(int i = 0; i < this.autoActivate.Length; i++)
			{
				this.autoActivate[i].settings.Register(this.Activate);
			}
			// auto disable
			for(int i = 0; i < this.autoInactivate.Length; i++)
			{
				this.autoInactivate[i].settings.Register(this.Inactivate);
			}
		}

		public void Activate()
		{
			this.IsActive = true;
		}

		public void Inactivate()
		{
			this.IsActive = false;
		}
	}
}
