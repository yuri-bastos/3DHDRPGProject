﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[EditorSettingInfo("End Blocking Machine", "When ending a 'Blocking' execution type machine.")]
	public class EndBlockingMachineGameStateChangeType : BaseGameStateChangeType
	{
		public EndBlockingMachineGameStateChangeType()
		{

		}

		public override void Register(Notify notify)
		{
			Maki.Control.EndBlockingMachineCalled += notify;
		}
	}
}
