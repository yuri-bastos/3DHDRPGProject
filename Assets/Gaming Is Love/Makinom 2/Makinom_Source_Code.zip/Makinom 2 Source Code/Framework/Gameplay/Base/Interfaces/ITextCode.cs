﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface ITextCode
	{
		string GetTextCode(int index);
	}
}
