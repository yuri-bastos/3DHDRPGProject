﻿
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class BaseAudioSettings : BaseData
	{
		// output audio mixer
		[EditorHelp("Set Output Mixer Group", "Set the output audio mixer group of the audio source.", "")]
		[EditorSeparator]
		public bool setOutputMixerGroup = false;

		[EditorHelp("Audio Mixer Group", "Select the audio mixer group that will be used.", "")]
		[EditorCondition("setOutputMixerGroup", true)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<AudioMixerGroup> outputMixerGroup;

		// distance
		[EditorHelp("Set Distance", "Set the min/max distance and rolloff mode of the audio source.", "")]
		[EditorSeparator]
		public bool setDistance = false;

		[EditorHelp("Minimum Distance", "Within the minimum distance the audio source will cease to grow louder in volume.", "")]
		[EditorCondition("setDistance", true)]
		[EditorLimit(0.0f, false)]
		public float minDistance = 0;

		[EditorHelp("Maximum Distance", "(Logarithmic rolloff) Maximum distance is the distance a sound stops attenuating at.", "")]
		[EditorLimit(0.0f, false)]
		public float maxDistance = 100;

		[EditorHelp("Rolloff Mode", "Sets how the audio source attenuates over distance.", "")]
		[EditorEndCondition]
		public AudioRolloffMode rolloff = AudioRolloffMode.Linear;


		// pitch
		[EditorHelp("Set Pitch", "Set the pitch of the audio source.", "")]
		[EditorSeparator]
		public bool setPitch = false;

		[EditorHelp("Random Pitch", "The pitch will be set to a random value between two values.", "")]
		[EditorCondition("setPitch", true)]
		public bool randomPitch = false;

		[EditorHelp("Pitch", "The pitch of the audio source.", "")]
		public float pitch = 1;

		[EditorHelp("Pitch 2", "The pitch of the audio source (upper limit).", "")]
		[EditorLimit("pitch", false)]
		[EditorCondition("randomPitch", true)]
		[EditorEndCondition(2)]
		public float pitch2 = 1;


		// spatial blend
		[EditorHelp("Set Spatial Blend", "Set the spatial blend setting of the audio source.", "")]
		[EditorSeparator]
		public bool setSpatialBlend = false;

		[EditorHelp("Spatial Blend", "Sets how much this audio source is affected by " +
			"3D spatialisation calculations (attenuation, doppler etc).\n" +
			"0.0 makes the sound full 2D, 1.0 makes it full 3D.", "")]
		[EditorCondition("setSpatialBlend", true)]
		[EditorEndCondition]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		public float spatialBlend = 0;


		// pan stereo
		[EditorHelp("Set Pan Stereo", "Set the pan stereo setting of the audio source.", "")]
		[EditorSeparator]
		public bool setPanStereo = false;

		[EditorHelp("Pan Stereo", "Pans a playing sound in a stereo way (left or right).\n" +
			"This only applies to sounds that are Mono or Stereo.\n" +
			"-1.0 = Full left, 0.0 = center, 1.0 = full right.", "")]
		[EditorConditionCallback("setPanStereo")]
		[EditorEndCondition]
		[EditorLimit(-1.0f, 1.0f, isSlider=true)]
		public float panStereo = 0;


		// loop
		[EditorHelp("Set Loop", "Set the loop setting of the audio source.", "")]
		[EditorSeparator]
		public bool setLoop = false;

		[EditorHelp("Loop", "The audio clip will loop.", "")]
		[EditorCondition("setLoop", true)]
		[EditorEndCondition]
		public bool loop = false;


		// ignore listener volume
		[EditorHelp("Set Ignore Listener Volume", "Set the ignore listener volume setting of the audio source.", "")]
		[EditorSeparator]
		public bool setIgnoreLV = false;

		[EditorHelp("Ignore Listener Volume", "This makes the audio source not take into " +
			"account the volume of the audio listener.", "")]
		[EditorCondition("setIgnoreLV", true)]
		[EditorEndCondition]
		public bool ignoreLV = false;

		public BaseAudioSettings()
		{

		}

		public virtual void Change(AudioSource audio)
		{
			if(this.setOutputMixerGroup)
			{
				audio.outputAudioMixerGroup = this.outputMixerGroup.StoredAsset;
			}
			if(this.setPitch)
			{
				audio.pitch = this.randomPitch ? UnityWrapper.Range(this.pitch, this.pitch2) : this.pitch;
			}
			if(this.setDistance)
			{
				audio.rolloffMode = this.rolloff;
				audio.minDistance = this.minDistance;
				audio.maxDistance = this.maxDistance;
			}
			if(this.setSpatialBlend)
			{
				audio.spatialBlend = this.spatialBlend;
			}
			if(this.setPanStereo)
			{
				audio.panStereo = this.panStereo;
			}
			if(this.setLoop)
			{
				audio.loop = this.loop;
			}
			if(this.setIgnoreLV)
			{
				audio.ignoreListenerVolume = this.ignoreLV;
			}
		}
	}
}

