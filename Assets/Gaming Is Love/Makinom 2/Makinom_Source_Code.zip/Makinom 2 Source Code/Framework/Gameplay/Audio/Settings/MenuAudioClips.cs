
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.UI
{
	public class MenuAudioClips : BaseData
	{
		[EditorHelp("Sound Channel", "Define the sound channel that will used.\n" +
			"The default channel is 0.")]
		[EditorLimit(0, false)]
		public int channel = 0;


		// cursor move
		[EditorHelp("Cursor Move", "Played when input keys are used to change the selected input.", "")]
		[EditorTitleLabel("Cursor Move")]
		[EditorSeparator]
		public AssetSource<AudioClip> cursorMoveAudio = new AssetSource<AudioClip>();

		[EditorHelp("Cursor Move Volume", "The volume (0-1) used to play the cursor move clip.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		[EditorCondition("cursorMoveAudio.HasAsset", true)]
		[EditorEndCondition]
		public float cursorMoveVolume = 1.0f;


		// accept
		[EditorHelp("Accept", "Played when something is accepted (e.g. ok button or accepting an input button).", "")]
		[EditorTitleLabel("Accept")]
		[EditorSeparator]
		public AssetSource<AudioClip> acceptAudio = new AssetSource<AudioClip>();

		[EditorHelp("Accept Volume", "The volume (0-1) used to play the accept clip.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		[EditorCondition("acceptAudio.HasAsset", true)]
		[EditorEndCondition]
		public float acceptVolume = 1.0f;


		// cancel
		[EditorHelp("Cancel", "Played when a something is canceled (e.g. cancel button).", "")]
		[EditorTitleLabel("Cancel")]
		[EditorSeparator]
		public AssetSource<AudioClip> cancelAudio = new AssetSource<AudioClip>();

		[EditorHelp("Cancel Volume", "The volume (0-1) used to play the cancel clip.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		[EditorCondition("cancelAudio.HasAsset", true)]
		[EditorEndCondition]
		public float cancelVolume = 1.0f;


		// fail
		[EditorHelp("Fail", "Played when something fails (e.g. accepting an inactive input button).", "")]
		[EditorTitleLabel("Fail")]
		[EditorSeparator]
		public AssetSource<AudioClip> failAudio = new AssetSource<AudioClip>();

		[EditorHelp("Fail Volume", "The volume (0-1) used to play the fail clip.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		[EditorCondition("failAudio.HasAsset", true)]
		[EditorEndCondition]
		public float failVolume = 1.0f;


		// input
		[EditorHelp("Value Input", "Played when the player changes a value input (e.g. typing in a text field, changing a slider).", "")]
		[EditorTitleLabel("Value Input Change")]
		[EditorSeparator]
		public AssetSource<AudioClip> valueInputAudio = new AssetSource<AudioClip>();

		[EditorHelp("Value Input Volume", "The volume (0-1) used to play the value input clip.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		[EditorCondition("valueInputAudio.HasAsset", true)]
		public float valueInputVolume = 1.0f;

		[EditorHelp("Value Input Timeout", "The time in seconds between playing the value input clip twice.", "")]
		[EditorLimit(0.0f, false)]
		[EditorEndCondition]
		public float valueInputInterval = 0.1f;


		// change
		[EditorHelp("Change", "Can be played when something is changed.", "")]
		[EditorTitleLabel("Change")]
		[EditorSeparator]
		public AssetSource<AudioClip> changeAudio = new AssetSource<AudioClip>();

		[EditorHelp("Change Volume", "The volume (0-1) used to play the change clip.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		[EditorCondition("changeAudio.HasAsset", true)]
		[EditorEndCondition]
		public float changeVolume = 1.0f;


		// tab change
		[EditorHelp("Tab Change", "Played when input keys are used to change the selected tab.", "")]
		[EditorTitleLabel("Tab Change")]
		[EditorSeparator]
		public AssetSource<AudioClip> tabChangeAudio = new AssetSource<AudioClip>();

		[EditorHelp("Tab Change Volume", "The volume (0-1) used to play the tab change clip.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider = true)]
		[EditorCondition("tabChangeAudio.HasAsset", true)]
		[EditorEndCondition]
		public float tabChangeAudioVolume = 1.0f;


		// page change
		[EditorHelp("Page Change", "Played when input keys are used to change the page.", "")]
		[EditorTitleLabel("Page Change")]
		[EditorSeparator]
		public AssetSource<AudioClip> pageChangeAudio = new AssetSource<AudioClip>();

		[EditorHelp("Page Change Volume", "The volume (0-1) used to play the page change clip.", "")]
		[EditorLimit(0.0f, 1.0f, isSlider = true)]
		[EditorCondition("pageChangeAudio.HasAsset", true)]
		[EditorEndCondition]
		public float pageChangeAudioVolume = 1.0f;


		// ingame
		private float valueInputTime = 0;

		public MenuAudioClips()
		{

		}


		/*
		============================================================================
		Audio functions
		============================================================================
		*/
		public void Play(UIBoxAudioType type)
		{
			if(UIBoxAudioType.Cursor == type)
			{
				this.PlayCursorMove();
			}
			else if(UIBoxAudioType.Accept == type)
			{
				this.PlayAccept();
			}
			else if(UIBoxAudioType.Cancel == type)
			{
				this.PlayCancel();
			}
			else if(UIBoxAudioType.Fail == type)
			{
				this.PlayFail();
			}
			else if(UIBoxAudioType.ValueInput == type)
			{
				this.PlayValueInput();
			}
			else if(UIBoxAudioType.Change == type)
			{
				this.PlayChange();
			}
			else if(UIBoxAudioType.TabChange == type)
			{
				this.PlayTabChange();
			}
			else if(UIBoxAudioType.PageChange == type)
			{
				this.PlayPageChange();
			}
		}

		public void PlayCursorMove()
		{
			Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.cursorMoveAudio, this.cursorMoveVolume);
		}

		public void PlayAccept()
		{
			Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.acceptAudio, this.acceptVolume);
		}

		public void PlayCancel()
		{
			Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.cancelAudio, this.cancelVolume);
		}

		public void PlayFail()
		{
			Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.failAudio, this.failVolume);
		}

		public void PlayValueInput()
		{
			if(this.valueInputTime + this.valueInputInterval < Time.realtimeSinceStartup)
			{
				Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.valueInputAudio, this.valueInputVolume);
				this.valueInputTime = Time.realtimeSinceStartup;
			}
		}

		public void PlayChange()
		{
			Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.changeAudio, this.changeVolume);
		}

		public void PlayTabChange()
		{
			Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.tabChangeAudio, this.tabChangeAudioVolume);
		}

		public void PlayPageChange()
		{
			Maki.Audio.GetSoundChannel(this.channel).PlayOneShot(this.pageChangeAudio, this.pageChangeAudioVolume);
		}
	}
}
