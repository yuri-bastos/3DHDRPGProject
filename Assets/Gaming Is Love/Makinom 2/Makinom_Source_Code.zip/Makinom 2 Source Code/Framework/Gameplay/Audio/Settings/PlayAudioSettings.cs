﻿
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class PlayAudioSettings : BaseAudioSettings
	{
		[EditorHelp("Play One Shot", "Uses the PlayOneShot function of the audio source component to play the audio clip.", "")]
		public bool oneShot = false;


		// volume
		[EditorHelp("Set Volume", "Set the volume of the audio source.", "")]
		[EditorSeparator]
		[EditorCondition("oneShot", false)]
		[EditorEndCondition]
		public bool setVolume = false;

		[EditorHelp("Volume", "The volume the audio clip will be played with.", "")]
		[EditorCondition("oneShot", true)]
		[EditorCondition("setVolume", true)]
		[EditorEndCondition]
		[EditorLimit(0.0f, 1.0f, isSlider=true)]
		public float volume = 1;

		public PlayAudioSettings()
		{

		}

		public float PlayAudio(GameObject obj, AudioClip clip)
		{
			return this.PlayAudio(ComponentHelper.Get<AudioSource>(obj), clip);
		}

		public float PlayAudio(AudioSource audio, AudioClip clip)
		{
			if(audio != null)
			{
				this.Change(audio);

				// play
				if(this.oneShot)
				{
					ComponentHelper.PlayOneShot(audio.gameObject, clip, this.volume);
				}
				else
				{
					if(this.setVolume)
					{
						audio.volume = this.volume * Maki.Audio.SoundVolume;
					}
					audio.clip = clip;
					audio.Play();
				}
				return clip.length;
			}
			return 0;
		}

		public float PlayAudio(SoundChannel channel, AudioClip clip)
		{
			if(channel != null)
			{
				this.Change(channel.Source);

				// play
				if(this.oneShot)
				{
					channel.PlayOneShot(clip, this.volume);
				}
				else
				{
					if(this.setVolume)
					{
						channel.Volume = this.volume;
					}
					channel.Source.clip = clip;
					channel.Source.Play();
				}
				return clip.length;
			}
			return 0;
		}
	}
}

