﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public interface IDebug
	{
		void AddInfo(string info);

		void AddValue(object origin, object value);
	}
}
