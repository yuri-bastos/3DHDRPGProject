
using UnityEngine;
using UnityEngine.Audio;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Reflection
{
	public class CallParameter<T> : BaseData where T : IObjectSelection, new()
	{
		[EditorHelp("Parameter Type", "Select the value type of the parameter:\n" +
			"- String: A string value.\n" +
			"- Bool: A bool value.\n" +
			"- Int: An integer value.\n" +
			"- Float: A float value.\n" +
			"- Vector2: A Vector2 value (uses a Vector3, but only the X and Y axes).\n" +
			"- Vector3: A Vector3 value.\n" +
			"- Quaternion: A Quaternion value (uses a Vector3 as euler angles).\n" +
			"- Color: A color.\n" +
			"- Layer Mask: A layer mask.\n" +
			"- Game Object: A game object.\n" +
			"- Prefab: A prefab.\n" +
			"- Audio Clip: An audio clip.\n" +
			"- Audio Mixer: An audio mixer.\n" +
			"- Audio Mixer Group: An audio mixer group.\n" +
			"- Sprite: A sprite.\n" +
			"- Texture: A texture.\n" +
			"- Material: A material.\n" +
			"- Physic Material: A physic material.\n" +
			"- Physics Material 2D: A 2D physics material.\n" +
			"- Component: A component (attached to a game object).\n" +
			"- Enum: An enumeration.\n" +
			"- Transform: The transform of a game object.", "")]
		public ParameterType type = ParameterType.String;


		// string
		[EditorHelp("String Value", "Define the string value that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.String)]
		[EditorEndCondition]
		[EditorAutoInit]
		public StringValue<T> stringValue;


		// bool
		[EditorTitleLabel("Bool Value")]
		[EditorSeparator]
		[EditorCondition("type", ParameterType.Bool)]
		[EditorEndCondition]
		[EditorAutoInit]
		public BoolValue<T> boolValue;


		// enum
		[EditorHelp("Enum Name", "The name of the enumeration.\n" +
			"An int value will be used as the enum value.", "")]
		[EditorCondition("type", ParameterType.Enum)]
		[EditorEndCondition]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Enum)]
		public string enumName = "";


		// int, float, enum
		[EditorHelp("Int/Float Value", "Define the int/float value that will be used as parameter.", "")]
		[EditorSeparator]
		[EditorCondition("type", ParameterType.Int)]
		[EditorCondition("type", ParameterType.Float)]
		[EditorCondition("type", ParameterType.Enum)]
		[EditorEndCondition]
		[EditorAutoInit]
		public FloatValue<T> floatValue;


		// vector3, vector3, quaternion
		[EditorTitleLabel("Vector2/Vector3/Quaternion Value")]
		[EditorSeparator]
		[EditorCondition("type", ParameterType.Vector2)]
		[EditorCondition("type", ParameterType.Vector3)]
		[EditorCondition("type", ParameterType.Quaternion)]
		[EditorEndCondition]
		[EditorAutoInit]
		public Vector3Value<T> vector3Value;


		// color
		[EditorHelp("Color", "Select the color that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.Color)]
		[EditorEndCondition]
		public Color color = Color.white;


		// layer mask
		[EditorHelp("Layer Mask", "Select the layers that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.LayerMask)]
		[EditorEndCondition]
		public LayerMask layerMask = -1;


		// game object, component, transform
		[EditorTitleLabel("Game Object")]
		[EditorSeparator]
		[EditorCondition("type", ParameterType.GameObject)]
		[EditorCondition("type", ParameterType.Component)]
		[EditorCondition("type", ParameterType.Transform)]
		[EditorEndCondition]
		[EditorAutoInit]
		public T objectOrigin;

		// component
		[EditorHelp("Component Name", "The name of the component.", "")]
		[EditorWidth(true)]
		[EditorReflectionField(EditorReflectionFieldType.Class, typeof(Component))]
		[EditorCondition("type", ParameterType.Component)]
		public string componentName = "";

		[EditorHelp("Scope", "Select the scope of the component that will be used:\n" +
			"- In Object: A component attached to the game object.\n" +
			"- In Children: A component attached to the game object or any child object.\n" +
			"- In Parent: A component attached to the game object or any parent object.\n" +
			"- From Root: A component attached to the game object's root or any child object (from the root).", "")]
		[EditorEndCondition]
		public ComponentScopeSingle componentScope = ComponentScopeSingle.InObject;


		// prefab
		[EditorHelp("Prefab", "Select the prefab that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.Prefab)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<GameObject> prefab;


		// audio clip
		[EditorHelp("Audio Clip", "Select the audio clip that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.AudioClip)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<AudioClip> audioClip;


		// audio mixer
		[EditorHelp("Audio Mixer", "Select the audio mixer that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.AudioMixer)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<AudioMixer> audioMixer;


		// audio mixer group
		[EditorHelp("Audio Mixer Group", "Select the audio mixer group that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.AudioMixerGroup)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<AudioMixerGroup> audioMixerGroup;


		// sprite
		[EditorHelp("Sprite", "Select the sprite that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.Sprite)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<Sprite> sprite;


		// texture
		[EditorHelp("Texture", "Select the texture that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.Texture)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<Texture> texture;


		// material
		[EditorHelp("Material", "Select the material that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.Material)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<Material> material;


		// physic material
		[EditorHelp("Physic Material", "Select the physic material that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.PhysicMaterial)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<PhysicMaterial> physicMaterial;


		// physics material 2d
		[EditorHelp("Physics Material 2D", "Select the 2d physics material that will be used as parameter.", "")]
		[EditorCondition("type", ParameterType.PhysicsMaterial2D)]
		[EditorEndCondition]
		[EditorAutoInit]
		public AssetSource<PhysicsMaterial2D> physicMaterial2D;

		public CallParameter()
		{

		}

		public virtual bool NeedsCall
		{
			get
			{
				if(ParameterType.String == this.type)
				{
					return this.stringValue.NeedsCall;
				}
				else if(ParameterType.Bool == this.type)
				{
					return this.boolValue.NeedsCall;
				}
				else if(ParameterType.Int == this.type)
				{
					return this.floatValue.NeedsCall;
				}
				else if(ParameterType.Float == this.type)
				{
					return this.floatValue.NeedsCall;
				}
				else if(ParameterType.Vector2 == this.type)
				{
					return this.vector3Value.NeedsCall;
				}
				else if(ParameterType.Vector3 == this.type)
				{
					return this.vector3Value.NeedsCall;
				}
				else if(ParameterType.Quaternion == this.type)
				{
					return this.vector3Value.NeedsCall;
				}
				else if(ParameterType.GameObject == this.type)
				{
					return true;
				}
				else if(ParameterType.Component == this.type)
				{
					return true;
				}
				else if(ParameterType.Enum == this.type)
				{
					return this.floatValue.NeedsCall;
				}
				else if(ParameterType.Transform == this.type)
				{
					return true;
				}
				return false;
			}
		}

		public object GetParameterValue(IDataCall call)
		{
			if(ParameterType.String == this.type)
			{
				return this.stringValue.GetValue(call);
			}
			else if(ParameterType.Bool == this.type)
			{
				return this.boolValue.GetValue(call);
			}
			else if(ParameterType.Int == this.type)
			{
				return (int)this.floatValue.GetValue(call);
			}
			else if(ParameterType.Float == this.type)
			{
				return this.floatValue.GetValue(call);
			}
			else if(ParameterType.Vector2 == this.type)
			{
				return (Vector2)this.vector3Value.GetValue(call);
			}
			else if(ParameterType.Vector3 == this.type)
			{
				return this.vector3Value.GetValue(call);
			}
			else if(ParameterType.Quaternion == this.type)
			{
				return Quaternion.Euler(this.vector3Value.GetValue(call));
			}
			else if(ParameterType.Color == this.type)
			{
				return this.color;
			}
			else if(ParameterType.LayerMask == this.type)
			{
				return this.layerMask;
			}
			else if(ParameterType.GameObject == this.type)
			{
				return this.objectOrigin.GetObject(call);
			}
			else if(ParameterType.Prefab == this.type)
			{
				return this.prefab.settings.Get();
			}
			else if(ParameterType.AudioClip == this.type)
			{
				return this.audioClip.settings.Get();
			}
			else if(ParameterType.AudioMixer == this.type)
			{
				return this.audioMixer.settings.Get();
			}
			else if(ParameterType.AudioMixerGroup == this.type)
			{
				return this.audioMixerGroup.settings.Get();
			}
			else if(ParameterType.Sprite == this.type)
			{
				return this.sprite.settings.Get();
			}
			else if(ParameterType.Texture == this.type)
			{
				return this.texture.settings.Get();
			}
			else if(ParameterType.Material == this.type)
			{
				return this.material.settings.Get();
			}
			else if(ParameterType.PhysicMaterial == this.type)
			{
				return this.physicMaterial.settings.Get();
			}
			else if(ParameterType.PhysicsMaterial2D == this.type)
			{
				return this.physicMaterial2D.settings.Get();
			}
			else if(ParameterType.Component == this.type)
			{
				List<GameObject> list = this.objectOrigin.GetObjects(call);
				Component component = ComponentHelper.Get(list, this.componentScope, this.componentName);
				Maki.Pooling.GameObjectLists.Add(list);
				return component;
			}
			else if(ParameterType.Enum == this.type)
			{
				return (int)this.floatValue.GetValue(call);
			}
			else if(ParameterType.Transform == this.type)
			{
				GameObject tmpObject = this.objectOrigin.GetObject(call);
				if(tmpObject != null)
				{
					return tmpObject.transform;
				}
			}
			return null;
		}

		public override string ToString()
		{
			if(ParameterType.String == this.type)
			{
				return this.stringValue.ToString();
			}
			else if(ParameterType.Bool == this.type)
			{
				return this.boolValue.ToString();
			}
			else if(ParameterType.Int == this.type ||
				ParameterType.Float == this.type)
			{
				return this.floatValue.ToString();
			}
			else if(ParameterType.Vector2 == this.type ||
				ParameterType.Vector3 == this.type ||
				ParameterType.Quaternion == this.type)
			{
				return this.vector3Value.ToString();
			}
			else if(ParameterType.Color == this.type)
			{
				return "Color";
			}
			else if(ParameterType.LayerMask == this.type)
			{
				return "Layer Mask";
			}
			else if(ParameterType.GameObject == this.type ||
				ParameterType.Transform == this.type)
			{
				return this.objectOrigin.ToString();
			}
			else if(ParameterType.Prefab == this.type)
			{
				return this.prefab.ToString();
			}
			else if(ParameterType.AudioClip == this.type)
			{
				return this.audioClip.ToString();
			}
			else if(ParameterType.AudioMixer == this.type)
			{
				return this.audioMixer.ToString();
			}
			else if(ParameterType.AudioMixerGroup == this.type)
			{
				return this.audioMixerGroup.ToString();
			}
			else if(ParameterType.Sprite == this.type)
			{
				return this.sprite.ToString();
			}
			else if(ParameterType.Texture == this.type)
			{
				return this.texture.ToString();
			}
			else if(ParameterType.Material == this.type)
			{
				return this.material.ToString();
			}
			else if(ParameterType.PhysicMaterial == this.type)
			{
				return this.physicMaterial.ToString();
			}
			else if(ParameterType.PhysicsMaterial2D == this.type)
			{
				return this.physicMaterial2D.ToString();
			}
			else if(ParameterType.Component == this.type)
			{
				return this.componentName + "(" + this.objectOrigin.ToString() + ")";
			}
			else if(ParameterType.Enum == this.type)
			{
				return this.enumName + " " + this.floatValue.ToString();
			}
			return "";
		}
	}
}
