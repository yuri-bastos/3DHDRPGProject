
using UnityEngine;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom
{
	public sealed class ReflectionTypeHandler
	{
		// instance
		private static ReflectionTypeHandler instance;

		private static System.Object instanceLock = new System.Object();


		// types
		private Dictionary<string, System.Type> reflectionType = new Dictionary<string, System.Type>();


		// field infos
		private Dictionary<System.Type, FieldInfo[]> fieldInfos = new Dictionary<System.Type, FieldInfo[]>();


		// constructors
		private System.Object[] empty = new System.Object[] { };

		private Dictionary<System.Type, ConstructorInfo> emptyConstructors = new Dictionary<System.Type, ConstructorInfo>();

		private Dictionary<System.Type, ConstructorInfo> constructors = new Dictionary<System.Type, ConstructorInfo>();


		// statics
		public static BindingFlags FieldBindingFlags = BindingFlags.Public | BindingFlags.NonPublic |
			BindingFlags.Static | BindingFlags.Instance;


		// text codes
		private Dictionary<System.Type, TextCodeAttribute> textCodes;


		/*
		============================================================================
		Init functions
		============================================================================
		*/
		private ReflectionTypeHandler()
		{
			if(instance != null)
			{
				Debug.LogError("You can't create two instances of ReflectionTypeHandler!");
			}
			else
			{
				instance = this;
			}
		}

		public static ReflectionTypeHandler Instance
		{
			get
			{
				if(instance == null)
				{
					lock(instanceLock)
					{
						if(instance == null)
						{
							new ReflectionTypeHandler();
						}
					}
				}
				return instance;
			}
		}


		/*
		============================================================================
		Constructor functions
		============================================================================
		*/
		public System.Object CreateInstance(string typeString, System.Type baseType)
		{
			System.Type type = this.GetType(typeString, baseType);
			if(type != null)
			{
				return this.CreateInstance(type);
			}
			return null;
		}

		public System.Object CreateInstance(System.Type type)
		{
			if(type != null)
			{
				ConstructorInfo constructorInfo;
				if(this.emptyConstructors.TryGetValue(type, out constructorInfo))
				{
					return constructorInfo.Invoke(this.empty);
				}
				else
				{
					if(type.Equals(typeof(string)))
					{
						return "";
					}
					else if(type.Equals(typeof(int)))
					{
						return 0;
					}
					else if(type.Equals(typeof(float)))
					{
						return 0.0f;
					}
					else if(type.Equals(typeof(bool)))
					{
						return false;
					}
					else if(type.IsValueType)
					{
						return System.Activator.CreateInstance(type);
					}
					else
					{
						constructorInfo = type.GetConstructor(System.Type.EmptyTypes);
						if(constructorInfo != null)
						{
							this.emptyConstructors.Add(type, constructorInfo);
							return constructorInfo.Invoke(this.empty);
						}
					}
				}
			}
			return null;
		}

		public System.Object CreateInstance(System.Type type, System.Type[] constTypes, System.Object[] constValues)
		{
			if(type != null)
			{
				ConstructorInfo constructorInfo;
				if(this.constructors.TryGetValue(type, out constructorInfo))
				{
					return constructorInfo.Invoke(constValues);
				}
				else
				{
					constructorInfo = type.GetConstructor(constTypes);
					if(constructorInfo != null)
					{
						this.constructors.Add(type, constructorInfo);
						return constructorInfo.Invoke(constValues);
					}
				}
			}
			return null;
		}


		/*
		============================================================================
		Type functions
		============================================================================
		*/
		public System.Type SerializerGetType(string typeName)
		{
			System.Type type = null;
			if(this.reflectionType.TryGetValue(typeName, out type))
			{
				return type;
			}
			else
			{
				// generic types
				if(typeName.Contains("[") &&
					!typeName.Contains("Version="))
				{
					string[] split = typeName.Split('[', ',', ']');
					if(split.Length > 0)
					{
						System.Type baseType = ReflectionTypeHandler.Instance.SerializerGetType(split[0]);
						List<System.Type> typeArgs = new List<System.Type>();
						for(int i = 1; i < split.Length; i++)
						{
							if(split[i] != "")
							{
								System.Type tmpType = ReflectionTypeHandler.Instance.SerializerGetType(split[i]);
								if(tmpType != null)
								{
									typeArgs.Add(tmpType);
								}
							}
						}
						type = baseType.MakeGenericType(typeArgs.ToArray());
					}
				}
				// normal types
				else
				{
					Assembly makinom = Assembly.Load("Makinom2");
					if(makinom != null)
					{
						type = makinom.GetType(typeName);
						if(type == null)
						{
							type = makinom.GetType("GamingIsLove.Makinom." + typeName);
						}
					}

					if(type == null)
					{
						System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
						for(int i = 0; i < assembly.Length; i++)
						{
							type = assembly[i].GetType(typeName);
							if(type != null)
							{
								break;
							}
							else
							{
								type = assembly[i].GetType("GamingIsLove.Makinom." + typeName);
								if(type != null)
								{
									break;
								}
							}
						}
					}
					if(type == null)
					{
						type = ReflectionTypeHandler.Instance.SerializerGetRenamedType(typeName);
					}
				}
				if(type != null)
				{
					this.reflectionType.Add(typeName, type);
				}
				return type;
			}
		}

		private System.Type SerializerGetRenamedType(string typeName)
		{
			// schematic nodes
			if(typeName == "GamingIsLove.Makinom.Schematics.Nodes.GameOptionDialogueNode")
			{
				typeName = "GamingIsLove.Makinom.Schematics.Nodes.ValueOptionDialogueNode";
			}
			// formula nodes
			else if(typeName == "GamingIsLove.Makinom.Formulas.Nodes.SelectedDataCountStep")
			{
				typeName = "GamingIsLove.Makinom.Formulas.Nodes.SelectedDataCountNode";
			}
			else
			{
				return null;
			}

			System.Type type = null;
			if(this.reflectionType.TryGetValue(typeName, out type))
			{
				return type;
			}
			else
			{
				Assembly makinom = Assembly.Load("Makinom2");
				if(makinom != null)
				{
					type = makinom.GetType(typeName);
					if(type == null)
					{
						type = makinom.GetType("GamingIsLove.Makinom." + typeName);
					}
				}

				if(type == null)
				{
					System.Reflection.Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
					for(int i = 0; i < assembly.Length; i++)
					{
						type = assembly[i].GetType(typeName);
						if(type != null)
						{
							break;
						}
					}
				}
				if(type != null)
				{
					this.reflectionType.Add(typeName, type);
				}
				return type;
			}
		}

		public static string GetClassName(string reflectionString)
		{
			int index = reflectionString.LastIndexOf(".");
			if(index >= 0)
			{
				return reflectionString.Substring(index + 1);
			}
			return reflectionString;
		}

		public System.Type GetType(string reflectionString)
		{
			System.Type type;
			if(this.reflectionType.TryGetValue(reflectionString, out type))
			{
				return type;
			}
			else
			{
				string className = ReflectionTypeHandler.GetClassName(reflectionString);
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();

				for(int i = 0; i < assembly.Length; i++)
				{
					type = assembly[i].GetType(reflectionString);
					if(type == null)
					{
						type = assembly[i].GetType("GamingIsLove.Makinom." + reflectionString);
					}
					if(type != null && type.IsClass &&
						type.IsPublic && type.Name == className)
					{
						this.reflectionType.Add(reflectionString, type);
						return type;
					}
				}

				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] types = assembly[i].GetTypes();
						for(int j = 0; j < types.Length; j++)
						{
							if(types[j] != null && types[j].IsClass &&
								types[j].IsPublic && types[j].Name == className)
							{
								this.reflectionType.Add(reflectionString, types[j]);
								return types[j];
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for type: " + ex.Message);
					}
				}
			}
			return null;
		}

		public System.Type GetTypeOrInterface(string reflectionString)
		{
			System.Type type;
			if(this.reflectionType.TryGetValue(reflectionString, out type))
			{
				return type;
			}
			else
			{
				string className = ReflectionTypeHandler.GetClassName(reflectionString);
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();

				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						type = assembly[i].GetType(reflectionString);
						if(type == null)
						{
							type = assembly[i].GetType("GamingIsLove.Makinom." + reflectionString);
						}
						if(type != null &&
							(type.IsClass ? type.IsPublic : type.IsInterface) &&
							type.Name == className)
						{
							this.reflectionType.Add(reflectionString, type);
							return type;
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for type: " + ex.Message);
					}
				}

				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] types = assembly[i].GetTypes();
						for(int j = 0; j < types.Length; j++)
						{
							if(types[j] != null &&
								(types[j].IsClass ? types[j].IsPublic : types[j].IsInterface) &&
								types[j].Name == className)
							{
								this.reflectionType.Add(reflectionString, types[j]);
								return types[j];
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for type: " + ex.Message);
					}
				}
			}
			return null;
		}

		public System.Type GetType(string reflectionString, System.Type baseType)
		{
			System.Type type = null;
			if(this.reflectionType.TryGetValue(reflectionString, out type))
			{
				return type;
			}
			else
			{
				string className = ReflectionTypeHandler.GetClassName(reflectionString);
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();

				for(int i = 0; i < assembly.Length; i++)
				{
					type = assembly[i].GetType(reflectionString);
					if(type == null)
					{
						type = assembly[i].GetType("GamingIsLove.Makinom." + reflectionString);
					}
					if(type != null && type.IsClass && type.IsPublic &&
						baseType.IsAssignableFrom(type))
					{
						this.reflectionType.Add(reflectionString, type);
						return type;
					}
				}

				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] types = assembly[i].GetTypes();
						for(int j = 0; j < types.Length; j++)
						{
							if(types[j] != null && types[j].IsClass && types[j].IsPublic &&
								baseType.IsAssignableFrom(types[j]) && types[j].Name == className)
							{
								this.reflectionType.Add(reflectionString, types[j]);
								return types[j];
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for type: " + ex.Message);
					}
				}
			}
			return null;
		}

		public System.Type GetTypeOrInterface(string reflectionString, System.Type baseType)
		{
			System.Type type = null;
			if(this.reflectionType.TryGetValue(reflectionString, out type))
			{
				return type;
			}
			else
			{
				string className = ReflectionTypeHandler.GetClassName(reflectionString);
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();

				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						type = assembly[i].GetType(reflectionString);
						if(type == null)
						{
							type = assembly[i].GetType("GamingIsLove.Makinom." + reflectionString);
						}
						if(type != null &&
							(type.IsClass ?
								(type.IsPublic && baseType.IsAssignableFrom(type)) :
								type.IsInterface))
						{
							this.reflectionType.Add(reflectionString, type);
							return type;
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for type: " + ex.Message);
					}
				}

				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] types = assembly[i].GetTypes();
						for(int j = 0; j < types.Length; j++)
						{
							if(types[j] != null &&
								(types[j].IsClass ?
									(types[j].IsPublic && baseType.IsAssignableFrom(types[j])) :
									types[j].IsInterface) &&
								types[j].Name == className)
							{
								this.reflectionType.Add(reflectionString, types[j]);
								return types[j];
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for type: " + ex.Message);
					}
				}
			}
			return null;
		}

		public System.Type GetEnumType(string reflectionString)
		{
			System.Type type = null;
			if(this.reflectionType.TryGetValue(reflectionString, out type))
			{
				return type;
			}
			else
			{
				string className = ReflectionTypeHandler.GetClassName(reflectionString);
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();

				for(int i = 0; i < assembly.Length; i++)
				{
					type = assembly[i].GetType(reflectionString);
					if(type == null)
					{
						type = assembly[i].GetType("GamingIsLove.Makinom." + reflectionString);
					}
					if(type != null && type.IsEnum &&
						type.IsPublic && type.Name == className)
					{
						this.reflectionType.Add(reflectionString, type);
						return type;
					}
				}

				for(int i = 0; i < assembly.Length; i++)
				{
					try
					{
						System.Type[] types = assembly[i].GetTypes();
						for(int j = 0; j < types.Length; j++)
						{
							if(types[j] != null && types[j].IsEnum &&
								types[j].IsPublic && types[j].Name == className)
							{
								this.reflectionType.Add(reflectionString, types[j]);
								return types[j];
							}
						}
					}
					catch(System.Reflection.ReflectionTypeLoadException ex)
					{
						Debug.LogWarning("Issue while searching for type: " + ex.Message);
					}
				}
			}
			return null;
		}

		public static string GetGenericTypeName(System.Type type)
		{
			if(!string.IsNullOrEmpty(type.Namespace))
			{
				return type.Namespace + "." + type.Name;
			}
			return type.Name;
		}


		/*
		============================================================================
		FieldInfo functions
		============================================================================
		*/
		public FieldInfo[] GetFields(System.Type type)
		{
			FieldInfo[] field;
			if(this.fieldInfos.TryGetValue(type, out field))
			{
				return field;
			}
			else
			{
				field = type.GetFields(BindingFlags.Public | BindingFlags.Instance);
				this.fieldInfos.Add(type, field);
				return field;
			}
		}

		public static bool GetFieldValue(out object value, object instance, string fieldName)
		{
			if(fieldName.Contains("."))
			{
				value = instance;

				string[] names = fieldName.Split('.');
				for(int j = 0; j < names.Length; j++)
				{
					if(value != null)
					{
						// field
						FieldInfo field = value.GetType().GetField(names[j]);
						if(field != null)
						{
							value = field.GetValue(value);
							if(j == names.Length - 1)
							{
								return true;
							}
						}
						// property
						else
						{
							PropertyInfo property = value.GetType().GetProperty(names[j]);
							if(property != null)
							{
								value = property.GetValue(value, null);
								if(j == names.Length - 1)
								{
									return true;
								}
							}
							else
							{
								break;
							}
						}
					}
				}
			}
			else
			{
				// field
				FieldInfo field = instance.GetType().GetField(fieldName);
				if(field != null)
				{
					value = field.GetValue(instance);
					return true;
				}
				// property
				else
				{
					PropertyInfo property = instance.GetType().GetProperty(fieldName);
					if(property != null)
					{
						value = property.GetValue(instance, null);
						return true;
					}
				}
			}
			value = null;
			return false;
		}


		/*
		============================================================================
		Nested functions
		============================================================================
		*/
		public FieldInfo GetField(string fieldName, ref object instance, ref System.Type instanceType)
		{
			if(fieldName.Contains("."))
			{
				string[] path = fieldName.Split('.');
				for(int i = 0; i < path.Length; i++)
				{
					// final field
					if(i == path.Length - 1)
					{
						return instanceType.GetField(path[i],
							ReflectionTypeHandler.FieldBindingFlags);
					}
					// on path
					else
					{
						// field
						FieldInfo fieldInfo = instanceType.GetField(path[i],
							ReflectionTypeHandler.FieldBindingFlags);
						if(fieldInfo != null)
						{
							instanceType = fieldInfo.FieldType;
							if(instance != null)
							{
								instance = fieldInfo.GetValue(instance);
							}
						}
						// property
						else
						{
							PropertyInfo propertyInfo = instanceType.GetProperty(path[i],
								ReflectionTypeHandler.FieldBindingFlags);
							if(propertyInfo != null)
							{
								instanceType = propertyInfo.PropertyType;
								if(instance != null)
								{
									instance = propertyInfo.GetValue(instance, null);
								}
							}
							else
							{
								return null;
							}
						}
					}
				}
			}
			else
			{
				return instanceType.GetField(fieldName,
					ReflectionTypeHandler.FieldBindingFlags);
			}
			return null;
		}

		public PropertyInfo GetProperty(string propertyName, ref object instance, ref System.Type instanceType)
		{
			if(propertyName.Contains("."))
			{
				string[] path = propertyName.Split('.');
				for(int i = 0; i < path.Length; i++)
				{
					// final field
					if(i == path.Length - 1)
					{
						return instanceType.GetProperty(path[i],
							ReflectionTypeHandler.FieldBindingFlags);
					}
					// on path
					else
					{
						// field
						FieldInfo fieldInfo = instanceType.GetField(path[i],
							ReflectionTypeHandler.FieldBindingFlags);
						if(fieldInfo != null)
						{
							instanceType = fieldInfo.FieldType;
							if(instance != null)
							{
								instance = fieldInfo.GetValue(instance);
							}
						}
						// property
						else
						{
							PropertyInfo propertyInfo = instanceType.GetProperty(path[i],
								ReflectionTypeHandler.FieldBindingFlags);
							if(propertyInfo != null)
							{
								instanceType = propertyInfo.PropertyType;
								if(instance != null)
								{
									instance = propertyInfo.GetValue(instance, null);
								}
							}
							else
							{
								return null;
							}
						}
					}
				}
			}
			else
			{
				return instanceType.GetProperty(propertyName,
					ReflectionTypeHandler.FieldBindingFlags);
			}
			return null;
		}

		public MethodInfo GetMethod(string functionName, System.Type[] parameterType,
			ref object instance, ref System.Type instanceType)
		{
			if(functionName.Contains("."))
			{
				string[] path = functionName.Split('.');
				for(int i = 0; i < path.Length; i++)
				{
					// final field
					if(i == path.Length - 1)
					{
						return instanceType.GetMethod(path[i], parameterType);
					}
					// on path
					else
					{
						// field
						FieldInfo fieldInfo = instanceType.GetField(path[i],
							ReflectionTypeHandler.FieldBindingFlags);
						if(fieldInfo != null)
						{
							instanceType = fieldInfo.FieldType;
							if(instance != null)
							{
								instance = fieldInfo.GetValue(instance);
							}
						}
						// property
						else
						{
							PropertyInfo propertyInfo = instanceType.GetProperty(path[i],
								ReflectionTypeHandler.FieldBindingFlags);
							if(propertyInfo != null)
							{
								instanceType = propertyInfo.PropertyType;
								if(instance != null)
								{
									instance = propertyInfo.GetValue(instance, null);
								}
							}
							else
							{
								return null;
							}
						}
					}
				}
			}
			else
			{
				return instanceType.GetMethod(functionName, parameterType);
			}
			return null;
		}


		/*
		============================================================================
		Text code functions
		============================================================================
		*/
		public TextCodeAttribute GetTextCode(System.Type type)
		{
			if(this.textCodes == null)
			{
				this.GetTextCodes();
			}
			TextCodeAttribute textCode = null;
			if(!this.textCodes.TryGetValue(type, out textCode))
			{
				object[] attr = type.GetCustomAttributes(typeof(TextCodeAttribute), true);
				if(attr.Length > 0)
				{
					textCode = attr[0] as TextCodeAttribute;
				}
				if(textCode != null)
				{
					this.textCodes.Add(type, textCode);
				}
			}
			return textCode;
		}

		public Dictionary<System.Type, TextCodeAttribute> GetTextCodes()
		{
			if(this.textCodes == null)
			{
				System.Type baseType = typeof(BaseIndexData);
				this.textCodes = new Dictionary<System.Type, TextCodeAttribute>();
				Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
				for(int i = 0; i < assembly.Length; i++)
				{
					ReflectionTypeHandler.AddTextCodeFromAssembly(baseType, assembly[i], ref this.textCodes);
				}
			}
			return this.textCodes;
		}

		private static void AddTextCodeFromAssembly(System.Type baseType, Assembly assembly,
			ref Dictionary<System.Type, TextCodeAttribute> list)
		{
			try
			{
				System.Type[] types = assembly.GetTypes();
				for(int i = 0; i < types.Length; i++)
				{
					System.Type type = types[i].IsNested ? types[i].DeclaringType : types[i];
					if(!list.ContainsKey(type) &&
						!type.IsAbstract &&
						baseType.IsAssignableFrom(type))
					{
						TextCodeAttribute textCode = null;
						object[] attr = type.GetCustomAttributes(typeof(TextCodeAttribute), true);
						if(attr.Length > 0)
						{
							textCode = attr[0] as TextCodeAttribute;
						}
						if(textCode != null)
						{
							list.Add(type, textCode);
						}
					}
				}
			}
			catch(System.Reflection.ReflectionTypeLoadException ex)
			{
				Debug.LogWarning("Issue while searching for text codes: " + ex.Message);
			}
		}


		/*
		============================================================================
		Find classes functions
		============================================================================
		*/
		public static List<T> FindAndCreateAll<T>()
		{
			List<T> list = new List<T>();
			System.Type baseType = typeof(T);
			Assembly[] assembly = System.AppDomain.CurrentDomain.GetAssemblies();
			for(int i = 0; i < assembly.Length; i++)
			{
				ReflectionTypeHandler.FindClassesInAssembly(baseType, assembly[i], ref list);
			}
			return list;
		}

		private static void FindClassesInAssembly<T>(System.Type baseType, Assembly assembly, ref List<T> list)
		{
			try
			{
				System.Type[] types = assembly.GetTypes();
				for(int i = 0; i < types.Length; i++)
				{
					System.Type type = types[i].IsNested ? types[i].DeclaringType : types[i];
					if(!type.IsAbstract &&
						type.IsClass &&
						baseType.IsAssignableFrom(type))
					{
						list.Add((T)ReflectionTypeHandler.instance.CreateInstance(type));
					}
				}
			}
			catch(System.Reflection.ReflectionTypeLoadException ex)
			{
				Debug.LogWarning("Issue while searching for classes: " + ex.Message);
			}
		}
	}
}
