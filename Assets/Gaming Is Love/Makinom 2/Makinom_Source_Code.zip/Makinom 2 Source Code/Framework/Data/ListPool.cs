﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	public class ListPool<T>
	{
		private int size = 100;

		private int trimExcessThreshold = -1;

		private Queue<List<T>> pool;

		public ListPool()
		{
			this.pool = new Queue<List<T>>(this.size);
		}

		public ListPool(int size, int trimExcessThreshold)
		{
			this.size = size;
			this.trimExcessThreshold = trimExcessThreshold;
			this.pool = new Queue<List<T>>(this.size);
		}

		public void Add(List<T> list)
		{
			if(list != null && 
				this.pool.Count < this.size)
			{
				list.Clear();
				if(this.trimExcessThreshold > 0 &&
					list.Capacity > this.trimExcessThreshold)
				{
					list.TrimExcess();
				}
				this.pool.Enqueue(list);
			}
		}

		public List<T> Get()
		{
			List<T> list = null;
			if(this.pool.Count > 0)
			{
				list = this.pool.Dequeue();
			}
			else
			{
				list = new List<T>();
			}
			return list;
		}
	}
}
