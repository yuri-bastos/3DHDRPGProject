
using UnityEngine;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false)]
	public class NodeInfoAttribute : System.Attribute
	{
		public string[] subMenu;

		public NodeInfoAttribute()
		{
			this.subMenu = new string[] { "" };
		}

		public NodeInfoAttribute(string subMenu)
		{
			this.subMenu = new string[] { subMenu };
		}

		public NodeInfoAttribute(params string[] subMenu)
		{
			this.subMenu = subMenu;
		}
	}
}
