﻿
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom
{
	[System.AttributeUsage(System.AttributeTargets.Class, AllowMultiple = false)]
	public class EditorCombinedFieldAttribute : System.Attribute
	{
		public string[] field;

		public bool flexibleSpace = false;

		public bool noInspectorHorizontal = false;

		public EditorCombinedFieldAttribute(params string[] field)
		{
			this.field = field;
		}
	}
}
