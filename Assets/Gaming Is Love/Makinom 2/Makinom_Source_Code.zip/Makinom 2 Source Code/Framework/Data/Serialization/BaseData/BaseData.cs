
namespace GamingIsLove.Makinom
{
	/// <summary>
	/// Default data serialization implementation.
	/// Descend your class from this class if no special data serialization is needed, or override the serialization functions.
	/// </summary>
	public abstract class BaseData : IBaseData
	{
		/// <summary>
		/// Gets a <see cref="GamingIsLove.Makinom.DataObject"/> representing the class.
		/// </summary>
		/// <returns>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the class data.
		/// </returns>
		public virtual DataObject GetData()
		{
			return DataSerializer.GetDataObject(this);
		}

		/// <summary>
		/// Sets the variables of the class using a <see cref="GamingIsLove.Makinom.DataObject"/>.
		/// </summary>
		/// <param name='data'>
		/// <see cref="GamingIsLove.Makinom.DataObject"/> containing the data.
		/// </param>
		public virtual void SetData(DataObject data)
		{
			DataSerializer.SetDataObject(data, this);
		}

		/// <summary>
		/// Called for the field defined using the <c>settingAutoSetup</c> option of the <see cref="GamingIsLove.Makinom.EditorInfoAttribute"/>.
		/// </summary>
		/// <param name="fieldName">The name of the field the function is called for.</param>
		public virtual void EditorAutoSetup(string fieldName)
		{

		}
	}
}
