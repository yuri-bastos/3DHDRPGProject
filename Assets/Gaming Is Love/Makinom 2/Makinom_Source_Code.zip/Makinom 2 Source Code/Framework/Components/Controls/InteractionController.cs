
using GamingIsLove.Makinom;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Controls/Interaction Controller")]
	public class InteractionController : SerializedBehaviour<InteractionController.Settings>
	{
		// in-game
		protected bool interacting = false;

		protected List<IInteractionBehaviour> list = new List<IInteractionBehaviour>();

		protected InteractionDistanceSorter sorter;

		protected Vector3 lastPosition;

		protected HashSet<MachineTypeAsset> machineTypeLimit = null;

		protected virtual void Start()
		{
			this.sorter = new InteractionDistanceSorter(this);
			this.lastPosition = this.transform.position;

			this.InitTypeLimitList();
		}

		protected virtual void OnDisable()
		{
			this.list.Clear();
		}


		/*
		============================================================================
		Type limit functions
		============================================================================
		*/
		public virtual void InitTypeLimitList()
		{
			if(this.settings.any)
			{
				this.machineTypeLimit = null;
			}
			else
			{
				this.machineTypeLimit = new HashSet<MachineTypeAsset>();
				for(int i = 0; i < this.settings.machineType.Length; i++)
				{
					if(this.settings.machineType[i].StoredAsset != null &&
						!this.machineTypeLimit.Contains(this.settings.machineType[i].StoredAsset))
					{
						this.machineTypeLimit.Add(this.settings.machineType[i].StoredAsset);
					}
				}
			}
		}

		public virtual bool CanAddInteraction(IInteractionBehaviour interaction)
		{
			return this.machineTypeLimit == null ||
				(interaction.MachineType == null ?
					this.settings.noneTypes :
					this.machineTypeLimit.Contains(interaction.MachineType));
		}


		/*
		============================================================================
		List functions
		============================================================================
		*/
		public virtual void SortInteractions()
		{
			if(this.settings.interactWithNearest &&
				this.list.Count > 1)
			{
				this.lastPosition = this.transform.position;
				this.sorter.UpdatePosition();
				this.list.Sort(this.sorter);
			}
		}

		public virtual void Remove(IInteractionBehaviour interaction)
		{
			this.list.Remove(interaction);
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public virtual bool InteractionAvailable(MachineTypeAsset machineType)
		{
			return InteractionHandler.InteractionAvailable(machineType,
				Maki.Game.Player.GameObject, this.list, null);
		}

		public virtual IInteractionBehaviour GetFirstAvailable(MachineTypeAsset machineType)
		{
			this.SortInteractions();
			return InteractionHandler.GetFirstAvailable(machineType,
				Maki.Game.Player.GameObject, this.list, null);
		}

		public virtual int AvailableCount
		{
			get
			{
				int count = 0;
				for(int i = 0; i < this.list.Count; i++)
				{
					// remove dead interactions
					if(!ComponentHelper.IsAlive(this.list[i]))
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled &&
						this.list[i].CanInteract(Maki.Game.Player.GameObject) &&
						Maki.GameControls.interaction.lineOfSight.Check(Maki.Game.Player.GameObject, this.list[i].gameObject))
					{
						count++;
					}
				}
				return count;
			}
		}


		/*
		============================================================================
		Trigger functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter(Collider other)
		{
			IInteractionBehaviour[] interactions = other.gameObject.GetComponents<IInteractionBehaviour>();
			for(int i = 0; i < interactions.Length; i++)
			{
				if(interactions[i] != null &&
					interactions[i].IsInteract &&
					this.CanAddInteraction(interactions[i]) &&
					!this.list.Contains(interactions[i]))
				{
					this.list.Add(interactions[i]);
				}
			}
		}

		protected virtual void OnTriggerExit(Collider other)
		{
			IInteractionBehaviour[] interactions = other.gameObject.GetComponents<IInteractionBehaviour>();
			for(int i = 0; i < interactions.Length; i++)
			{
				if(interactions[i] != null &&
					interactions[i].IsInteract)
				{
					this.list.Remove(interactions[i]);
				}
			}
		}


		/*
		============================================================================
		Trigger2D functions
		============================================================================
		*/
		protected virtual void OnTriggerEnter2D(Collider2D other)
		{
			IInteractionBehaviour[] interactions = other.gameObject.GetComponents<IInteractionBehaviour>();
			for(int i = 0; i < interactions.Length; i++)
			{
				if(interactions[i] != null &&
					interactions[i].IsInteract &&
					this.CanAddInteraction(interactions[i]) &&
					!this.list.Contains(interactions[i]))
				{
					this.list.Add(interactions[i]);
				}
			}
		}

		protected virtual void OnTriggerExit2D(Collider2D other)
		{
			IInteractionBehaviour[] interactions = other.gameObject.GetComponents<IInteractionBehaviour>();
			for(int i = 0; i < interactions.Length; i++)
			{
				if(interactions[i] != null &&
					interactions[i].IsInteract)
				{
					this.list.Remove(interactions[i]);
				}
			}
		}


		/*
		============================================================================
		Interaction functions
		============================================================================
		*/
		public virtual bool Interact()
		{
			if(!this.interacting && Maki.Control.CanInteract)
			{
				this.SortInteractions();
				for(int i = 0; i < this.list.Count; i++)
				{
					// remove dead interactions
					if(!ComponentHelper.IsAlive(this.list[i]))
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled &&
						Maki.GameControls.interaction.lineOfSight.Check(Maki.Game.Player.GameObject, this.list[i].gameObject))
					{
						StartCoroutine(BlockInteraction());
						if(this.list[i].Interact(Maki.Game.Player.GameObject))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public virtual bool Interact(MachineTypeAsset machineType)
		{
			if(!this.interacting && Maki.Control.CanInteract)
			{
				this.SortInteractions();
				for(int i = 0; i < this.list.Count; i++)
				{
					// remove dead interactions
					if(!ComponentHelper.IsAlive(this.list[i]))
					{
						this.list.RemoveAt(i--);
					}
					// check available interactions
					else if(this.list[i].enabled &&
						this.list[i].CanInteract(Maki.Game.Player.GameObject) &&
						(machineType == null || machineType == this.list[i].MachineType) &&
						Maki.GameControls.interaction.lineOfSight.Check(Maki.Game.Player.GameObject, this.list[i].gameObject))
					{
						this.StartCoroutine(this.BlockInteraction());
						if(this.list[i].Interact(Maki.Game.Player.GameObject))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		protected virtual IEnumerator BlockInteraction()
		{
			this.interacting = true;
			yield return null;
			this.interacting = false;
		}


		/*
		============================================================================
		Gizmo functions
		============================================================================
		*/
		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(this.transform.position, "/GamingIsLove/Makinom/Components/InteractionController Icon.png");
		}

		protected virtual void OnDrawGizmosSelected()
		{
			if(this.settings.interactWithNearest)
			{
				Gizmos.color = Color.green;
				Gizmos.DrawWireCube(
					this.transform.TransformPoint(this.settings.positionOffset),
					new Vector3(0.05f, 0.05f, 0.05f));
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Priority", "The priority of this interaction controller.\n" +
				"The priority of interaction controllers decides which will be checked before others when trying to interact.\n" +
				"Interaction controllers are sorted descending by their priority, " +
				"i.e. the highest priority number will be the first to use.", "")]
			public int priority = 0;

			[EditorHelp("Interact With Nearest", "The interaction nearest to the interaction controller's position + offset is used.\n" +
				"The position offset is in local space.\n" +
				"If disabled, the first interaction that entered the interaction controller is used.")]
			public bool interactWithNearest = false;

			[EditorHelp("Ignore Distance", "Enable the axes that will be ignored for the distance check.")]
			[EditorCondition("interactWithNearest", true)]
			public AxisBool ignoreDistance = new AxisBool();

			[EditorHelp("Position Offset", "The offset to the interaction controller's position used for determine the nearest interaction.")]
			[EditorEndCondition]
			public Vector3 positionOffset = Vector3.zero;


			// limit machine type
			[EditorHelp("Any Interaction", "Any interaction is used by this interaction controller.\n" +
				"If disabled, you can limit the interactions to defined machine types.", "")]
			[EditorSeparator]
			[EditorTitleLabel("Limit Machine Types")]
			public bool any = true;

			[EditorHelp("None Types", "Interact with interactions that have no machine type defined.")]
			[EditorCondition("any", false)]
			public bool noneTypes = false;

			[EditorHelp("Machine Type", "Select the machine type that can be interacted with.", "")]
			[EditorArray("Add Machine Type", "Adds a machine type that can be interacted with.", "",
				"Remove", "Removes this machine type.", "", 
				isCopy = true, isMove = true,
				foldout = true, foldoutText = new string[] {
					"Machine Type", "Select the machine type that can be interacted with.", ""
				})]
			[EditorEndCondition]
			[EditorAutoInit]
			public AssetSelection<MachineTypeAsset>[] machineType;

			public Settings()
			{

			}
		}
	}
}