﻿
using UnityEngine;
using GamingIsLove.Makinom;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Controls/Simple Move")]
	public class SimpleMove : SerializedBehaviour<SimpleMove.Settings>
	{
		// move target
		protected bool doMove = false;

		protected Vector3 targetPosition;

		protected float maxSpeed = 5;


		// movement
		protected CharacterController controller;

		protected Rigidbody2D rigidbody2DComponent;

		protected Vector3 moveDirection;

		protected float moveSpeed = 0;

		protected virtual void Start()
		{
			this.controller = this.transform.root.GetComponent<CharacterController>();
			this.rigidbody2DComponent = this.transform.root.GetComponent<Rigidbody2D>();
		}

		protected virtual void Update()
		{
			if(this.doMove)
			{
				float delta = Maki.Game.DeltaTime;

				if(this.settings.faceTarget)
				{
					if(this.settings.ignoreRotation.x)
					{
						this.targetPosition.x = this.transform.position.x;
					}
					if(this.settings.ignoreRotation.y)
					{
						this.targetPosition.y = this.transform.position.y;
					}
					if(this.settings.ignoreRotation.z)
					{
						this.targetPosition.z = this.transform.position.z;
					}

					if(this.rigidbody2DComponent != null)
					{
						this.moveDirection = VectorHelper.GetDirection(this.transform.position, this.targetPosition).normalized;
						Vector3 rotation = this.transform.eulerAngles;
						rotation.z = VectorHelper.DirectionToAngle(this.moveDirection, Maki.GameSettings.horizontalPlane);

						if(this.settings.smooth &&
							this.settings.rotationDamping > 0)
						{
							this.transform.rotation = Quaternion.Slerp(this.transform.rotation, Quaternion.Euler(rotation),
								this.settings.rotationDamping * delta);
						}
						else
						{
							this.transform.eulerAngles = rotation;
						}
					}
					else
					{
						if(this.settings.smooth &&
							this.settings.rotationDamping > 0)
						{
							this.transform.rotation = Quaternion.Slerp(this.transform.rotation,
								Quaternion.LookRotation(this.targetPosition - this.transform.position),
								this.settings.rotationDamping * delta);
						}
						else
						{
							this.transform.LookAt(this.targetPosition);
						}

						this.moveDirection = this.transform.TransformDirection(Vector3.forward);
					}
				}
				else
				{
					this.moveDirection = VectorHelper.GetDirection(this.transform.position, this.targetPosition).normalized;
				}

				if(this.settings.smooth)
				{
					this.moveSpeed = Mathf.Lerp(this.moveSpeed, this.maxSpeed, this.settings.speedSmoothing * delta);
				}
				else
				{
					this.moveSpeed = this.maxSpeed;
				}

				if(this.controller != null)
				{
					this.controller.Move((this.moveDirection * this.moveSpeed + Physics.gravity) * delta);
				}
				else if(this.rigidbody2DComponent != null)
				{
					this.rigidbody2DComponent.velocity = this.moveDirection * this.moveSpeed;
				}
				else
				{
					this.transform.Translate(this.moveDirection * this.moveSpeed * delta, Space.World);
				}
			}
		}


		/*
		============================================================================
		Move functions
		============================================================================
		*/
		public virtual void Move(Vector3 change)
		{
			this.doMove = false;
			if(this.controller != null)
			{
				this.controller.Move(change);
			}
			else if(this.rigidbody2DComponent != null)
			{
				this.rigidbody2DComponent.velocity = change;
			}
			else
			{
				this.transform.Translate(change, Space.World);
			}
		}

		public virtual void MoveTo(float speed, Vector3 position)
		{
			this.maxSpeed = speed;
			this.targetPosition = position;
			this.doMove = true;
		}

		public virtual void SetPosition(Vector3 position)
		{
			this.doMove = false;
			this.transform.position = position;
		}

		public virtual void Stop()
		{
			this.doMove = false;
			if(this.controller != null)
			{
				this.controller.Move(Vector3.zero);
			}
			else if(this.rigidbody2DComponent != null)
			{
				this.rigidbody2DComponent.velocity = Vector2.zero;
			}
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Face Target", "Rotate to the target position.\n" +
				"Use 'Ignore Rotation' to manage which axes don't rotate.\n" +
				"For 2D movement (using a 'Rigidbody 2D' component) only rotates on the Z-axis.")]
			public bool faceTarget = true;

			[EditorHelp("Ignore Rotation", "Enable the axes that will be ignored for rotations.")]
			[EditorCondition("faceTarget", true)]
			[EditorEndCondition]
			public AxisBool ignoreRotation = new AxisBool();


			// smoothing
			[EditorHelp("Smooth", "Smooth rotations and movement.")]
			[EditorSeparator]
			public bool smooth = true;

			[EditorHelp("Speed Smoothing", "The speed smothing that will be used.\n" +
				"Lower value means higher smoothing.")]
			[EditorIndent]
			[EditorCondition("smooth", true)]
			public float speedSmoothing = 10;

			[EditorHelp("Rotation Damping", "The rotation damping that will be used.\n" +
				"Lower value means higher damping.")]
			[EditorIndent]
			[EditorCondition("faceTarget", true)]
			[EditorEndCondition(2)]
			public float rotationDamping = 6.0f;

			public Settings()
			{

			}
		}
	}
}
