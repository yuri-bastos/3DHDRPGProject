
using UnityEngine;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Place On Ground")]
	public class PlaceOnGround : SerializedBehaviour<PlaceOnGround.Settings>
	{
		protected virtual void Start()
		{
			this.Place();
		}

		public virtual void Place()
		{
			RaycastOutput hit;
			if(RaycastHelper.Raycast(Maki.GameSettings.raycastType,
				transform.position, -Vector3.up, out hit, this.settings.distance, this.settings.layerMask))
			{
				transform.position = hit.point + this.settings.offset;
			}
		}

		protected virtual void OnDrawGizmos()
		{
			Gizmos.DrawIcon(transform.position, "/GamingIsLove/Makinom/Components/PlaceOnGround Icon.png");
		}


		/*
		============================================================================
		Settings class
		============================================================================
		*/
		public class Settings : BaseData
		{
			[EditorHelp("Distance", "The distance used for the raycast.")]
			public float distance = 100.0f;

			[EditorHelp("Layer Mask", "Select the layers that will be hit by the raycast.")]
			public LayerMask layerMask = -1;

			[EditorHelp("Offset", "The offset that will be added to the hit ground position.")]
			public Vector3 offset = Vector3.zero;

			public Settings()
			{

			}
		}
	}
}