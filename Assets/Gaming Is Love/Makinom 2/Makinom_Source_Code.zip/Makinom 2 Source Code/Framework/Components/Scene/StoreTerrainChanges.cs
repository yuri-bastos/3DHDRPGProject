
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("Makinom/Scenes/Store Terrain Changes")]
	public class StoreTerrainChanges : MonoBehaviour
	{
		public string objectID = "";

		protected virtual void Start()
		{
			Terrain terrain = this.GetComponent<Terrain>();
			if(terrain != null)
			{
				TerrainDataChanges changes = Maki.Game.Scene.GetTerrainChanges(this.objectID);
				if(changes != null)
				{
					if(changes.HeightMap != null)
					{
						Maki.Handler.TerrainHeightMapChange(terrain.terrainData);
						terrain.terrainData.SetHeights(0, 0, changes.HeightMap);
					}
					if(changes.AlphaMap != null)
					{
						Maki.Handler.TerrainAlphaMapChange(terrain.terrainData);
						terrain.terrainData.SetAlphamaps(0, 0, changes.AlphaMap);
					}
				}
			}
		}

		public virtual void StoreTerrainHeightMap(TerrainData terrainData)
		{
			TerrainDataChanges changes = Maki.Game.Scene.GetTerrainChanges(this.objectID);
			if(changes != null)
			{
				changes.HeightMap = terrainData.GetHeights(0, 0,
					terrainData.heightmapResolution, terrainData.heightmapResolution);
			}
		}

		public virtual void StoreTerrainAlphaMap(TerrainData terrainData)
		{
			TerrainDataChanges changes = Maki.Game.Scene.GetTerrainChanges(this.objectID);
			if(changes != null)
			{
				changes.AlphaMap = terrainData.GetAlphamaps(0, 0,
					terrainData.alphamapWidth, terrainData.alphamapHeight);
			}
		}
	}
}
