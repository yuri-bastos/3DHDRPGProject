
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Components
{
	[AddComponentMenu("")]
	public class CameraMoverComponent : MonoBehaviour
	{
		protected Camera camComp;

		protected float time;

		protected float time2;

		protected GetFloat deltaTime;

		protected bool inPause = false;


		// mover
		protected bool running = false;

		protected CameraPositionAsset camPos;

		protected Transform target;

		protected Interpolation.FloatInstance interpolateFoV;

		protected Interpolation.Vector3Instance interpolatePosition;

		protected Interpolation.QuaternionInstance interpolateRotation;


		// rotater
		protected bool rotating = false;

		protected float rotateSpeed = 0;

		protected Vector3 rotationAxis = Vector3.zero;

		public virtual void Stop()
		{
			this.inPause = false;
			this.running = false;
			this.rotating = false;
			this.deltaTime = null;
			this.interpolateFoV = null;
			this.interpolatePosition = null;
			this.interpolateRotation = null;
		}

		public virtual void SetTargetData(CameraPositionAsset cp, Camera camera, Transform target,
			Interpolation interpolation, float time, GetFloat deltaTime, bool inPause)
		{
			this.Stop();

			if(cp.Settings.setPosition ||
				cp.Settings.setRotation ||
				cp.Settings.setFoV)
			{
				this.deltaTime = deltaTime;
				this.inPause = inPause;
				this.camPos = cp;
				this.camComp = camera;
				this.target = target;

				Transform tmp = new GameObject().transform;
				tmp.SetPositionAndRotation(this.camComp.transform.position, this.camComp.transform.rotation);
				this.camPos.Settings.Use(tmp, this.target);

				if(this.camPos.Settings.setFoV)
				{
					this.interpolateFoV = interpolation.CreateFloat(
						this.camComp.fieldOfView, this.camPos.Settings.fieldOfView, time);
				}
				if(this.camPos.Settings.setPosition)
				{
					this.interpolatePosition = interpolation.CreateVector3(
						this.camComp.transform.position, tmp.position, time);
				}
				if(this.camPos.Settings.setRotation)
				{
					this.interpolateRotation = interpolation.CreateQuaternion(
						this.camComp.transform.rotation, tmp.rotation, time);
				}

				UnityWrapper.Destroy(tmp.gameObject);

				this.running = true;
				this.enabled = true;
			}
		}

		public virtual void SetTargetData(Vector3 pos, Quaternion rot, float fov, Camera camera,
			Interpolation interpolation, float time, GetFloat deltaTime, bool inPause)
		{
			this.Stop();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.camComp = camera;
			this.camPos = null;

			this.interpolateFoV = interpolation.CreateFloat(
				this.camComp.fieldOfView, fov, time);
			this.interpolatePosition = interpolation.CreateVector3(
				this.camComp.transform.position, pos, time);
			this.interpolateRotation = interpolation.CreateQuaternion(
				this.camComp.transform.rotation, rot, time);

			this.running = true;
			this.enabled = true;
		}

		public virtual void CameraRotate(Camera camera, Transform target, Vector3 axes,
			float t, float speed, GetFloat deltaTime, bool inPause)
		{
			this.Stop();

			this.deltaTime = deltaTime;
			this.inPause = inPause;
			this.camComp = camera;
			this.target = target;
			this.rotationAxis = axes;
			this.time = 0;
			this.time2 = t;
			this.rotateSpeed = speed;

			this.rotating = true;
			this.enabled = true;
		}

		protected virtual void Update()
		{
			if(this.camComp != null &&
				(this.inPause || !Maki.Game.Paused))
			{
				if(this.running)
				{
					float deltaTime = this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();

					if(this.interpolatePosition != null)
					{
						this.camComp.transform.position = this.interpolatePosition.Tick(deltaTime);
					}
					if(this.interpolateFoV != null)
					{
						this.camComp.fieldOfView = this.interpolateFoV.Tick(deltaTime);
					}
					if(this.interpolateRotation != null)
					{
						this.camComp.transform.rotation = this.interpolateRotation.Tick(deltaTime);
					}

					if((this.interpolatePosition != null  && this.interpolatePosition.Finished) ||
						(this.interpolateRotation != null && this.interpolateRotation.Finished) ||
						(this.interpolateFoV != null && this.interpolateFoV.Finished))
					{
						this.running = false;
						this.enabled = false;
					}
				}
				else if(this.rotating)
				{
					if(this.target != null)
					{
						float t = this.deltaTime == null ? Maki.Game.DeltaTime : this.deltaTime();
						this.time += t;
						this.camComp.transform.RotateAround(this.target.position, this.rotationAxis, this.rotateSpeed * t);
						if(this.time >= this.time2)
						{
							this.rotating = false;
							this.enabled = false;
						}
					}
					else
					{
						this.rotating = false;
						this.enabled = false;
					}
				}
			}
		}
	}
}
