﻿
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	public abstract class MakinomFullViewEditor
	{
		protected MakinomEditorWindow parent;

		protected BaseEditor baseEditor;

		public MakinomFullViewEditor(MakinomEditorWindow parent)
		{
			this.parent = parent;
			this.baseEditor = new BaseEditor(false, this.parent.Repaint);
		}

		public virtual bool ShowGUI()
		{
			this.baseEditor.ClearShow();
			return false;
		}
	}
}
