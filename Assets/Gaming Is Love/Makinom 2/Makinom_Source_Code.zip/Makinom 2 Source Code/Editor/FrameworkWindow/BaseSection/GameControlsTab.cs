
using GamingIsLove.Makinom;
using UnityEngine;
using UnityEditor;

namespace GamingIsLove.Makinom.Editor
{
	public class GameControlsTab : BaseEditorTab
	{
		public GameControlsTab(MakinomEditorWindow parent)
		{
			this.parent = parent;

			this.DefaultSetup();
		}

		public override void DefaultSetup()
		{
			if(Maki.Data.ProjectAsset.IsEmpty)
			{
				Maki.GameControls.interaction.interactKey.Source.EditorAsset = Maki.InputKeys.GetAsset(2);
			}
		}


		/*
		============================================================================
		Properties
		============================================================================
		*/
		public override string Name
		{
			get { return "Game Controls"; }
		}

		public override string HelpText
		{
			get { return "Change basic game control, interaction and object selection settings."; }
		}

		public override string HelpInfo
		{
			get { return ""; }
		}

		protected override BaseSettings Settings
		{
			get { return Maki.GameControls; }
		}

		protected override IBaseData DisplayedSettings
		{
			get { return Maki.GameControls; }
		}


		/*
		============================================================================
		Settings functions
		============================================================================
		*/
		public override void ShowSettings()
		{
			base.ShowSettings();

			for(int i = 0; i < EditorContent.Extensions.Count; i++)
			{
				if(EditorContent.Extensions[i].GameControls != null)
				{
					EditorAutomation.Automate(EditorContent.Extensions[i].GameControls, this);
				}
			}
		}
	}
}

