﻿
using UnityEngine;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace GamingIsLove.Makinom.Editor
{
	[EditorSettingInfo("CSV (UTF-8)", "Import/export data as a CSV with UTF-8 formatting.")]
	public class CSV_UTF8_LanguageExportFormat : BaseLanguageExportFormat
	{
		[EditorHelp("Separator", "Separator sign used to separate IDs and language texts.")]
		public string separator = ";";

		[EditorHelp("Text Start Encloser", "Added before a language text.")]
		public string textStartEncloser = "\"";

		[EditorHelp("Text End Encloser", "Added after a language text.")]
		public string textEndEncloser = "\"";

		[EditorHelp("Include Information", "Export files will add an 'Information' column containing export information (e.g. source of the text).\n" +
			"Import files will assume the exported 'Information' column is included (will be skipped).")]
		public bool includeInformation = true;

		[EditorHelp("Include Translation Note", "Export files will add a 'Translation Node' column containing the translation nodes you defined.\n" +
			"Import files will assume the exported 'Translation Note' column is included (will be skipped).")]
		public bool includeTranslationNote = true;

		public CSV_UTF8_LanguageExportFormat()
		{

		}

		public override string GetFileExtension()
		{
			return "csv";
		}


		/*
		============================================================================
		Export functions
		============================================================================
		*/
		protected virtual string GetDefaultExport(List<LanguageData.Export> export)
		{
			StringBuilder builder = new StringBuilder();

			// format:
			// ExportID;Index;Information;Translation Note;Default Text;Language 0;Language 1;...
			// 0;0;"Content.Name";"X means Y";"Default Name";;;...

			builder.Append("ExportID").
				Append(this.separator).Append("Index");
			if(this.includeInformation)
			{
				builder.Append(this.separator).Append("Information");
			}
			if(this.includeTranslationNote)
			{
				builder.Append(this.separator).Append("Translation Note");
			}
			builder.Append(this.separator).Append("Default Text");
			for(int i = 0; i < Maki.Languages.Count; i++)
			{
				builder.Append(this.separator).Append(Maki.Languages.Get(i).GetName());
			}
			builder.Append("\n");

			for(int i = 0; i < export.Count; i++)
			{
				for(int j = 0; j < export[i].texts.Length; j++)
				{
					// export ID
					builder.Append(export[i].exportID);
					// list index
					builder.Append(this.separator).Append(j);
					// info
					if(this.includeInformation)
					{
						builder.Append(this.separator).Append(this.textStartEncloser).
							Append(export[i].info).Append(export[i].textInfos[j]).Append(this.textEndEncloser);
					}
					// translation note
					if(this.includeTranslationNote)
					{
						builder.Append(this.separator).Append(this.textStartEncloser).
							Append(export[i].translationNote).Append(this.textEndEncloser);
					}
					// languages
					for(int k = 0; k < export[i].texts[j].Length; k++)
					{
						if(string.IsNullOrEmpty(export[i].texts[j][k]))
						{
							builder.Append(this.separator);
						}
						else
						{
							if(export[i].texts[j][k].Contains("\""))
							{
								export[i].texts[j][k] = export[i].texts[j][k].Replace("\"", "\"\"");
							}
							builder.Append(this.separator).Append(this.textStartEncloser).Append(export[i].texts[j][k]).
								Append(this.textEndEncloser);
						}
					}
					builder.Append("\n");
				}
			}

			return builder.ToString();
		}

		public override void SaveExportData(string path, List<LanguageData.Export> export)
		{
			this.SaveFile(path, this.GetDefaultExport(export));
		}


		/*
		============================================================================
		Import functions
		============================================================================
		*/
		public override EditorLanguageExporter.ImportData GetImportData(string path)
		{
			string data = this.LoadFile(path);
			if(!string.IsNullOrEmpty(data))
			{
				try
				{
					data = data.Replace("\r\n", "\n").Replace("\r", "\n");

					EditorLanguageExporter.ImportData importData = new EditorLanguageExporter.ImportData();
					importData.path = path;

					// header
					int index = data.IndexOf("\n");
					string text = data.Substring(0, index);

					string[] splitData = text.Split(new string[] { this.separator }, System.StringSplitOptions.None);
					int offset = 2 + (this.includeInformation ? 1 : 0) + (this.includeTranslationNote ? 1 : 0);
					importData.language = new EditorLanguageExporter.ImportData.ImportLanguage[splitData.Length - offset];
					for(int i = 0; i < importData.language.Length; i++)
					{
						importData.language[i] = new EditorLanguageExporter.ImportData.ImportLanguage();
						importData.language[i].name = splitData[i + offset];
						if(i > 0)
						{
							importData.language[i].asset.settings.EditorAsset = Maki.Languages.Find(importData.language[i].name);
							importData.language[i].import = importData.language[i].asset.settings.EditorAsset != null;
						}
					}
					int currentIndex = index + 1;

					// data
					string textEnd = this.textEndEncloser + this.separator;
					string textEndLine = this.textEndEncloser + "\n";
					while(index >= 0 && index < data.Length)
					{
						// export ID
						index = data.IndexOf(this.separator, currentIndex);

						if(index >= 0 && index < data.Length)
						{
							int exportID = -1;
							if(int.TryParse(data.Substring(currentIndex, index - currentIndex), out exportID))
							{
								LanguageData.Import import;
								if(!importData.import.TryGetValue(exportID, out import))
								{
									import = new LanguageData.Import();
									importData.import.Add(exportID, import);
								}
								currentIndex = index + this.separator.Length;

								// text index
								index = data.IndexOf(this.separator, currentIndex);
								int textIndex = -1;
								if(int.TryParse(data.Substring(currentIndex, index - currentIndex), out textIndex))
								{
									string[] texts;
									if(!import.texts.TryGetValue(textIndex, out texts))
									{
										texts = new string[importData.language.Length];
										import.texts.Add(textIndex, texts);
									}
									currentIndex = index + this.separator.Length;

									// skip information
									if(this.includeInformation)
									{
										index = data.IndexOf(this.separator, currentIndex);
										currentIndex = index + this.separator.Length;
									}

									// skip translation note
									if(this.includeTranslationNote)
									{
										index = data.IndexOf(this.separator, currentIndex);
										currentIndex = index + this.separator.Length;
									}

									// default, language texts
									for(int i = 0; i < texts.Length; i++)
									{
										if(!string.IsNullOrEmpty(this.textStartEncloser) &&
											data.IndexOf(this.textStartEncloser, currentIndex) == currentIndex)
										{
											currentIndex += this.textStartEncloser.Length;
											index = data.IndexOf(i == texts.Length - 1 ? textEndLine : textEnd, currentIndex);
											texts[i] = data.Substring(currentIndex, index - currentIndex).Replace("\"\"", "\"");

											currentIndex = index + (i == texts.Length - 1 ? textEndLine : textEnd).Length;
										}
										else
										{
											index = data.IndexOf(i == texts.Length - 1 ? "\n" : this.separator, currentIndex);
											texts[i] = data.Substring(currentIndex, index - currentIndex).Replace("\"\"", "\"");

											currentIndex = index + (i == texts.Length - 1 ? "\n" : this.separator).Length;
										}
									}
								}
								else
								{
									Debug.LogWarning("Unexpected data while reading/importing CSV (UTF-8) language export file (expected text index).");
									index = -1;
								}
							}
							else
							{
								Debug.LogWarning("Unexpected data while reading/importing CSV (UTF-8) language export file (expected export ID).");
								index = -1;
							}
						}
					}

					return importData;
				}
				catch(System.Exception ex)
				{
					Debug.LogError("Error while reading/importing CSV (UTF-8) language export file.\n" +
						ex.Message + "\n" + ex.StackTrace);
				}
			}
			return null;
		}
	}
}
