﻿
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Collections.Generic;
using System.Reflection;
using System.IO;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorLanguageExporter : BaseData
	{
		[EditorHelp("Reset Export IDs", "Reset the export IDs of the different language texts when exporting.\n" +
			"Please note that resetting export IDs can lead to previous exports not matching current langauge texts any longer.\n" +
			"Export IDs are separate per export source (settings, scenes, prefabs, schematics) " +
			"and also only reset for the language texts that are exported by them.")]
		public bool resetExportIDs = false;

		[EditorHelp("Format", "Select how the language data is formatted:")]
		[EditorInfo(settingBaseType = typeof(BaseLanguageExportFormat), settingAutoSetup = "settings")]
		public string type = typeof(CSV_UTF8_LanguageExportFormat).ToString();

		public BaseLanguageExportFormat settings = new CSV_UTF8_LanguageExportFormat();

		public override void EditorAutoSetup(string fieldName)
		{
			if("fileSettings" == fieldName)
			{
				if(!this.settings.IsType(this.type))
				{
					DataObject data = this.settings.GetData();
					object tmpSettings = ReflectionTypeHandler.Instance.CreateInstance(
						this.type, typeof(BaseLanguageExportFormat));
					if(tmpSettings is BaseLanguageExportFormat)
					{
						this.settings = (BaseLanguageExportFormat)tmpSettings;
						this.settings.SetData(data);
					}
					else
					{
						this.settings = new CSV_UTF8_LanguageExportFormat();
						this.settings.SetData(data);
						this.type = this.settings.GetType().ToString();
					}
				}
			}
		}

		protected virtual int GetSettingsExportID()
		{
			return Maki.Languages.exportIDSettings++;
		}

		protected virtual int GetScenesExportID()
		{
			return Maki.Languages.exportIDScenes++;
		}

		protected virtual int GetPrefabsExportID()
		{
			return Maki.Languages.exportIDPrefabs++;
		}

		protected virtual int GetSchematicsExportID()
		{
			return Maki.Languages.exportIDSchematics++;
		}


		/*
		============================================================================
		Export functions
		============================================================================
		*/
		public virtual void ExportSettings(bool filePerSubSection)
		{
			if(filePerSubSection)
			{
				string path = EditorUtility.SaveFolderPanel("Save Language Export (Settings) To Folder", "", "");

				if(path.Length > 0)
				{
					if(this.resetExportIDs)
					{
						Maki.Languages.exportIDSettings = 0;
					}

					string fileExtension = "." + this.settings.GetFileExtension();
					path += "/";

					Dictionary<string, List<LanguageData.Export>> exportFiles = new Dictionary<string, List<LanguageData.Export>>();
					EditorDataHandler.Instance.GetLanguageExport(this.resetExportIDs, this.GetSettingsExportID, ref exportFiles);

					foreach(KeyValuePair<string, List<LanguageData.Export>> pair in exportFiles)
					{
						this.settings.SaveExportData(path + pair.Key + fileExtension, pair.Value);
					}

					this.ShowExportedDialogue("Settings");
				}
			}
			else
			{
				string path = EditorUtility.SaveFilePanel("Save Language Export (Settings)", "",
					"LanguageExport_Settings", this.settings.GetFileExtension());

				if(path.Length > 0)
				{
					if(this.resetExportIDs)
					{
						Maki.Languages.exportIDSettings = 0;
					}
					List<LanguageData.Export> export = new List<LanguageData.Export>();
					EditorDataHandler.Instance.GetLanguageExport(this.resetExportIDs, this.GetSettingsExportID, ref export);
					this.settings.SaveExportData(path, export);

					this.ShowExportedDialogue("Settings");
				}
			}
		}

		public virtual void ExportScenes()
		{
			string path = EditorUtility.SaveFilePanel("Save Language Export (Scenes)", "",
				"LanguageExport_Scenes", this.settings.GetFileExtension());

			if(path.Length > 0)
			{
				if(this.resetExportIDs)
				{
					Maki.Languages.exportIDScenes = 0;
				}
				List<LanguageData.Export> export = new List<LanguageData.Export>();

				// remember current scene
				string currentScene = EditorSceneManager.GetActiveScene().path;

				for(int i = 0; i < EditorBuildSettings.scenes.Length; i++)
				{
					if(EditorBuildSettings.scenes[i].enabled &&
						EditorBuildSettings.scenes[i].path != "")
					{
						string scenePath = EditorBuildSettings.scenes[i].path;
						EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
						scenePath = scenePath.Substring(scenePath.LastIndexOf("/") + 1);
						scenePath = scenePath.Substring(0, scenePath.LastIndexOf("."));

						MonoBehaviour[] behaviour = Object.FindObjectsOfType<MonoBehaviour>();
						if(behaviour != null)
						{
							for(int j = 0; j < behaviour.Length; j++)
							{
								if(behaviour[j] != null)
								{
									FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(behaviour[j].GetType());
									for(int k = 0; k < field.Length; k++)
									{
										if(typeof(IBaseData).IsAssignableFrom(field[k].FieldType))
										{
											IBaseData tmp = (IBaseData)field[k].GetValue(behaviour[j]);
											int count = export.Count;
											DataSerializer.GetLanguageExport(tmp, this.resetExportIDs,
												this.GetScenesExportID, scenePath, ref export);
											if(count != export.Count)
											{
												EditorUtility.SetDirty(behaviour[j]);
											}
										}
									}
								}
							}
						}
						EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
					}
				}

				// open remembered scene
				EditorSceneManager.OpenScene(currentScene, OpenSceneMode.Single);

				this.settings.SaveExportData(path, export);

				this.ShowExportedDialogue("Scenes");
			}
		}

		public virtual void ExportPrefabs()
		{
			string path = EditorUtility.SaveFilePanel("Save Language Export (Prefabs)", "",
				"LanguageExport_Prefabs", this.settings.GetFileExtension());

			if(path.Length > 0)
			{
				if(this.resetExportIDs)
				{
					Maki.Languages.exportIDPrefabs = 0;
				}
				List<LanguageData.Export> export = new List<LanguageData.Export>();

				List<GameObject> prefabs = MakinomAssetHelper.GetAllPrefabs();
				for(int i = 0; i < prefabs.Count; i++)
				{
					if(prefabs[i] != null)
					{
						MonoBehaviour[] behaviour = prefabs[i].GetComponentsInChildren<MonoBehaviour>();
						if(behaviour != null)
						{
							for(int j = 0; j < behaviour.Length; j++)
							{
								if(behaviour[j] != null)
								{
									FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(behaviour[j].GetType());
									for(int k = 0; k < field.Length; k++)
									{
										if(typeof(IBaseData).IsAssignableFrom(field[k].FieldType))
										{
											IBaseData tmp = (IBaseData)field[k].GetValue(behaviour[j]);
											int count = export.Count;
											DataSerializer.GetLanguageExport(tmp, this.resetExportIDs,
												this.GetPrefabsExportID, prefabs[i].name, ref export);
											if(count != export.Count)
											{
												EditorUtility.SetDirty(behaviour[j]);
											}
										}
									}
								}
							}
						}
					}
				}
				AssetDatabase.SaveAssets();
				AssetDatabase.Refresh();

				this.settings.SaveExportData(path, export);

				this.ShowExportedDialogue("Prefabs");
			}
		}

		public virtual void ExportSchematics(string folder, bool filePerSchematic)
		{
			if(filePerSchematic)
			{
				string path = EditorUtility.SaveFolderPanel("Save Language Export (Schematics) To Folder", "", "");

				if(path.Length > 0)
				{
					if(this.resetExportIDs)
					{
						Maki.Languages.exportIDSchematics = 0;
					}

					string fileExtension = "." + this.settings.GetFileExtension();
					path += "/";

					bool encrypted = false;
					DataFile.SaveFormatType format = DataFile.SaveFormatType.ByteArray;
					MakinomAssetHelper.GetSaveSettings(ref encrypted, ref format);

					AssetDatabase.Refresh();
					List<MakinomSchematicAsset> schematics = MakinomAssetHelper.GetAllAssets<MakinomSchematicAsset>(folder);
					for(int i = 0; i < schematics.Count; i++)
					{
						if(schematics[i] != null)
						{
							List<LanguageData.Export> export = new List<LanguageData.Export>();
							DataSerializer.GetLanguageExport(schematics[i].Settings, this.resetExportIDs,
								this.GetSchematicsExportID, schematics[i].name, ref export);
							if(export.Count > 0)
							{
								schematics[i].SaveData(encrypted, format);
								EditorUtility.SetDirty(schematics[i]);

								string filePath = path + AssetDatabase.GetAssetPath(schematics[i]).
									Replace("Assets/", "").
									Replace(schematics[i].name + ".asset", "");
								MakinomAssetHelper.CreateFolder(filePath);
								filePath += schematics[i].name + fileExtension;
								this.settings.SaveExportData(filePath, export);
							}
						}
					}
					AssetDatabase.SaveAssets();
					AssetDatabase.Refresh();

					this.ShowExportedDialogue("Schematics");
				}
			}
			else
			{
				string path = EditorUtility.SaveFilePanel("Save Language Export (Schematics)", "",
					"LanguageExport_Schematics", this.settings.GetFileExtension());

				if(path.Length > 0)
				{
					if(this.resetExportIDs)
					{
						Maki.Languages.exportIDSchematics = 0;
					}
					List<LanguageData.Export> export = new List<LanguageData.Export>();

					bool encrypted = false;
					DataFile.SaveFormatType format = DataFile.SaveFormatType.ByteArray;
					MakinomAssetHelper.GetSaveSettings(ref encrypted, ref format);

					AssetDatabase.Refresh();
					List<MakinomSchematicAsset> schematics = MakinomAssetHelper.GetAllAssets<MakinomSchematicAsset>(folder);
					for(int i = 0; i < schematics.Count; i++)
					{
						if(schematics[i] != null)
						{
							int count = export.Count;
							DataSerializer.GetLanguageExport(schematics[i].Settings, this.resetExportIDs,
								this.GetSchematicsExportID, schematics[i].name, ref export);
							if(count != export.Count)
							{
								schematics[i].SaveData(encrypted, format);
								EditorUtility.SetDirty(schematics[i]);
							}
						}
					}
					AssetDatabase.SaveAssets();
					AssetDatabase.Refresh();

					this.settings.SaveExportData(path, export);

					this.ShowExportedDialogue("Schematics");
				}
			}
		}

		public virtual void ExportSchematic(MakinomSchematicAsset schematic)
		{
			if(schematic != null)
			{
				string path = EditorUtility.SaveFilePanel("Save Language Export (Schematics)", "",
					"LanguageExport_Schematics_" + schematic.name, this.settings.GetFileExtension());

				if(path.Length > 0)
				{
					if(this.resetExportIDs)
					{
						Maki.Languages.exportIDSchematics = 0;
					}
					List<LanguageData.Export> export = new List<LanguageData.Export>();

					bool encrypted = false;
					DataFile.SaveFormatType format = DataFile.SaveFormatType.ByteArray;
					MakinomAssetHelper.GetSaveSettings(ref encrypted, ref format);

					AssetDatabase.Refresh();
					DataSerializer.GetLanguageExport(schematic.Settings, this.resetExportIDs,
						this.GetSchematicsExportID, schematic.name, ref export);
					if(export.Count > 0)
					{
						schematic.SaveData(encrypted, format);
						EditorUtility.SetDirty(schematic);
						this.settings.SaveExportData(path, export);

						AssetDatabase.SaveAssets();
						AssetDatabase.Refresh();

						this.ShowExportedDialogue("Schematic: " + schematic.name);
					}
					else
					{
						this.ShowNoExportedDialogue("Schematic: " + schematic.name);
					}
				}
			}
		}

		public virtual void ShowExportedDialogue(string name)
		{
			EditorUtility.DisplayDialog("Language Data Exported (" + name + ")",
				"Please save your settings to keep track of the export ID changes.", "Ok");
		}

		public virtual void ShowNoExportedDialogue(string name)
		{
			EditorUtility.DisplayDialog("No Language Data Exported (" + name + ")",
				"The exported settings didn't contain any language data.", "Ok");
		}


		/*
		============================================================================
		Import functions
		============================================================================
		*/
		public virtual ImportData LoadImportFile()
		{
			string path = EditorUtility.OpenFilePanel("Load Language Export", "", this.settings.GetFileExtension());

			if(path.Length > 0)
			{
				return this.settings.GetImportData(path);
			}
			return null;
		}

		public virtual void ImportSettings(ImportData importData)
		{
			if(importData != null)
			{
				bool[] importLanguage = new bool[importData.language.Length];
				LanguageAsset[] languageAsset = new LanguageAsset[importData.language.Length];
				for(int i = 0; i < importData.language.Length; i++)
				{
					importLanguage[i] = importData.language[i].import;
					languageAsset[i] = importData.language[i].asset;
				}
				EditorDataHandler.Instance.SetLanguageImport(importLanguage, languageAsset, importData.import);

				EditorUtility.DisplayDialog("Language Data Imported (Settings)",
					"Don't forget to save your settings to keep the imported language data.", "Ok");
			}
		}

		public virtual void ImportScenes(ImportData importData)
		{
			if(importData != null)
			{
				bool[] importLanguage = new bool[importData.language.Length];
				LanguageAsset[] languageAsset = new LanguageAsset[importData.language.Length];
				for(int i = 0; i < importData.language.Length; i++)
				{
					importLanguage[i] = importData.language[i].import;
					languageAsset[i] = importData.language[i].asset;
				}

				// remember current scene
				string currentScene = EditorSceneManager.GetActiveScene().path;

				for(int i = 0; i < EditorBuildSettings.scenes.Length; i++)
				{
					if(EditorBuildSettings.scenes[i].enabled &&
						EditorBuildSettings.scenes[i].path != "")
					{
						string scenePath = EditorBuildSettings.scenes[i].path;
						EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
						scenePath = scenePath.Substring(scenePath.LastIndexOf("/") + 1);
						scenePath = scenePath.Substring(0, scenePath.LastIndexOf("."));

						MonoBehaviour[] behaviour = Object.FindObjectsOfType<MonoBehaviour>();
						if(behaviour != null)
						{
							for(int j = 0; j < behaviour.Length; j++)
							{
								if(behaviour[j] != null)
								{
									FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(behaviour[j].GetType());
									for(int k = 0; k < field.Length; k++)
									{
										if(typeof(IBaseData).IsAssignableFrom(field[k].FieldType))
										{
											IBaseData tmp = (IBaseData)field[k].GetValue(behaviour[j]);
											bool hasImported = false;
											DataSerializer.SetLanguageImport(tmp, ref hasImported, importLanguage, languageAsset, importData.import);
											if(hasImported)
											{
												EditorUtility.SetDirty(behaviour[j]);
											}
										}
									}
								}
							}
						}
						EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
					}
				}

				// open remembered scene
				EditorSceneManager.OpenScene(currentScene, OpenSceneMode.Single);
			}
		}

		public virtual void ImportPrefabs(ImportData importData)
		{
			if(importData != null)
			{
				bool[] importLanguage = new bool[importData.language.Length];
				LanguageAsset[] languageAsset = new LanguageAsset[importData.language.Length];
				for(int i = 0; i < importData.language.Length; i++)
				{
					importLanguage[i] = importData.language[i].import;
					languageAsset[i] = importData.language[i].asset;
				}

				List<GameObject> prefabs = MakinomAssetHelper.GetAllPrefabs();
				for(int i = 0; i < prefabs.Count; i++)
				{
					if(prefabs[i] != null)
					{
						MonoBehaviour[] behaviour = prefabs[i].GetComponentsInChildren<MonoBehaviour>();
						if(behaviour != null)
						{
							for(int j = 0; j < behaviour.Length; j++)
							{
								if(behaviour[j] != null)
								{
									FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(behaviour[j].GetType());
									for(int k = 0; k < field.Length; k++)
									{
										if(typeof(IBaseData).IsAssignableFrom(field[k].FieldType))
										{
											IBaseData tmp = (IBaseData)field[k].GetValue(behaviour[j]);
											bool hasImported = false;
											DataSerializer.SetLanguageImport(tmp, ref hasImported, importLanguage, languageAsset, importData.import);
											if(hasImported)
											{
												EditorUtility.SetDirty(behaviour[j]);
											}
										}
									}
								}
							}
						}
					}
				}
				AssetDatabase.SaveAssets();
				AssetDatabase.Refresh();
			}
		}

		public virtual void ImportSchematics(ImportData importData, string folder)
		{
			if(importData != null)
			{
				bool[] importLanguage = new bool[importData.language.Length];
				LanguageAsset[] languageAsset = new LanguageAsset[importData.language.Length];
				for(int i = 0; i < importData.language.Length; i++)
				{
					importLanguage[i] = importData.language[i].import;
					languageAsset[i] = importData.language[i].asset;
				}

				bool encrypted = false;
				DataFile.SaveFormatType format = DataFile.SaveFormatType.ByteArray;
				MakinomAssetHelper.GetSaveSettings(ref encrypted, ref format);

				AssetDatabase.Refresh();
				List<MakinomSchematicAsset> schematics = MakinomAssetHelper.GetAllAssets<MakinomSchematicAsset>(folder);
				for(int i = 0; i < schematics.Count; i++)
				{
					if(schematics[i] != null)
					{
						bool hasImported = false;
						DataSerializer.SetLanguageImport(schematics[i].Settings, ref hasImported, importLanguage, languageAsset, importData.import);
						if(hasImported)
						{
							schematics[i].SaveData(encrypted, format);
							EditorUtility.SetDirty(schematics[i]);
						}
					}
				}
				AssetDatabase.SaveAssets();
				AssetDatabase.Refresh();
			}
		}

		public virtual void ImportSchematic(ImportData importData, MakinomSchematicAsset schematic)
		{
			if(importData != null &&
				schematic != null)
			{
				bool[] importLanguage = new bool[importData.language.Length];
				LanguageAsset[] languageAsset = new LanguageAsset[importData.language.Length];
				for(int i = 0; i < importData.language.Length; i++)
				{
					importLanguage[i] = importData.language[i].import;
					languageAsset[i] = importData.language[i].asset;
				}

				bool encrypted = false;
				DataFile.SaveFormatType format = DataFile.SaveFormatType.ByteArray;
				MakinomAssetHelper.GetSaveSettings(ref encrypted, ref format);

				AssetDatabase.Refresh();
				bool hasImported = false;
				DataSerializer.SetLanguageImport(schematic.Settings, ref hasImported, importLanguage, languageAsset, importData.import);
				if(hasImported)
				{
					schematic.SaveData(encrypted, format);
					EditorUtility.SetDirty(schematic);
					AssetDatabase.SaveAssets();
					AssetDatabase.Refresh();
				}
			}
		}

		public class ImportData
		{
			public string path = "";

			public ImportLanguage[] language;

			public Dictionary<int, LanguageData.Import> import = new Dictionary<int, LanguageData.Import>();

			public ImportData()
			{

			}

			public class ImportLanguage : BaseData
			{
				[EditorHide]
				public string name = "";

				[EditorHide]
				public bool import = false;

				[EditorHelp("Language", "Select the language this language data will be imported for.")]
				public AssetSelection<LanguageAsset> asset = new AssetSelection<LanguageAsset>();
			}
		}
	}
}
