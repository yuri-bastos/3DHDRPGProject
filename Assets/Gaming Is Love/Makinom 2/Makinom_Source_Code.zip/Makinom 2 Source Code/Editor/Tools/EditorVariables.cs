
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using GamingIsLove.Makinom.Schematics;
using GamingIsLove.Makinom.Components;
using System.IO;
using System.Collections.Generic;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	public class EditorVariables
	{
		private static EditorVariables instance;

		private static System.Object instanceLock = new System.Object();


		// variable lists
		public List<string> defined = new List<string>();

		public List<string> foundEditor = new List<string>();

		public List<MakinomEditorAsset.SceneVariables> foundScene = new List<MakinomEditorAsset.SceneVariables>();

		public List<string> foundPrefab = new List<string>();

		public Dictionary<string, List<GameObject>> keyPrefab = new Dictionary<string, List<GameObject>>();

		public List<string> foundSchematic = new List<string>();

		public Dictionary<string, List<MakinomSchematicAsset>> keySchematic = new Dictionary<string, List<MakinomSchematicAsset>>();

		public List<string> temporary = new List<string>();


		/*
		============================================================================
		Init functions
		============================================================================
		*/
		private EditorVariables()
		{
			if(instance != null)
			{
				Debug.LogError("You can't create two instances of EditorVariables!");
			}
			else
			{
				instance = this;
				instance.LoadVariables();
			}
		}

		public static EditorVariables Instance
		{
			get
			{
				if(instance == null)
				{
					lock(instanceLock)
					{
						if(instance == null)
						{
							new EditorVariables();
						}
					}
				}
				return instance;
			}
		}


		/*
		============================================================================
		File functions
		============================================================================
		*/
		public void LoadVariables()
		{
			this.temporary.Clear();
			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;

			this.defined = editorAsset.VariablesDefined;
			this.foundEditor = editorAsset.VariablesEditor;
			this.foundScene = editorAsset.VariablesScene;
			this.foundPrefab = editorAsset.VariablesPrefab;
			this.foundSchematic = editorAsset.VariablesSchematic;
		}

		public void SaveVariables(MakinomEditorAsset editorAsset)
		{
			this.temporary.Clear();
			editorAsset.VariablesDefined = this.defined;
			editorAsset.VariablesEditor = this.foundEditor;
			editorAsset.VariablesScene = this.foundScene;
			editorAsset.VariablesPrefab = this.foundPrefab;
			editorAsset.VariablesSchematic = this.foundSchematic;
		}


		/*
		============================================================================
		Update functions
		============================================================================
		*/
		public void UpdateSettings(bool saveAsset)
		{
			this.foundEditor.Clear();
			EditorDataHandler.Instance.GetVariables(ref this.foundEditor);
			this.foundEditor.Sort();

			if(saveAsset)
			{
				MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
				editorAsset.VariablesEditor = this.foundEditor;
				MakinomAssetHelper.SaveEditorAsset(editorAsset);
			}
		}

		public void UpdateSchematic(SchematicSettings schematic)
		{
			DataSerializer.GetVariables(schematic, ref this.foundSchematic);

			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
			editorAsset.VariablesSchematic = this.foundSchematic;
			MakinomAssetHelper.SaveEditorAsset(editorAsset);
		}

		public void UpdateSchematics(string folder)
		{
			this.foundSchematic.Clear();
			this.keySchematic.Clear();
			MakinomAssetHelper.GetSchematicVariables(ref this.foundSchematic, ref this.keySchematic, folder);
			this.foundSchematic.Sort();

			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
			editorAsset.VariablesSchematic = this.foundSchematic;
			MakinomAssetHelper.SaveEditorAsset(editorAsset);
		}

		public void UpdateScenes()
		{
			this.foundScene.Clear();

			// remember current scene
			string path = EditorSceneManager.GetActiveScene().path;

			for(int i = 0; i < EditorBuildSettings.scenes.Length; i++)
			{
				if(EditorBuildSettings.scenes[i].enabled &&
					EditorBuildSettings.scenes[i].path != "")
				{
					this.ScanScene(EditorBuildSettings.scenes[i].path);
				}
			}

			// open remembered scene
			EditorSceneManager.OpenScene(path, OpenSceneMode.Single);

			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
			editorAsset.VariablesScene = this.foundScene;
			MakinomAssetHelper.SaveEditorAsset(editorAsset);
		}

		private void ScanScene(string path)
		{
			EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
			path = path.Substring(path.LastIndexOf("/") + 1);
			path = path.Substring(0, path.LastIndexOf("."));

			MakinomEditorAsset.SceneVariables tmpList = new MakinomEditorAsset.SceneVariables(path);

			MonoBehaviour[] behaviour = Object.FindObjectsOfType<MonoBehaviour>();
			if(behaviour != null)
			{
				for(int j = 0; j < behaviour.Length; j++)
				{
					if(behaviour[j] != null)
					{
						FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(behaviour[j].GetType());
						for(int k = 0; k < field.Length; k++)
						{
							if(typeof(IBaseData).IsAssignableFrom(field[k].FieldType))
							{
								DataSerializer.GetVariables((IBaseData)field[k].GetValue(behaviour[j]), ref tmpList.variables);
							}
						}
					}
				}
			}

			if(tmpList.variables.Count > 0)
			{
				this.foundScene.Add(tmpList);
			}
		}

		public void UpdatePrefabs()
		{
			this.foundPrefab.Clear();
			this.keyPrefab.Clear();

			List<GameObject> prefabs = MakinomAssetHelper.GetAllPrefabs();
			for(int i = 0; i < prefabs.Count; i++)
			{
				if(prefabs[i] != null)
				{
					List<string> tmpList = new List<string>();

					MonoBehaviour[] behaviour = prefabs[i].GetComponentsInChildren<MonoBehaviour>();
					if(behaviour != null)
					{
						for(int j = 0; j < behaviour.Length; j++)
						{
							if(behaviour[j] != null)
							{
								FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(behaviour[j].GetType());
								for(int k = 0; k < field.Length; k++)
								{
									if(typeof(IBaseData).IsAssignableFrom(field[k].FieldType))
									{
										DataSerializer.GetVariables((IBaseData)field[k].GetValue(behaviour[j]), ref tmpList);
									}
								}
							}
						}
					}

					for(int j = 0; j < tmpList.Count; j++)
					{
						if(!this.foundPrefab.Contains(tmpList[j]))
						{
							this.foundPrefab.Add(tmpList[j]);
						}
						List<GameObject> prefabList;
						if(!this.keyPrefab.TryGetValue(tmpList[j], out prefabList))
						{
							prefabList = new List<GameObject>();
							this.keyPrefab.Add(tmpList[j], prefabList);
						}
						prefabList.Add(prefabs[j]);
					}
				}
			}

			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
			editorAsset.VariablesPrefab = this.foundPrefab;
			MakinomAssetHelper.SaveEditorAsset(editorAsset);
		}


		/*
		============================================================================
		GUI field functions
		============================================================================
		*/
		public List<string> Find(string value)
		{
			List<string> list = new List<string>();
			// defined variables
			for(int i = 0; i < this.defined.Count; i++)
			{
				if(this.defined[i].IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0)
				{
					list.Add(this.defined[i]);
				}
			}
			// editor variables
			for(int i = 0; i < this.foundEditor.Count; i++)
			{
				if(!list.Contains(this.foundEditor[i]) &&
					this.foundEditor[i].IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0)
				{
					list.Add(this.foundEditor[i]);
				}
			}
			// scene variables
			for(int i = 0; i < this.foundScene.Count; i++)
			{
				for(int j = 0; j < this.foundScene[i].variables.Count; j++)
				{
					if(!list.Contains(this.foundScene[i].variables[j]) &&
						this.foundScene[i].variables[j].IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0)
					{
						list.Add(this.foundScene[i].variables[j]);
					}
				}
			}
			// schematic variables
			for(int i = 0; i < this.foundSchematic.Count; i++)
			{
				if(!list.Contains(this.foundSchematic[i]) &&
					this.foundSchematic[i].IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0)
				{
					list.Add(this.foundSchematic[i]);
				}
			}
			// temporary variables
			for(int i = 0; i < this.temporary.Count; i++)
			{
				if(!list.Contains(this.temporary[i]) &&
					this.temporary[i].IndexOf(value, System.StringComparison.OrdinalIgnoreCase) >= 0)
				{
					list.Add(this.temporary[i]);
				}
			}
			list.Sort();
			return list;
		}


		/*
		============================================================================
		Replace functions
		============================================================================
		*/
		public void ReplaceVariable(string oldKey, string newKey,
			bool replaceInSettings, bool replaceInScenes, bool replaceOnPrefabs,
			bool replaceInSchematics, string schematicFolder)
		{
			// replace in settings
			if(replaceInSettings)
			{
				EditorDataHandler.Instance.ReplaceVariable(oldKey, newKey);

				this.UpdateSettings(true);
			}
			// replace in scenes
			if(replaceInScenes)
			{
				this.foundScene.Clear();

				// remember current scene
				string path = EditorSceneManager.GetActiveScene().path;

				for(int i = 0; i < EditorBuildSettings.scenes.Length; i++)
				{
					if(EditorBuildSettings.scenes[i].enabled &&
						EditorBuildSettings.scenes[i].path != "")
					{
						this.ReplaceInScene(EditorBuildSettings.scenes[i].path, oldKey, newKey);
					}
				}

				// open remembered scene
				EditorSceneManager.OpenScene(path, OpenSceneMode.Single);

				MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
				editorAsset.VariablesScene = this.foundScene;
				MakinomAssetHelper.SaveEditorAsset(editorAsset);
			}
			// replace on prefabs)
			if(replaceOnPrefabs)
			{
				this.ReplaceOnPrefabs(oldKey, newKey);

				MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
				editorAsset.VariablesPrefab = this.foundPrefab;
				MakinomAssetHelper.SaveEditorAsset(editorAsset);
			}
			// replace in schematics
			if(replaceInSchematics)
			{
				this.foundSchematic.Clear();
				this.keySchematic.Clear();
				MakinomAssetHelper.ReplaceSchematicVariable(oldKey, newKey,
					ref this.foundSchematic, ref this.keySchematic, schematicFolder);
				this.foundSchematic.Sort();

				MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
				editorAsset.VariablesSchematic = this.foundSchematic;
				MakinomAssetHelper.SaveEditorAsset(editorAsset);
			}
		}

		private void ReplaceInScene(string path, string oldKey, string newKey)
		{
			EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
			path = path.Substring(path.LastIndexOf("/") + 1);
			path = path.Substring(0, path.LastIndexOf("."));

			MakinomEditorAsset.SceneVariables tmpList = new MakinomEditorAsset.SceneVariables(path);

			bool changed = false;
			MonoBehaviour[] behaviour = Object.FindObjectsOfType<MonoBehaviour>();
			if(behaviour != null)
			{
				for(int j = 0; j < behaviour.Length; j++)
				{
					if(behaviour[j] != null)
					{
						FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(behaviour[j].GetType());
						for(int k = 0; k < field.Length; k++)
						{
							if(typeof(IBaseData).IsAssignableFrom(field[k].FieldType))
							{
								IBaseData tmp = (IBaseData)field[k].GetValue(behaviour[j]);
								if(DataSerializer.ReplaceVariable(tmp, oldKey, newKey))
								{
									changed = true;
									EditorUtility.SetDirty(behaviour[j]);
								}
								DataSerializer.GetVariables(tmp, ref tmpList.variables);
							}
						}
					}
				}
			}

			if(changed)
			{
				EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
			}

			if(tmpList.variables.Count > 0)
			{
				this.foundScene.Add(tmpList);
			}
		}

		private void ReplaceOnPrefabs(string oldKey, string newKey)
		{
			this.foundPrefab.Clear();
			this.keyPrefab.Clear();

			List<GameObject> prefabs = MakinomAssetHelper.GetAllPrefabs();
			for(int i = 0; i < prefabs.Count; i++)
			{
				if(prefabs[i] != null)
				{
					List<string> tmpList = new List<string>();

					MonoBehaviour[] behaviour = prefabs[i].GetComponentsInChildren<MonoBehaviour>();
					if(behaviour != null)
					{
						for(int j = 0; j < behaviour.Length; j++)
						{
							if(behaviour[j] != null)
							{
								FieldInfo[] field = ReflectionTypeHandler.Instance.GetFields(behaviour[j].GetType());
								for(int k = 0; k < field.Length; k++)
								{
									if(typeof(IBaseData).IsAssignableFrom(field[k].FieldType))
									{
										IBaseData tmp = (IBaseData)field[k].GetValue(behaviour[j]);
										if(DataSerializer.ReplaceVariable(tmp, oldKey, newKey))
										{
											EditorUtility.SetDirty(behaviour[j]);
										}
										DataSerializer.GetVariables(tmp, ref tmpList);
									}
								}
							}
						}
					}

					for(int j = 0; j < tmpList.Count; j++)
					{
						if(!this.foundPrefab.Contains(tmpList[j]))
						{
							this.foundPrefab.Add(tmpList[j]);
						}
						List<GameObject> prefabList;
						if(!this.keyPrefab.TryGetValue(tmpList[j], out prefabList))
						{
							prefabList = new List<GameObject>();
							this.keyPrefab.Add(tmpList[j], prefabList);
						}
						prefabList.Add(prefabs[j]);
					}
				}
			}

			MakinomEditorAsset editorAsset = EditorDataHandler.Instance.EditorAsset;
			editorAsset.VariablesPrefab = this.foundPrefab;
			MakinomAssetHelper.SaveEditorAsset(editorAsset);
		}
	}
}
