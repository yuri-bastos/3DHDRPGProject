
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using GamingIsLove.Makinom.Schematics;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(TaggedMachineComponent))]
public class TaggedMachineInspector : BaseMachineInspector
{
	public override void OnInspectorGUI()
	{
		this.MachineSetup(target as TaggedMachineComponent);
	}

	private void MachineSetup(TaggedMachineComponent target)
	{
		serializedObject.Update();
		Undo.RecordObject(target, "Change to 'Tagged Machine' on " + target.name);
		this.BaseInit(true);

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.BaseMachineSetup(target);

		this.EndSetup();
	}
}
