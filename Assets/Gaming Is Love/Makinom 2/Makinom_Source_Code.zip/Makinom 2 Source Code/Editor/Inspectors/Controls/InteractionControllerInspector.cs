
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;

namespace GamingIsLove.Makinom.Editor
{
	[CustomEditor(typeof(InteractionController))]
	public class InteractionControllerInspector : BaseInspector
	{
		public override void OnInspectorGUI()
		{
			this.ShowSettings(target as InteractionController);
		}

		private void ShowSettings(InteractionController target)
		{
			if(Application.isPlaying)
			{
				EditorGUILayout.LabelField("Available Interactions", target.AvailableCount.ToString());
				EditorGUILayout.Separator();
			}

			if(target.settings.interactWithNearest)
			{
				EditorGUILayout.HelpBox("The interaction nearest to the interaction controller's position + offset is used.\n" +
					"The position offset is in local space.",
					MessageType.Info, true);
			}
			else
			{
				EditorGUILayout.HelpBox("The first interaction that entered the interaction controller is used.",
					MessageType.Info, true);
			}

			this.ShowSettings(target.settings, false);
		}
	}
}
