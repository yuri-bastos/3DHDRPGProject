﻿
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[CustomEditor(typeof(GameObjectManager))]
public class GameObjectManagerInspector : BaseInspector
{
	public override void OnInspectorGUI()
	{
		this.ComponentSetup(target as GameObjectManager);
	}

	private void ComponentSetup(GameObjectManager target)
	{
		serializedObject.Update();
		Undo.RecordObject(target, "Change to 'Game Object Manager' on " + target.name);
		this.BaseInit(true);

		this.ShowSerializedProperty("notes");

		EditorGUILayout.HelpBox("Enables or disables added game objects based on the defined conditions.\n" +
			"The game objects need to already be placed in your scenes.\n" +
			"The 'Game Object Manager' doesn't work if itself is disabled.",
			MessageType.Info);

		this.ShowSerializedProperty("gameObjects");

		EditorAutomation.Automate(target.settings, this.baseEditor);

		this.EndSetup();
	}
}