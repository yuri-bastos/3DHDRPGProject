
using GamingIsLove.Makinom;
using GamingIsLove.Makinom.Editor;
using GamingIsLove.Makinom.Components;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

namespace GamingIsLove.Makinom.Editor
{
	[CustomEditor(typeof(ObjectVariablesComponent))]
	public class ObjectVariablesComponentInspector : BaseInspector
	{
		public override void OnInspectorGUI()
		{
			this.ComponentSetup(target as ObjectVariablesComponent);
		}

		private void ComponentSetup(ObjectVariablesComponent target)
		{
			if(target.settings.isLocal)
			{
				GUILayout.TextArea("Local variables are only available as long as the object exists " +
					"and can't be shared between multiple objects.");
			}
			else
			{
				GUILayout.TextArea("The object ID is used to keep track of object variables.\n" +
					"If game objects share the same ID, their variables will also be shared.\n" +
					"The object ID is used game-wide, i.e. also in different scenes.");
			}

			this.ShowSettings(target.settings, true);

			// show variables while playing
			if(Application.isPlaying)
			{
				this.baseEditor.VariableEditor.Show(target.Handler);
			}
		}
	}
}
