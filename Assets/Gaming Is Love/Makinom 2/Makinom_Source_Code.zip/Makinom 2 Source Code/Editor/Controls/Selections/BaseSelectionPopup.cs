﻿
using UnityEngine;
using UnityEditor;
using UnityEditor.AnimatedValues;
using UnityEditor.IMGUI.Controls;
using System.Collections.Generic;
using System;
using System.Reflection;

namespace GamingIsLove.Makinom.Editor
{
	public abstract class BaseSelectionPopup : PopupWindowContent
	{
		protected static float WIDTH = 250;

		protected BaseEditor baseEditor;

		protected string name = "";

		protected List<Element> tree;

		protected List<Element> displayList = new List<Element>();

		protected Element header;


		// animation
		protected AnimFloat animation = new AnimFloat(0);

		protected List<Element> previousList = new List<Element>();

		protected Element previousHeader;


		// input
		protected int index = -1;

		protected int selectedIndex = -1;

		protected bool mouseMoved = false;

		protected bool holdingArrowKey = false;

		protected float holdTimeout = 0;

		protected bool isClosing = false;


		// search field
		protected SearchField searchField = new SearchField();

		protected string lastSearch = "";

		protected string search = "";


		// gui
		protected Vector2 scroll = Vector2.zero;

		protected bool topMode = false;

		protected Vector2 callPosition;

		protected float activatorHeight;

		protected Vector2 windowSize;

		protected float searchFieldHeight = 28;

		protected float listLabelHeight = 30;

		protected float headerHeight = 30;

		protected float listHeight = 0;

		protected float listCursorHeight = 0;

		protected int maxItemHeightCount = 20;


		// callbacks
		protected Notify closeCallback;

		public virtual void Init(float width, float activatorHeight, string name, List<Element> tree,
			Vector2 callPosition, Rect callBounds, Notify closeCallback, BaseEditor baseEditor)
		{
			this.name = name;
			this.tree = tree;
			this.closeCallback = closeCallback;
			this.baseEditor = baseEditor;

			this.windowSize.x = width;
			this.activatorHeight = activatorHeight;
			this.callPosition = callPosition;
			if(callBounds.x + width > Screen.width)
			{
				this.callPosition.x = this.callPosition.x + callBounds.width - width;
			}

			for(int i = 0; i < this.tree.Count; i++)
			{
				this.tree[i].popup = this;
			}

			this.listLabelHeight = EditorContent.Instance.PopupListStyle.CalcHeight(new GUIContent("Name"), width);
			this.headerHeight = EditorContent.Instance.PopupListHeaderStyle.CalcHeight(new GUIContent("Header"), width) +
				EditorContent.Instance.PopupListHeaderStyle.margin.vertical;

			this.animation.speed = 3;

			this.UpdateList();
			this.searchField.SetFocus();
		}

		public override void OnOpen()
		{
			if(this.baseEditor != null)
			{
				this.baseEditor.BlockScroll = true;
			}
			this.animation.valueChanged.AddListener(this.editorWindow.Repaint);
			this.editorWindow.Focus();
		}

		public virtual void Close()
		{
			this.isClosing = true;
			this.editorWindow.Close();
		}

		public override void OnClose()
		{
			if(this.baseEditor != null)
			{
				this.baseEditor.BlockScroll = false;
			}
			if(this.closeCallback != null)
			{
				this.closeCallback();
			}
		}


		/*
		============================================================================
		Bound functions
		============================================================================
		*/
		protected virtual void UpdateHeight(float height)
		{
			this.topMode = false;
			if(this.maxItemHeightCount > 0)
			{
				height = Mathf.Min(height, this.maxItemHeightCount * this.listLabelHeight);
			}
			this.windowSize.y = this.searchFieldHeight + this.headerHeight + height;
			this.listHeight = this.windowSize.y - this.searchFieldHeight;
			this.listCursorHeight = this.listHeight - this.headerHeight;
		}

		public override Vector2 GetWindowSize()
		{
			return this.windowSize;
		}

		public virtual bool CursorInList()
		{
			float y = Event.current.mousePosition.y - this.scroll.y;
			return y >= 0 && y < this.listCursorHeight;
		}


		/*
		============================================================================
		GUI functions
		============================================================================
		*/
		public override void OnGUI(Rect rect)
		{
			if(EditorWindow.focusedWindow != this.editorWindow)
			{
				this.Close();
				return;
			}

			EditorGUILayout.BeginVertical();

			this.topMode = this.editorWindow.position.y < this.callPosition.y;
			if(this.topMode)
			{
				if(this.animation.isAnimating)
				{
					Rect bounds = new Rect(this.animation.value * this.editorWindow.position.width, 0,
						this.editorWindow.position.width, this.listHeight);
					GUILayoutUtility.GetRect(this.editorWindow.position.width, this.listHeight);

					// previous list
					GUILayout.BeginArea(bounds);
					this.ShowList(this.previousList);
					this.ShowHeader(this.previousHeader);
					GUILayout.EndArea();

					// current list
					bounds.x += this.editorWindow.position.width * (this.animation.target * -1);
					GUILayout.BeginArea(bounds);
					this.ShowList(this.displayList);
					this.ShowHeader(this.header);
					GUILayout.EndArea();
				}
				else
				{
					this.ShowList(this.displayList);
					this.ShowHeader(this.header);
				}

				this.ShowSearch();
			}
			else
			{
				this.ShowSearch();

				if(this.animation.isAnimating)
				{
					Rect bounds = new Rect(this.animation.value * this.editorWindow.position.width,
						this.searchFieldHeight,
						this.editorWindow.position.width, this.listHeight);
					GUILayoutUtility.GetRect(this.editorWindow.position.width, this.listHeight);

					// previous list
					GUILayout.BeginArea(bounds);
					this.ShowHeader(this.previousHeader);
					this.ShowList(this.previousList);
					GUILayout.EndArea();

					// current list
					bounds.x += this.editorWindow.position.width * (this.animation.target * -1);
					GUILayout.BeginArea(bounds);
					this.ShowHeader(this.header);
					this.ShowList(this.displayList);
					GUILayout.EndArea();
				}
				else
				{
					this.ShowHeader(this.header);
					this.ShowList(this.displayList);
				}
			}

			EditorGUILayout.EndVertical();


			// input
			if(this.displayList.Count > 0 &&
				!this.animation.isAnimating)
			{
				if(Event.current.type == EventType.MouseMove)
				{
					this.mouseMoved = true;
					this.editorWindow.Repaint();
				}

				// list navigation
				if(Event.current.keyCode == KeyCode.UpArrow)
				{
					if(Event.current.type == EventType.KeyUp)
					{
						this.holdingArrowKey = false;
						this.holdTimeout = 0;
					}
					else if(this.holdTimeout < Time.realtimeSinceStartup)
					{
						bool started = false;
						if(this.holdingArrowKey)
						{
							this.holdTimeout = Time.realtimeSinceStartup + 0.025f;
						}
						else
						{
							started = true;
							this.holdTimeout = Time.realtimeSinceStartup + 0.5f;
							this.holdingArrowKey = true;
						}

						if(this.selectedIndex == -1)
						{
							this.selectedIndex = this.displayList.Count - 1;
						}
						else
						{
							this.selectedIndex--;
							if(this.selectedIndex < 0)
							{
								this.selectedIndex = this.displayList.Count - 1;
							}
							else if(this.selectedIndex < this.displayList.Count &&
								this.displayList[this.selectedIndex] is SeparatorElement)
							{
								this.selectedIndex--;
								if(this.selectedIndex < 0)
								{
									this.selectedIndex = this.displayList.Count - 1;
								}
							}
							if(this.selectedIndex == 0 &&
								!started)
							{
								this.holdTimeout += 0.5f;
							}
						}
						this.editorWindow.Repaint();
						this.UpdateScrollPosition();
					}
				}
				else if(Event.current.keyCode == KeyCode.DownArrow)
				{
					if(Event.current.type == EventType.KeyUp)
					{
						this.holdingArrowKey = false;
						this.holdTimeout = 0;
					}
					else if(this.holdTimeout < Time.realtimeSinceStartup)
					{
						bool started = false;
						if(this.holdingArrowKey)
						{
							this.holdTimeout = Time.realtimeSinceStartup + 0.025f;
						}
						else
						{
							started = true;
							this.holdTimeout = Time.realtimeSinceStartup + 0.5f;
							this.holdingArrowKey = true;
						}

						if(this.selectedIndex == -1)
						{
							this.selectedIndex = 0;
						}
						else
						{
							this.selectedIndex++;
							if(this.selectedIndex >= this.displayList.Count)
							{
								this.selectedIndex = 0;
							}
							else if(this.selectedIndex < this.displayList.Count &&
								this.displayList[this.selectedIndex] is SeparatorElement)
							{
								this.selectedIndex++;
								if(this.selectedIndex >= this.displayList.Count)
								{
									this.selectedIndex = 0;
								}
							}
							if(this.selectedIndex == this.displayList.Count - 1 &&
								!started)
							{
								this.holdTimeout += 0.5f;
							}
						}
						this.editorWindow.Repaint();
						this.UpdateScrollPosition();
					}
				}
				// parent navigation
				else if(Event.current.keyCode == KeyCode.LeftArrow)
				{
					if(Event.current.type == EventType.KeyUp &&
						this.header != null)
					{
						Event.current.Use();
						this.selectedIndex = -1;
						this.previousHeader = this.header;
						this.header = this.header.parent;

						// animation
						this.previousList.Clear();
						this.previousList.AddRange(this.displayList);
						this.animation.value = 0;
						this.animation.target = 1;

						this.UpdateList();
						this.selectedIndex = this.displayList.IndexOf(this.previousHeader);
						this.editorWindow.Repaint();
					}
				}
				else if(Event.current.keyCode == KeyCode.RightArrow)
				{
					if(Event.current.type == EventType.KeyUp &&
						this.selectedIndex >= 0 &&
						this.selectedIndex < this.displayList.Count &&
						this.displayList[this.selectedIndex] is TypeElement)
					{
						Event.current.Use();
						this.displayList[this.selectedIndex].Accepted();
						this.selectedIndex = 0;
					}
				}
			}
			// accept/cancel
			if(Event.current.type == EventType.KeyUp)
			{
				if(Event.current.keyCode == KeyCode.Escape)
				{
					this.Close();
				}
				else if(Event.current.keyCode == KeyCode.Return ||
					Event.current.keyCode == KeyCode.KeypadEnter)
				{
					if(this.selectedIndex >= 0 &&
						this.selectedIndex < this.displayList.Count)
					{
						this.displayList[this.selectedIndex].Accepted();
					}
				}
			}
		}

		protected virtual void ShowSearch()
		{
			if(!this.isClosing)
			{
				EditorGUILayout.BeginVertical(EditorContent.Instance.PopupListStyle);
				this.search = this.searchField.OnGUI(this.search);
				if(this.search != this.lastSearch)
				{
					this.lastSearch = this.search;
					this.header = null;
					this.UpdateList();
				}
				EditorGUILayout.EndVertical();

				if(Event.current.type == EventType.Repaint)
				{
					this.searchFieldHeight = GUILayoutUtility.GetLastRect().height;
				}
			}
		}

		protected virtual void ShowHeader(Element header)
		{
			if(header != null)
			{
				if(GUILayout.Button(header.DisplayName,
						EditorContent.Instance.PopupListHeaderStyle) &&
					!this.animation.isAnimating)
				{
					this.selectedIndex = -1;
					this.previousHeader = header;
					this.header = header.parent;

					// animation
					this.previousList.Clear();
					this.previousList.AddRange(this.displayList);
					this.animation.value = 0;
					this.animation.target = 1;

					this.UpdateList();
					this.selectedIndex = this.displayList.IndexOf(this.previousHeader);
					this.editorWindow.Repaint();
				}
				EditorContent.Instance.DrawLeftArrow();
			}
			else
			{
				GUILayout.Label(this.name,
					EditorContent.Instance.PopupListHeaderStyle);
			}
		}

		protected virtual void ShowList(List<Element> list)
		{
			this.scroll = EditorGUILayout.BeginScrollView(this.scroll);
			EditorGUILayout.BeginVertical();

			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					list[i].Show(i);
				}
			}

			EditorGUILayout.EndVertical();
			EditorGUILayout.EndScrollView();

			if(this.mouseMoved &&
				Event.current.type == EventType.Repaint)
			{
				this.mouseMoved = false;
				this.selectedIndex = -1;
				this.editorWindow.Repaint();
			}
		}

		protected virtual void UpdateList()
		{
			this.displayList.Clear();

			float height = 0;

			if(this.search == "")
			{
				for(int i = 0; i < this.tree.Count; i++)
				{
					if(this.tree[i].parent == this.header)
					{
						this.displayList.Add(this.tree[i]);
						height += this.tree[i].Height;
					}
				}
			}
			else
			{
				string[] searchSplit = this.search.Split(new char[] { ' ' },
					StringSplitOptions.RemoveEmptyEntries);

				// matches name
				for(int i = 0; i < this.tree.Count; i++)
				{
					if(!(this.tree[i] is TypeElement) &&
						!this.DisplayListContains(this.tree[i].Value))
					{
						if(this.tree[i].DisplayName.Equals(this.search, StringComparison.OrdinalIgnoreCase))
						{
							this.displayList.Add(this.tree[i]);
							height += this.tree[i].Height;
						}
					}
				}
				// starts with name
				for(int i = 0; i < this.tree.Count; i++)
				{
					if(!(this.tree[i] is TypeElement) &&
						!this.DisplayListContains(this.tree[i].Value))
					{
						if(this.tree[i].DisplayName.StartsWith(this.search, StringComparison.OrdinalIgnoreCase))
						{
							this.displayList.Add(this.tree[i]);
							height += this.tree[i].Height;
						}
					}
				}
				// contains full
				for(int i = 0; i < this.tree.Count; i++)
				{
					if(!(this.tree[i] is TypeElement) &&
						!this.DisplayListContains(this.tree[i].Value))
					{
						if(this.tree[i].DisplayName.IndexOf(this.search, System.StringComparison.OrdinalIgnoreCase) >= 0 ||
							this.tree[i].Description.IndexOf(this.search, System.StringComparison.OrdinalIgnoreCase) >= 0)
						{
							this.displayList.Add(this.tree[i]);
							height += this.tree[i].Height;
						}
					}
				}
				// contains split
				for(int i = 0; i < this.tree.Count; i++)
				{
					if(!(this.tree[i] is TypeElement) &&
						!this.DisplayListContains(this.tree[i].Value))
					{
						int count = 0;
						for(int j = 0; j < searchSplit.Length; j++)
						{
							if(this.tree[i].DisplayName.IndexOf(searchSplit[j], System.StringComparison.OrdinalIgnoreCase) >= 0 ||
								this.tree[i].Description.IndexOf(searchSplit[j], System.StringComparison.OrdinalIgnoreCase) >= 0)
							{
								count++;
							}
						}
						if(count == searchSplit.Length)
						{
							this.displayList.Add(this.tree[i]);
							height += this.tree[i].Height;
						}
					}
				}
			}

			this.UpdateHeight(height);
		}

		protected virtual bool DisplayListContains(object value)
		{
			for(int i = 0; i < this.displayList.Count; i++)
			{
				if(this.displayList[i].CheckValue(value))
				{
					return true;
				}
			}
			return false;
		}

		protected virtual void UpdateScrollPosition()
		{
			if(this.selectedIndex == 0)
			{
				this.scroll.y = 0;
			}
			else
			{
				float indexPos = 0;
				float selectedHeight = 0;
				if(this.selectedIndex >= 0 &&
					this.selectedIndex < this.displayList.Count)
				{
					selectedHeight = this.displayList[this.selectedIndex].Height;
					for(int i = 0; i < this.selectedIndex; i++)
					{
						indexPos += this.displayList[i].Height;
					}
				}

				if(indexPos < this.scroll.y)
				{
					this.scroll.y = indexPos;
				}
				else if((this.scroll.y + this.editorWindow.position.height - this.searchFieldHeight -
					this.headerHeight) < indexPos + selectedHeight)
				{
					this.scroll.y += (indexPos + selectedHeight) -
						(this.scroll.y + this.editorWindow.position.height - this.searchFieldHeight -
							this.headerHeight);
				}
			}
		}


		/*
		============================================================================
		Element classes
		============================================================================
		*/
		public abstract class Element
		{
			public BaseSelectionPopup popup;

			public Element parent;

			protected string name = "";

			protected string description = "";

			protected GUIContent content;

			public Element()
			{

			}

			public Element(string name, string description) : this(name, description, null)
			{

			}

			public Element(string name, string description, Element parent)
			{
				this.name = name;
				this.description = description;
				this.parent = parent;
				this.content = new GUIContent(this.DisplayName, Maki.EditorSettings.popupTooltip ? this.Description : "");
			}

			public virtual string Name
			{
				get { return this.name; }
			}

			public virtual string Description
			{
				get { return this.description; }
			}

			public virtual string DisplayName
			{
				get { return this.name; }
			}

			public virtual void Show(int i)
			{
				if(GUILayout.Button(this.content,
					this.popup.index == i ?
						EditorContent.Instance.SelectedPopupListStyle :
						(this.popup.selectedIndex == i ?
							EditorContent.Instance.HoverPopupListStyle :
							EditorContent.Instance.PopupListStyle)) &&
					!this.popup.animation.isAnimating)
				{
					this.Accepted();
				}
				else if(this.popup.mouseMoved &&
					Event.current.type == EventType.Repaint &&
					GUILayoutUtility.GetLastRect().Contains(Event.current.mousePosition) &&
					this.popup.CursorInList())
				{
					this.popup.mouseMoved = false;
					this.popup.selectedIndex = i;
					this.popup.editorWindow.Repaint();
				}
			}

			public virtual float Height
			{
				get { return this.popup.listLabelHeight; }
			}

			public abstract void Accepted();

			public virtual object Value
			{
				get { return null; }
			}

			public virtual bool CheckValue(object value)
			{
				return false;
			}
		}

		public class SeparatorElement : Element
		{
			public SeparatorElement()
			{

			}

			public SeparatorElement(Element parent)
			{
				this.parent = parent;
			}

			public override void Show(int i)
			{
				GUILayout.Label("", EditorContent.Instance.EmptyStyle,
					GUILayout.Height(this.Height), GUILayout.MinHeight(this.Height), GUILayout.MaxHeight(this.Height));
			}

			public override float Height
			{
				get { return 1; }
			}

			public override void Accepted()
			{

			}
		}

		public class TypeElement : Element
		{
			public TypeElement(string name, string description) : this(name, description, null)
			{

			}

			public TypeElement(string name, string description, Element parent) : base(name, description, parent)
			{

			}

			public TypeElement(string name, string description, Element parent, BaseSelectionPopup popup) : base(name, description, parent)
			{
				this.popup = popup;
			}

			public override void Show(int i)
			{
				if(GUILayout.Button(this.content,
					this.popup.index == i ?
						EditorContent.Instance.SelectedPopupListTypeStyle :
						(this.popup.selectedIndex == i ?
							EditorContent.Instance.HoverPopupListTypeStyle :
							EditorContent.Instance.PopupListTypeStyle)) &&
					!this.popup.animation.isAnimating)
				{
					this.Accepted();
				}
				else if(this.popup.mouseMoved &&
					Event.current.type == EventType.Repaint &&
					GUILayoutUtility.GetLastRect().Contains(Event.current.mousePosition) &&
					this.popup.CursorInList())
				{
					this.popup.mouseMoved = false;
					this.popup.selectedIndex = i;
					this.popup.editorWindow.Repaint();
				}

				EditorContent.Instance.DrawRightArrow(true);
			}

			public override void Accepted()
			{
				this.popup.selectedIndex = -1;
				this.popup.previousHeader = this.popup.header;
				this.popup.header = this;

				// animation
				this.popup.previousList.Clear();
				this.popup.previousList.AddRange(this.popup.displayList);
				this.popup.animation.value = 0;
				this.popup.animation.target = -1;

				// clear search
				this.popup.search = "";
				this.popup.lastSearch = "";
				this.popup.searchField = new SearchField();
				this.popup.searchField.SetFocus();

				// update popup
				this.popup.UpdateList();
				this.popup.editorWindow.Repaint();
			}

			public override object Value
			{
				get { return this.name; }
			}

			public override bool CheckValue(object value)
			{
				return this.name.Equals(value);
			}
		}
	}
}
